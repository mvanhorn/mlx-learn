"""Compare device-resident native scheduling variants with exact output checks."""
from __future__ import annotations
import gc,hashlib,importlib.util,json,statistics,time,warnings
from pathlib import Path
import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case,dataset,independent_score
from benchmarks.logistic_wide import package_source_paths
from mlxlearn_device import fit_logistic
from mlxlearn_device import _logistic as device_module

base=Path(__file__).resolve().parent
names=('baseline','adaptive16')
modules={}
for name in names:
 p=base/name/'_metal_loop.so';spec=importlib.util.spec_from_file_location('_metal_loop',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);modules[name]=module
original=device_module.metal_loop
EVENTS=[]
class Proxy:
 def __init__(self,name):self.name=name
 def run(self,*args):
  r=modules[self.name].run(*args)
  if len(r)!=10:raise ValueError(f'bad instrumented result {len(r)}')
  EVENTS.append({'n_iter':int(r[1]),'status':int(r[2]),'gpu_ms':float(r[6])*1000,'native_wall_ms':float(r[7])*1000,'command_buffers':int(r[8]),'encoded_steps':int(r[9])})
  return r[:6]
proxies={k:Proxy(k) for k in names}

cases=[Case('normal_1024',20000,1024,seed=41),
       Case('weighted_ill_83',20000,1024,seed=83,weighted=True,ill_conditioned=True),
       Case('weighted_ill_41',20000,1024,seed=41,weighted=True,ill_conditioned=True),
       Case('wide_4096',20000,4096,seed=41),
       Case('rank_deficient_1024',20000,1024,seed=41,rank_deficient=True,C=1e6),
       Case('budget_weighted_ill',20000,1024,seed=83,weighted=True,ill_conditioned=True)]


def fit(X,y,weights,case,variant,sketch):
 EVENTS.clear();device_module.metal_loop=proxies[variant]
 with warnings.catch_warnings(record=True) as caught:
  warnings.simplefilter('always');mx.synchronize();enabled=gc.isenabled();gc.disable()
  try:
   start=time.perf_counter();m=fit_logistic(X,y,sample_weight=weights,C=case.C,tol=1e-4,max_iter=3 if case.name.startswith('budget') else 200,sketch_size=sketch);mx.synchronize();elapsed=(time.perf_counter()-start)*1000
  finally:
   if enabled:gc.enable()
 return m,elapsed,{'n_iter':m.n_iter,'converged':m.converged,'stop_reason':m.stop_reason,'sketch_pairs':m.sketch_pairs_,'fallback':m.used_unsketched_fallback_,'native_events':EVENTS.copy(),'warnings':[{'category':w.category.__name__,'message':str(w.message)} for w in caught]}


def sig(m):
 return {'coef':np.asarray(m.coef_).copy(),'center':np.asarray(m.center_).copy(),'bias':np.asarray(m.centered_intercept_).copy()}


def main():
 roots=[Path('src/mlxlearn_device'),Path('src/mlxlearn')]
 paths=package_source_paths()+[p for d in roots[:1] for p in d.rglob('*.py')]+[Path(__file__).resolve()]+[base/(v+'.mm') for v in names]+[base/v/'_metal_loop.so' for v in names]
 hashes=lambda:{str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 before=hashes();out={'method':'resident-device fits, instrumented extensions, paired balanced order, 3 warmups + 8 repeats, quality outside timer','source_integrity_before':before,'cases':[]}
 try:
  with threadpool_limits(limits=1):
   for case in cases:
    X,y,weights,ratio=dataset(case)
    dx=mx.array(X);dy=mx.array(y);dw=mx.array(weights,dtype=mx.float32) if weights is not None else None;mx.eval(*(a for a in (dx,dy,dw) if a is not None))
    with warnings.catch_warnings():
     warnings.simplefilter('ignore');ref=SK(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weights)
    refq,refpred=independent_score(ref,X,y,weights,case.C,ratio)
    for sketch in (0,4):
     samples={v:[] for v in names};models={v:[] for v in names};details={v:[] for v in names}
     for i in range(11):
      for v in (names if i%2==0 else names[::-1]):
       m,t,d=fit(dx,dy,dw,case,v,sketch)
       if i>=3:samples[v].append(t);models[v].append(m);details[v].append(d)
     quality={v:[independent_score(m,X,y,weights,case.C,ratio,(refq['objective_float64'],refpred))[0] for m in group] for v,group in models.items()}
     failures=[]
     for i in range(8):
      a,b=details['baseline'][i],details['adaptive16'][i]
      sa,sb=sig(models['baseline'][i]),sig(models['adaptive16'][i])
      if any(not np.array_equal(sa[k],sb[k]) for k in sa):failures.append([i,'device output changed'])
      if (a['n_iter'],a['converged'],a['stop_reason'],a['fallback']) != (b['n_iter'],b['converged'],b['stop_reason'],b['fallback']):failures.append([i,'status changed'])
      if case.name.startswith('budget'):
       if a['n_iter']>3 or b['n_iter']>3 or a['converged'] or b['converged']:failures.append([i,'budget or false convergence'])
      else:
       if not b['converged'] or b['warnings'] or quality['adaptive16'][i]['gradient_max_abs_float64']>1e-4:failures.append([i,'accuracy or warning'])
       if ratio is not None and quality['adaptive16'][i]['nullspace_coefficient_relative']>1e-3:failures.append([i,'nullspace'])
     row={'case':case.name,'sketch_size':sketch,'median_ms':{v:statistics.median(s) for v,s in samples.items()},'samples_ms':samples,'details':details,'quality':quality,'failures':failures}
     out['cases'].append(row);print(case.name,'sketch',sketch,{k:round(v,3) for k,v in row['median_ms'].items()},'fail',failures[:2],flush=True)
     (base/'device-results.json').write_text(json.dumps(out,indent=2)+'\n')
 finally:device_module.metal_loop=original
 out['source_integrity_after']=hashes();out['source_integrity_passed']=out['source_integrity_before']==out['source_integrity_after'];(base/'device-results.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
