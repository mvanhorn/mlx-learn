"""Exploratory sketch-size panel; includes setup and independent scoring."""
import json, statistics, time, warnings
from pathlib import Path
import mlx.core as mx
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case, dataset, independent_score
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression

payload={'description':'Exploratory wide ill-conditioned C1, max_iter=200, tol=1e-4. One warmup and 3 measured fits per k. Complete fit includes setup; independent scores outside timing. No sample discarded.', 'rows':[]}
original = native_command.run_native_loop
traces=[]
def observed(*args, **kwargs):
 result=original(*args, **kwargs)
 if isinstance(result,native_command.NativeAttempt):
  s=result.state
  traces.append({'status':result.status,'n_iter':s.n_iter,'n_fev':s.n_fev,'reason':s.stop_reason,'converged':s.converged,'gradient':s.grad_max_abs})
 else:traces.append({'status':'ineligible' if result is None else 'legacy'})
 return result
native_command.run_native_loop=observed
try:
 with threadpool_limits(limits=1):
  for seed in (41,83):
   case=Case(f'wide_{seed}',20000,4096,seed=seed,ill_conditioned=True)
   X,y,weights,ratio=dataset(case)
   with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always');ref=SkLogisticRegression(C=1,tol=1e-4,max_iter=200).fit(X,y)
   (refscore,_)=independent_score(ref,X,y,None,1.,None)
   for k in (0,1,2,4,8):
    row={'seed':seed,'sketch_size':k,'sklearn':refscore,'sklearn_warning':[str(w.message) for w in caught],'fits':[]}
    for i in range(4):
     traces.clear()
     with warnings.catch_warnings(record=True) as caught_fit,tuning_context(force_backend='mlx',lbfgs_sketch_size=k):
      warnings.simplefilter('always');mx.synchronize();start=time.perf_counter()
      model=LogisticRegression(C=1,tol=1e-4,max_iter=200).fit(X,y);mx.synchronize();elapsed=(time.perf_counter()-start)*1000
     score,_=independent_score(model,X,y,None,1.,None)
     score['objective_relative_gap_to_sklearn']=(score['objective_float64']-refscore['objective_float64'])/abs(refscore['objective_float64'])
     item={'ms':elapsed,'iterations':model.n_iter_.tolist(),'warnings':[str(w.message) for w in caught_fit], 'native_attempt':list(traces),'quality':score}
     if i:row['fits'].append(item)
    row['median_ms']=statistics.median(x['ms'] for x in row['fits'])
    payload['rows'].append(row)
    print(seed,k,round(row['median_ms'],2),row['fits'][-1],flush=True)
    Path('bench/native_resume/wide_sketch_panel.json').write_text(json.dumps(payload,indent=2)+'\n')
finally:native_command.run_native_loop=original
