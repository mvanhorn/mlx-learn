"""Inspect the discarded native attempt on the ill-conditioned benchmark."""
import json, time, warnings
from types import SimpleNamespace
import mlx.core as mx
import numpy as np
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import CASES, dataset, independent_score
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn._solvers.fused_lbfgs import _convergence_gradient_max
from mlxlearn.linear_model import LogisticRegression

case=next(c for c in CASES if c.name=='ill_conditioned_4096')
X,y,sw,_=dataset(case)
original_loop=native_command._metal_loop
original_run=native_command.run_native_loop
records=[]
class Loop:
    def run(self,*args):
        result=original_loop.run(*args)
        records.append({'raw':result[0],'iterations':result[1],'status':result[2],
                        'function_evaluations':result[3], 'last':result[4], 'previous':result[5]})
        return result

def wrapper(*args,**kw):
    Xd,yd,weights,sw_sum,l2,fit_intercept,config,fun=args
    result=original_run(*args,**kw)
    if records:
        rec=records[-1]; p=Xd.shape[1]+int(fit_intercept)
        theta=mx.array(np.frombuffer(rec.pop('raw'),dtype=np.float32).copy()).reshape(1,p)
        objective,gradient=fun(theta)
        grad_max=float(_convergence_gradient_max(gradient,kw.get('convergence_center')))
        recent=.5*(abs(rec['last'])+abs(rec['previous'])) if rec['iterations']>=2 else abs(rec['last'])
        rec.update({'direct_objective':objective,'direct_original_grad':grad_max,
                    'direct_relative_loss_change':recent/max(abs(objective),1e-12),
                    'internal_tol':config.tol,'max_iter':config.max_iter,
                    'python_returned_none':result is None})
    return result

native_command._metal_loop=Loop();native_command.run_native_loop=wrapper
try:
 with threadpool_limits(limits=1),tuning_context(force_backend='mlx'),warnings.catch_warnings(record=True) as caught:
  warnings.simplefilter('always'); t=time.perf_counter();model=LogisticRegression(C=case.C,max_iter=200,tol=1e-4).fit(X,y);elapsed=time.perf_counter()-t
  score,_=independent_score(model,X,y,None,case.C,None)
 print(json.dumps({'native_attempts':records,'whole_fit_ms':elapsed*1000,'model_iterations':model.n_iter_.tolist(),'warnings':[str(w.message) for w in caught],'independent_score':score},indent=2))
finally:
 native_command._metal_loop=original_loop;native_command.run_native_loop=original_run
