"""CPU-only investigation of correlation-block preconditioning.

This is a small, untimed numerical illustration, not a GPU benchmark or a
production implementation. It finds disjoint pairs from a random row sample,
builds 2x2 ridge-regularized Hessian blocks, and optimizes the *same* binary
logistic objective in transformed coordinates. An exact three-feature linear
dependency illustrates why independently preconditioning pairs can add a
component in the global null space. Run only when the GPU timing lane is idle.
"""
from __future__ import annotations

import json
import sys
import time

import numpy as np
from scipy.optimize import minimize
from scipy.special import expit
from threadpoolctl import threadpool_limits


def make_case(kind: str, seed: int = 41):
    rng = np.random.default_rng(seed)
    n, d = 1_200, 96
    X = rng.standard_normal((n, d))
    if kind == "correlated":
        half = d // 2
        X[:, half:] = X[:, :half] + 0.01 * X[:, half:]
        X *= np.logspace(-1, 1, d)
        X = X[:, rng.permutation(d)]
        y = (X[:, 0] + 0.5 * rng.standard_normal(n) > 0).astype(float)
        return X, y, 1.0, None
    if kind == "rank_deficient":
        # The dependency spans a correlated pair and an independent feature:
        # x2 = x0 + .05*x1, so n=(-1,-.05,1,0,...) is an exact null vector.
        X[:, 2] = X[:, 0] + 0.05 * X[:, 1]
        y = (X[:, 0] + 0.5 * rng.standard_normal(n) > 0).astype(float)
        null = np.zeros(d)
        null[:3] = [-1.0, -0.05, 1.0]
        return X, y, 1e6, null
    y = (X[:, 0] + 0.5 * rng.standard_normal(n) > 0).astype(float)
    return X, y, 1.0, None


def block_transform(X, C, seed=77, sample_rows=192, min_abs_correlation=0.9):
    """Sampled, disjoint correlation pairs; no known fixture pairing is used."""
    n, d = X.shape
    rng = np.random.default_rng(seed)
    sample = X[rng.choice(n, min(n, sample_rows), replace=False)]
    sample = sample - sample.mean(axis=0)
    norm = np.linalg.norm(sample, axis=0)
    normalized = sample / np.where(norm > 0, norm, 1.0)
    correlation = np.abs(normalized.T @ normalized)
    np.fill_diagonal(correlation, 0)
    available = np.ones(d, dtype=bool)
    pairs = []
    while True:
        mask = available[:, None] & available[None, :]
        masked = np.where(mask, correlation, 0)
        first, second = np.unravel_index(np.argmax(masked), masked.shape)
        if masked[first, second] < min_abs_correlation:
            break
        pairs.append((int(first), int(second)))
        available[first] = available[second] = False
    # Scalar baseline on unpaired features avoids a global Jacobi transform.
    diagonal = 0.25 * np.mean(sample * sample, axis=0) + 1.0 / (C * n)
    scalar = 1.0 / np.sqrt(np.mean(diagonal))
    transform = np.eye(d) * scalar
    for first, second in pairs:
        block = sample[:, [first, second]]
        H = 0.25 * (block.T @ block) / len(block) + np.eye(2) / (C * n)
        values, vectors = np.linalg.eigh(H)
        # The inverse square root is positive definite even for near duplicates.
        transform[np.ix_([first, second], [first, second])] = (
            vectors * (1.0 / np.sqrt(values))
        ) @ vectors.T
    return transform, pairs


def solve(X, y, C, transform, maxiter=200, gtol=1e-4):
    """Solve exactly the original regularized objective with w=transform@z."""
    n, d = X.shape
    XT = X @ transform
    lam = 1.0 / (C * n)

    def fun(z):
        w = transform @ z[:d]
        logits = XT @ z[:d] + z[d]
        loss = np.mean(np.logaddexp(0.0, logits) - y * logits) + 0.5 * lam * (w @ w)
        residual = (expit(logits) - y) / n
        grad = np.empty(d + 1)
        grad[:d] = XT.T @ residual + lam * (transform.T @ w)
        grad[d] = residual.sum()
        return float(loss), grad

    start = time.perf_counter()
    result = minimize(fun, np.zeros(d + 1), jac=True, method="L-BFGS-B",
                      options={"maxiter": maxiter, "gtol": gtol, "ftol": 1e-15,
                               "maxls": 30, "maxcor": 10})
    elapsed = time.perf_counter() - start
    w = transform @ result.x[:d]
    logits = X @ w + result.x[d]
    residual = (expit(logits) - y) / n
    grad = X.T @ residual + lam * w
    grad_max = max(float(np.max(np.abs(grad))), abs(float(residual.sum())))
    return {"objective": float(result.fun), "gradient_original_max": grad_max,
            "iterations": int(result.nit), "success": bool(result.success),
            "message": str(result.message), "seconds_excluding_setup": elapsed,
            "coef": w}


def main():
    output = []
    with threadpool_limits(limits=1):
        for kind in ("ordinary", "correlated", "rank_deficient"):
            X, y, C, null = make_case(kind)
            X -= X.mean(axis=0)
            transform, pairs = block_transform(X, C)
            baseline = solve(X, y, C, np.eye(X.shape[1]))
            blocked = solve(X, y, C, transform)
            reference = solve(X, y, C, np.eye(X.shape[1]), maxiter=2_000, gtol=1e-10)
            row = {"case": kind, "C": C, "paired_columns": len(pairs), "pairs": pairs}
            for name, result in (("baseline", baseline), ("blocked", blocked), ("reference", reference)):
                w = result.pop("coef")
                result["relative_objective_gap"] = (
                    result["objective"] - reference["objective"]
                ) / abs(reference["objective"])
                result["nullspace_ratio"] = (None if null is None else
                    abs(float(w @ null)) / max(float(np.linalg.norm(w) * np.linalg.norm(null)), 1e-300))
                row[name] = result
            output.append(row)
        # A deterministic analytic counterexample: Xn=0 but P(Xᵀr) has a
        # nonzero n component for block-diagonal P. This is independent of any
        # particular optimizer or convergence tolerance.
        A = np.array([[1., 0., 1.], [0., 1., 1.]])
        null = np.array([-1., -1., 1.])
        H = A.T @ A + np.eye(3) * 1e-6
        P = np.zeros((3, 3))
        P[:2, :2] = np.linalg.inv(H[:2, :2])
        P[2, 2] = 1.0 / H[2, 2]
        gradient = A.T @ np.array([1., 2.])
        output.append({"analytic_counterexample": {"null_residual": float(np.linalg.norm(A @ null)),
            "original_gradient_null_dot": float(null @ gradient),
            "block_direction_null_dot": float(null @ (P @ gradient))}})
    json.dump(output, sys.stdout, indent=2)
    print()


if __name__ == "__main__":
    main()
