"""Hybrid selection, total iteration budgets, and failed-refinement handling."""

from __future__ import annotations

from contextlib import contextmanager
from types import SimpleNamespace

import mlx.core as mx
import numpy as np
import pytest

from mlxlearn._common.device import use_device
from mlxlearn._solvers import logistic, native_logistic
from mlxlearn._solvers.lbfgs import LBFGSState
from mlxlearn_device import _native_cg, _newton


@pytest.mark.parametrize("n,d,l2,ratio,expected", [
    (4096, 2048, 1e-5, 1000, True),
    (20_000, 4096, 1e-5, 1000, True),
    (20_000, 4096, 5e-11, 1000, False),
    (20_000, 4096, 0.999e-7, 1000, False),
    (20_000, 4096, 1e-5, 100, False),
    (20_000, 4096, 1e-5, 1, False),
    (4095, 4096, 1e-5, 1000, False),
    (20_000, 1024, 1e-5, 1000, False),
])
def test_hybrid_selection_keeps_weak_regularization_on_existing_solver(monkeypatch, n, d, l2, ratio, expected):
    monkeypatch.setattr(_native_cg, "metal_loop", SimpleNamespace(run_cg=object()))
    with mx.stream(mx.cpu):
        diagonal = mx.concatenate((mx.ones((d // 2,)), mx.full((d - d // 2,), ratio), mx.ones((1,))))
        parts = mx.stack((mx.zeros((1, d + 1)), diagonal[None, :]))
        chosen = _newton.use_newton_for_curvature(parts, n, d, 1.0, l2)
    assert chosen is expected


@pytest.fixture
def mocked_host_hybrid(monkeypatch):
    @contextmanager
    def pretend_gpu(_device):
        with use_device("cpu"):
            yield "gpu"

    monkeypatch.setattr(logistic, "use_device", pretend_gpu)
    monkeypatch.setattr(logistic, "_use_native_solver", lambda *_args: True)
    monkeypatch.setattr(_newton, "use_newton_for_curvature", lambda *_args: True)
    monkeypatch.setattr(logistic, "_needs_float64_certificate", lambda *_args: True)
    monkeypatch.setattr(logistic, "_original_float64_certificate", lambda *_args: (0.4, 0.0))
    monkeypatch.setattr(logistic, "_polish_binary_intercept", lambda *_a, **_kw: pytest.fail("hybrid must not bias-polish"))
    calls = []

    def run(budget, *, warm_used=None, refined=True, warm_reason="gtol", warm_objective=0.5):
        def warm(X, y, sw, sw_sum, l2, fit_intercept, config, fun, **_kwargs):
            calls.append(("warm", config.max_iter))
            used = config.max_iter if warm_used is None else warm_used
            return LBFGSState(mx.zeros((1, X.shape[1] + 1)), warm_objective, 0.0,
                              used, 2, warm_reason == "gtol", warm_reason)

        def newton(original, centered, center, y, sw, denom, l2, **kwargs):
            calls.append(("newton", kwargs["max_iter"]))
            used = min(3, kwargs["max_iter"])
            return _newton.NewtonResult(kwargs["initial"], used, 5, refined,
                                        "duality-gap" if refined else "line-search-failure",
                                        0.4, 0.0, 1e-6 if refined else 1e-2, 0.0, 4, True)

        monkeypatch.setattr(native_logistic, "minimize_binary", warm)
        monkeypatch.setattr(_newton, "minimize_newton", newton)
        with use_device("cpu"):
            X = np.zeros((3, 512), dtype=np.float32)
            result = logistic.solve_logistic(
                X, np.array([0, 1, 0]), n_classes=2,
                config=logistic.LogisticConfig(device="gpu", max_iter=budget),
                X_device=mx.zeros((3, 512)), X_center=mx.zeros((512,)),
                initial_parts=mx.ones((2, 1, 513)),
            )
        return result, calls

    return run


@pytest.mark.parametrize("budget", [1, 7, 32, 33, 40, 200])
def test_host_hybrid_shares_accepted_iteration_budget(mocked_host_hybrid, budget):
    result, calls = mocked_host_hybrid(budget)
    assert calls[0] == ("warm", min(32, budget))
    assert result.n_iter <= budget
    if budget <= 32:
        assert len(calls) == 1
        assert not result.converged and result.stop_reason == "max_iter"
    else:
        assert calls[1] == ("newton", budget - 32)
        assert result.n_iter == 32 + min(3, budget - 32)
        assert result.converged


def test_early_warm_stop_leaves_the_actual_remaining_budget(mocked_host_hybrid):
    result, calls = mocked_host_hybrid(200, warm_used=3)
    assert calls == [("warm", 32), ("newton", 197)]
    assert result.n_iter == 6 and result.converged


def test_failed_newton_cannot_be_promoted_by_perfect_float64_gradient(mocked_host_hybrid):
    result, calls = mocked_host_hybrid(200, refined=False)
    assert calls == [("warm", 32), ("newton", 168)]
    assert not result.converged and result.stop_reason == "line-search-failure"
    assert result.grad_max_abs == 0
    assert result.n_iter == 35


@pytest.mark.parametrize("reason,objective", [
    ("non-finite-objective", 0.5), ("max_iter", float("nan")), ("max_iter", float("inf")),
])
def test_nonfinite_warm_failure_never_enters_newton_or_passes_certificate(mocked_host_hybrid, reason, objective):
    result, calls = mocked_host_hybrid(200, warm_reason=reason, warm_objective=objective)
    assert calls == [("warm", 32)]
    assert not result.converged and result.stop_reason == "non-finite-objective"


@pytest.mark.parametrize("version", [None, 123, "0.31.0", "0.33.0", "0.32.2rc1"])
def test_hybrid_does_not_select_unsupported_dlpack_version(monkeypatch, version):
    monkeypatch.setattr(mx, "__version__", version)
    monkeypatch.setattr(_native_cg, "metal_loop", SimpleNamespace(run_cg=object()))
    with mx.stream(mx.cpu):
        parts = mx.ones((2, 1, 2049))
        assert not _newton.use_newton_for_curvature(parts, 20_000, 2048, 1.0, 1e-5)
