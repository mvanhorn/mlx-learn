"""Trace ill-conditioned wide fits at tighter tolerances; don't discard warnings."""
import json
import warnings
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace

import numpy as np
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits

from benchmarks.hessian_logistic import Case,dataset,fit_once,independent_score,sources
from benchmarks.logistic_wide import frozen_reference
from benchmarks.sketch_weighted import fit_previous_sketch,reference_sketch_module

root=Path(__file__).resolve().parents[2];here=Path(__file__).resolve().parent
archive=root/'bench/wide_accuracy_candidate/candidate.zip';native=root/'bench/wide_accuracy_candidate/candidate/mlxlearn/_solvers/_metal_loop.abi3.so'
sketch_archive=root/'benchmarks/reference/wide-repair-start-sources-2026-10-27.zip'
extra=[archive,archive.with_suffix('.manifest.json'),native,sketch_archive,sketch_archive.with_suffix('.manifest.json'),Path(__file__).resolve()]
out={'method':'complete fits, stricter requested tol proxies stricter gradient and progress; centered float64 tight oracle','sources_before':sources(extra),'cases':[]}
path=here/'sweep.json';sketch=reference_sketch_module(sketch_archive)
with frozen_reference(archive=archive,extension=native) as candidate,threadpool_limits(limits=1):
 for seed in (41,83):
  case=Case('ill_conditioned_4096',20000,4096,seed=seed,ill_conditioned=True)
  X,y,sw,ratio=dataset(case);center=X.mean(axis=0,dtype=np.float64);centered=X.astype(np.float64)-center
  with warnings.catch_warnings(record=True) as caught:
   warnings.simplefilter('always'); oracle=SkLogisticRegression(C=1,tol=1e-10,max_iter=3000).fit(centered,y)
  oracle=SimpleNamespace(coef_=oracle.coef_,intercept_=oracle.intercept_-oracle.coef_@center)
  score,pred=independent_score(oracle,X,y,sw,1,ratio); oracle_warnings=[str(w.message) for w in caught];del centered
  print('REFERENCE',seed,score,'warnings',oracle_warnings,flush=True)
  for variant in ('candidate','candidate_sketch'):
   for tol in (1e-4,5e-5,2.5e-5,1e-5):
    for budget in (200,300):
     if variant=='candidate_sketch': model,sec,detail=fit_previous_sketch(X,y,sw,case,candidate,sketch,tol,budget,4)
     else: model,sec,detail=fit_once('baseline',X,y,sw,case,candidate,tol,budget,None,4,4)
     quality,_=independent_score(model,X,y,sw,1,ratio,(score['objective_float64'],pred))
     row={'case':asdict(case),'reference':score,'reference_warnings':oracle_warnings,'variant':variant,'tol':tol,'max_iter':budget,'ms':sec*1000,'detail':detail,'quality':quality}
     out['cases'].append(row);print(seed,variant,tol,budget,'n',detail['n_iter'],'ms',round(sec*1000,2),'gap',quality['objective_relative_gap_to_sklearn'],'warnings',detail['warnings'],flush=True)
     path.write_text(json.dumps(out,indent=2)+'\n')
out['sources_after']=sources(extra);out['source_integrity_pass']=out['sources_before']==out['sources_after'];path.write_text(json.dumps(out,indent=2)+'\n')
