"""One-pass Hessian sketch from the already computed initial gradient.

Research prototype only. Computes a true H0*S product without moving training
arrays to CPU. H0 is the binary logistic Hessian at zero logits. The single
probe is supplied by the existing initial-gradient preparation pass, so the
feature component lies in range(X.T) and costs no additional X.T@Omega pass.
"""

from __future__ import annotations

import mlx.core as mx

_hvp = mx.fast.metal_kernel(
    name="research_hessian_gradient_probe_hvp_v1",
    input_names=["X", "s", "sw"],
    output_names=["parts"],
    source=r"""
uint tid=thread_position_in_threadgroup.x,lane=tid%32,sg=tid/32;
uint group=threadgroup_position_in_grid.x;
constexpr uint V=(D+32*FEATURE_GROUPS-1)/(32*FEATURE_GROUPS);
constexpr uint CHUNK=V*32,DPAD=CHUNK*FEATURE_GROUPS;
constexpr uint ROW_GROUPS=GROUPS/FEATURE_GROUPS;
constexpr uint SCRATCH=(ROW_GROUPS*DPAD > GROUPS) ? ROW_GROUPS*DPAD : GROUPS;
uint fs=sg%FEATURE_GROUPS,rs=sg/FEATURE_GROUPS;
threadgroup float scratch[SCRATCH];
float accum[V];for(uint k=0;k<V;++k)accum[k]=0.0f;
float bias=0.0f;
for(uint rr=0;rr<ROWS;++rr){
 uint row=group*(ROW_GROUPS*ROWS)+rr*ROW_GROUPS+rs;
 float values[V],z=0.0f;
 if(row<N){for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;
  values[k]=j<D?X[ulong(row)*D+j]:0.0f;
  if(j<D)z=fma(values[k],s[j],z);}}
 else{for(uint k=0;k<V;++k)values[k]=0.0f;}
 z=simd_sum(z);
 if(FEATURE_GROUPS>1){
  if(lane==0)scratch[sg]=z;
  threadgroup_barrier(mem_flags::mem_threadgroup);
  z=0.0f;for(uint f=0;f<FEATURE_GROUPS;++f)z+=scratch[rs*FEATURE_GROUPS+f];
  threadgroup_barrier(mem_flags::mem_threadgroup);
 }
 if(P>D)z+=s[D];
 float r=(row<N)?0.25f*sw[row]*z:0.0f;
 if(fs==0 && lane==0)bias+=r;
 for(uint k=0;k<V;++k)accum[k]=fma(values[k],r,accum[k]);
}
if(lane==0)scratch[sg]=bias;
threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==0 && lane==0 && P>D){float total=0.0f;
 for(uint q=0;q<GROUPS;++q)total+=scratch[q];parts[ulong(group)*P+D]=total;}
threadgroup_barrier(mem_flags::mem_threadgroup);
for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;scratch[rs*DPAD+j]=accum[k];}
threadgroup_barrier(mem_flags::mem_threadgroup);
if(rs==0){for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;if(j<D){
 float total=0.0f;for(uint r=0;r<ROW_GROUPS;++r)total+=scratch[r*DPAD+j];
 parts[ulong(group)*P+j]=total;
}}}
""",
)


def history(
    X,
    sample_weight,
    sw_sum,
    l2,
    fit_intercept,
    h0inv,
    initial_g,
    *,
    history_size=10,
    min_curvature=1e-12,
):
    n, d = X.shape
    p = d + int(fit_intercept)
    if sample_weight is None:
        sample_weight = mx.ones((n,), mx.float32)
    s0 = initial_g.reshape((p,))
    maximum = mx.max(mx.abs(s0))
    finite = mx.isfinite(maximum) & (maximum > 0)
    scaled = s0 / mx.where(finite, maximum, 1.0)
    length = mx.sqrt(mx.sum(scaled * scaled))
    valid = finite & mx.isfinite(length) & (length > 0)
    s = scaled / mx.where(valid, length, 1.0)
    if n >= 16384:
        groups, fg, rows = (4, 1, 32) if d <= 1024 else (8, 4, 32 if d <= 2048 else 64)
    else:
        groups, fg, rows = (2, 1, 16) if d <= 1024 else (8, 4, 8)
    blocks = (n + (groups // fg) * rows - 1) // ((groups // fg) * rows)
    parts = _hvp(
        inputs=[X, s, sample_weight],
        template=[
            ("N", n),
            ("D", d),
            ("P", p),
            ("GROUPS", groups),
            ("FEATURE_GROUPS", fg),
            ("ROWS", rows),
        ],
        grid=(blocks * groups * 32, 1, 1),
        threadgroup=(groups * 32, 1, 1),
        output_shapes=[(blocks, p)],
        output_dtypes=[mx.float32],
    )[0]
    yy = mx.sum(parts, axis=0) / float(sw_sum)
    if fit_intercept:
        yy = yy + mx.concatenate([l2 * s[:d], mx.zeros((1,), mx.float32)])
    else:
        yy = yy + l2 * s
    sy = mx.sum(s * yy)
    y2 = mx.sum(yy * yy * h0inv)
    valid = (
        valid
        & mx.all(mx.isfinite(s))
        & mx.all(mx.isfinite(yy))
        & mx.isfinite(sy)
        & mx.isfinite(y2)
        & (y2 > 0)
        & (sy > float(min_curvature) * mx.maximum(y2, 1.0))
    )
    mx.eval(s, yy, sy, y2, valid)
    count = int(bool(valid))
    if count:
        coefficients = mx.stack([1.0 / sy, sy / y2]).reshape(1, 2)
        sh = s.reshape(1, p)
        yh = yy.reshape(1, p)
    else:
        sh = mx.zeros((0, p), mx.float32)
        yh = mx.zeros((0, p), mx.float32)
        coefficients = mx.zeros((0, 2), mx.float32)
    if history_size > count:
        sh = mx.concatenate([sh, mx.zeros((history_size - count, p), mx.float32)])
        yh = mx.concatenate([yh, mx.zeros((history_size - count, p), mx.float32)])
        coefficients = mx.concatenate(
            [coefficients, mx.zeros((history_size - count, 2), mx.float32)]
        )
    return sh, yh, coefficients, count
