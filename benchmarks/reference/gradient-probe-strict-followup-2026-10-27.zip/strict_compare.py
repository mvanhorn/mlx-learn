"""Compare current four-pair sketch against a fused initial-gradient probe.

Full sklearn-compatible fits, balanced order, every model independently scored
in float64 after timing. Scratch patching is process-local and restored.
"""

from __future__ import annotations

import contextlib
import importlib.util
import json
import statistics
import sys
from dataclasses import replace
from pathlib import Path

import mlx.core as mx
import numpy as np
from benchmarks.hessian_logistic import CASES, dataset, fit_once, independent_score, sources
from threadpoolctl import threadpool_limits

import mlxlearn_device.hessian_sketch as sketch
from mlxlearn._solvers import native_logistic

spec = importlib.util.spec_from_file_location(
    "gradient_probe", Path(__file__).with_name("gradient_probe.py")
)
gp = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = gp
spec.loader.exec_module(gp)


@contextlib.contextmanager
def candidate():
    original_init = sketch.initial_metric_from_parts
    original_build = sketch.build_sketch_history
    storage = {}

    def init(parts, reg, denom):
        g, h = original_init(parts, reg, denom)
        storage["g"] = g
        return g, h

    def build(
        X,
        sw,
        sw_sum,
        l2,
        fit_intercept,
        h0inv,
        *,
        history_size=10,
        sketch_size=4,
        seed=0,
        min_curvature=1e-12,
    ):
        if "g" not in storage:
            raise RuntimeError("initial gradient not captured")
        return gp.history(
            X,
            sw,
            sw_sum,
            l2,
            fit_intercept,
            h0inv,
            storage["g"],
            history_size=history_size,
            min_curvature=min_curvature,
        )

    original_guard = native_logistic._conservative_config_for_skewed_curvature

    def strict_guard(parts, d, sw_sum, l2, config):
        result = original_guard(parts, d, sw_sum, l2, config)
        return replace(result, tol=min(result.tol, 0.25 * config.tol))

    sketch.initial_metric_from_parts = init
    sketch.build_sketch_history = build
    native_logistic._conservative_config_for_skewed_curvature = strict_guard
    try:
        yield
    finally:
        sketch.initial_metric_from_parts = original_init
        sketch.build_sketch_history = original_build
        native_logistic._conservative_config_for_skewed_curvature = original_guard


def run_one(v, X, y, sw, case):
    with candidate() if v == "gradient_probe" else contextlib.nullcontext():
        variant = "sketch" if v in ("gradient_probe", "existing_sketch") else v
        return fit_once(variant, X, y, sw, case, None, 1e-4, 200, sketch_size=4)


def validate_component():
    rng = np.random.default_rng(13)
    n, d = 1027, 513
    X = rng.normal(size=(n, d)).astype(np.float32)
    y = rng.integers(0, 2, n).astype(np.float32)
    sw = rng.uniform(0.1, 3, n).astype(np.float32)
    sw[::13] = 0
    S = float(sw.astype(np.float64).sum())
    C = 1.0
    l2 = 1 / (S * C)
    X -= X.mean(axis=0, dtype=np.float64).astype(np.float32)
    g = np.concatenate(
        [X.T @ ((0.5 - y) * sw) / S, np.array([((0.5 - y) * sw).sum() / S], np.float32)]
    ).astype(np.float32)
    dev = mx.array(X)
    w = mx.array(sw)
    gv = mx.array(g)
    h = mx.ones((d + 1,), mx.float32)
    hs, hy, hc, k = gp.history(dev, w, S, l2, True, h, gv)
    mx.eval(hs, hy, hc)
    sp = np.asarray(hs)[0].astype(np.float64)
    actual = np.asarray(hy)[0].astype(np.float64)
    Xd = X.astype(np.float64)
    weights = sw.astype(np.float64)
    proj = Xd @ sp[:d] + sp[d]
    r = weights * proj / (4 * S)
    expected = np.concatenate([Xd.T @ r + l2 * sp[:d], np.array([r.sum()])])
    err = np.max(np.abs(actual - expected))
    rel = err / max(float(np.max(np.abs(expected))), 1e-30)
    print("component", k, "absolute max", err, "relative max", rel, flush=True)
    if k != 1 or rel > 5e-5:
        raise RuntimeError("Hessian-vector component accuracy failed")
    return {"seed_pairs": k, "max_abs_error": float(err), "max_relative_error": float(rel)}


def main():
    specs = [
        ("wide_1024", 83),
        ("wide_1024", 2027),
        ("wide_4096", 41),
        ("wide_4096", 83),
        ("weighted_ill_1024", 41),
        ("weighted_ill_1024", 83),
        ("shifted_1024", 41),
        ("shifted_1024", 83),
        ("rank_deficient_1024", 41),
        ("rank_deficient_1024", 83),
        ("ill_conditioned_4096", 41),
        ("ill_conditioned_4096", 83),
    ]
    variants = ("current", "existing_sketch", "gradient_probe", "sklearn")
    paths = [Path(__file__), Path(__file__).with_name("gradient_probe.py")]
    before = sources(paths)
    payload = {
        "method": "2 warmups + 3 interleaved full fits; candidate internal tol=0.25 public, all original-input float64 quality; sklearn 1 thread",
        "source_before": before,
        "cases": [],
    }
    with threadpool_limits(limits=1):
        payload["component"] = validate_component()
        for case_name, seed in specs:
            base = next(c for c in CASES if c.name == case_name)
            case = replace(base, seed=seed)
            X, y, weights, ratio = dataset(case)
            samples = {v: [] for v in variants}
            details = {v: [] for v in variants}
            models = {v: [] for v in variants}
            for i in range(5):
                order = variants[i % 4 :] + variants[: i % 4]
                if i % 2:
                    order = order[::-1]
                for v in order:
                    model, elapsed, record = run_one(v, X, y, weights, case)
                    if i >= 2:
                        samples[v].append(elapsed * 1000)
                        details[v].append(record)
                        models[v].append(model)
            skq, skpred = independent_score(models["sklearn"][-1], X, y, weights, case.C, ratio)
            scored = {
                v: [
                    independent_score(
                        m, X, y, weights, case.C, ratio, (skq["objective_float64"], skpred)
                    )[0]
                    for m in ms
                ]
                for v, ms in models.items()
            }
            row = {
                "case": case.name,
                "seed": case.seed,
                "times_ms": samples,
                "median_ms": {v: statistics.median(a) for v, a in samples.items()},
                "details": details,
                "quality_each_fit": scored,
                "sklearn_score": skq,
            }
            payload["cases"].append(row)
            print(
                case.name,
                case.seed,
                {v: round(x, 2) for v, x in row["median_ms"].items()},
                "iterations",
                {v: details[v][-1]["n_iter"] for v in variants},
                "probe_score",
                scored["gradient_probe"][-1],
                flush=True,
            )
            Path("bench/sketch_speed/strict_results.json").write_text(
                json.dumps(payload, indent=2) + "\n"
            )
    payload["source_after"] = sources(paths)
    payload["source_integrity_pass"] = payload["source_after"] == before
    Path("bench/sketch_speed/strict_results.json").write_text(json.dumps(payload, indent=2) + "\n")


if __name__ == "__main__":
    main()
