from pathlib import Path
import shutil,subprocess,sysconfig
base=Path(__file__).resolve().parent
source=base.parent/'wide_tile/snapshot/src'
for label in ('baseline','candidate'):
 dest=base/label
 if dest.exists(): shutil.rmtree(dest)
 shutil.copytree(source,dest,ignore=shutil.ignore_patterns('__pycache__'))
def edit(path, old, new):
 s=path.read_text(); assert s.count(old)==1, (path,old,s.count(old)); path.write_text(s.replace(old,new))
p=base/'candidate/mlxlearn/_solvers/native_logistic_fused.py'
edit(p,'float accumulator[V];for(uint k=0;k<V;++k)accumulator[k]=0;\nfloat local_loss=0,local_bias=0;', 'float accumulator[V], accumulator2[V];for(uint k=0;k<V;++k){accumulator[k]=0;accumulator2[k]=0;}\nfloat local_loss=0,local_bias=0,local_bias2=0;')
edit(p,'float first_residual=0;', 'float first_residual=0, second_residual=0;')
edit(p,'if(lane==0){first_residual=sw[row]*sign*sigmoid_stable(sign*fma(alpha0,z,raw[row]));if(fs==0)local_bias+=first_residual;}', 'if(lane==0){first_residual=sw[row]*sign*sigmoid_stable(sign*fma(alpha0,z,raw[row]));second_residual=sw[row]*sign*sigmoid_stable(sign*fma(alpha0*0.5f,z,raw[row]));if(fs==0){local_bias+=first_residual;local_bias2+=second_residual;}}')
edit(p,'first_residual=simd_shuffle(first_residual,ushort(0));\n for(uint k=0;k<V;++k)accumulator[k]=fma(values[k],first_residual,accumulator[k]);', 'first_residual=simd_shuffle(first_residual,ushort(0));second_residual=simd_shuffle(second_residual,ushort(0));\n for(uint k=0;k<V;++k){accumulator[k]=fma(values[k],first_residual,accumulator[k]);accumulator2[k]=fma(values[k],second_residual,accumulator2[k]);}')
edit(p,'if(lane==0)scratch[sg*(CAND+1)+CAND]=local_bias;', 'if(lane==0){scratch[sg*(CAND+1)+CAND]=local_bias;}')
old='if(lane==0 && P>D){float total=0;for(uint s=0;s<GROUPS;++s)total+=scratch[s*(CAND+1)+CAND];gradient_parts[ulong(group)*P+D]=total;}'
# Keep original bias first, then store second in scratch after loss output.
edit(p,old,old)
old='if(rs==0){for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;if(j<D){float total=0;for(uint r=0;r<ROW_GROUPS;++r)total+=scratch[r*DPAD+j];gradient_parts[ulong(group)*P+j]=total;}}}'
new=old+'''\nthreadgroup_barrier(mem_flags::mem_threadgroup);
for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;scratch[rs*DPAD+j]=accumulator2[k];}
threadgroup_barrier(mem_flags::mem_threadgroup);
if(rs==0){for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;if(j<D){float total=0;for(uint r=0;r<ROW_GROUPS;++r)total+=scratch[r*DPAD+j];gradient_parts[ulong(B)*P+ulong(group)*P+j]=total;}}}
threadgroup_barrier(mem_flags::mem_threadgroup);
if(lane==0)scratch[sg]=local_bias2;
threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==0 && lane==0 && P>D){float total=0;for(uint s=0;s<GROUPS;++s)total+=scratch[s];gradient_parts[ulong(B)*P+ulong(group)*P+D]=total;}'''
edit(p,old,new)
p=base/'candidate/mlxlearn/_solvers/native_logistic.py'
old='if(isfinite(df) && df<=c1*a*stats[5] && stats[5]<0){alpha=a;accepted_diff=df;accepted=true;break;}'
new='if(isfinite(df) && df<=c1*a*stats[5] && stats[5]<0 && (!accepted || df<accepted_diff)){alpha=a;accepted_diff=df;accepted=true;}'
edit(p,old,new)
p=base/'candidate/mlxlearn/_solvers/native_command.py'
edit(p,'float value=0, loss=0;\n for(uint i=sg;i<B;i+=4){\n   if(col<P)value+=parts[ulong(i)*P+col];', 'float value=0, value2=0, loss=0;\n for(uint i=sg;i<B;i+=4){\n   if(col<P){value+=parts[ulong(i)*P+col];value2+=parts[ulong(B)*P+ulong(i)*P+col];}')
edit(p,'threadgroup float shared[128], shared_loss[128];\n shared[t]=value;shared_loss[t]=loss;', 'threadgroup float shared[128], shared2[128], shared_loss[128];\n shared[t]=value;shared2[t]=value2;shared_loss[t]=loss;')
edit(p,'if(col<P)gradient[col]=(shared[t]+shared[t+32]+shared[t+64]+shared[t+96])/denom;', 'if(col<P){gradient[col]=(shared[t]+shared[t+32]+shared[t+64]+shared[t+96])/denom;gradient[P+col]=(shared2[t]+shared2[t+32]+shared2[t+64]+shared2[t+96])/denom;}')
edit(p,'active[0]=meta[1]==0 && meta[8]!=alpha;', 'active[0]=meta[1]==0 && meta[8]!=alpha && meta[8]!=alpha*0.5f;')
edit(p,'if(t<P){float value=first[t];\n  if(meta[1]==0 && meta[8]!=alpha){', 'if(t<P){float value=first[meta[8]==alpha*0.5f ? P+t : t];\n  if(meta[1]==0 && meta[8]!=alpha && meta[8]!=alpha*0.5f){')
p=base/'candidate/mlxlearn/_solvers/_metal_loop.mm'
edit(p,'MLXLearnRetainTestBufferV4','MLXLearnRetainTestBufferDual') if p.read_text().count('MLXLearnRetainTestBufferV4')==1 else p.write_text(p.read_text().replace('MLXLearnRetainTestBufferV4','MLXLearnRetainTestBufferDual'))
edit(p,'+size_t(p)*12+48+size_t(n)*8+size_t(8)*blocks*4+size_t(blocks)*p*4', '+size_t(p)*16+48+size_t(n)*8+size_t(8)*blocks*4+size_t(blocks)*p*8')
edit(p,'auto gradparts=alloc(size_t(blocks)*p*4), diffs=alloc(32);', 'auto gradparts=alloc(size_t(blocks)*p*8), diffs=alloc(32);')
edit(p,'auto first=alloc(size_t(p)*4), residual=alloc(size_t(n)*4);', 'auto first=alloc(size_t(p)*8), residual=alloc(size_t(n)*4);')
edit(p,'mincurv=float(mincurv_d),alpha=1;', 'mincurv=float(mincurv_d),alpha=2;')
output=base/'candidate/mlxlearn/_solvers/_metal_loop.abi3.so'
cmd=['clang++','-O3','-shared','-fobjc-arc','-std=c++17','-undefined','dynamic_lookup','-framework','Foundation','-framework','Metal',f'-I{sysconfig.get_path("include")}',str(p),'-o',str(output)]
subprocess.run(cmd,check=True)
print('prepared',output)
