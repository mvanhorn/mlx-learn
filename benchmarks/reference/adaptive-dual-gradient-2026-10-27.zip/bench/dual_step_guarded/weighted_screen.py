"""Screen adaptive dual-gradient steps against guarded weighted baseline."""
import gc,hashlib,json,statistics,time,warnings
import numpy as np
import mlx.core as mx
from threadpoolctl import threadpool_limits
from panel import base,Case,dataset,independent_score,SK,native_command,proxies,candidate_source,reference_source,tuning_context,LogisticRegression
from mlxlearn_device import _logistic as device
from sklearn.exceptions import ConvergenceWarning

cases=[('ordinary',41),('ordinary',83),('unbalanced',41),('unbalanced',83),('rare',2027),('effective',83),('shifted',41),('rank',41),('ill',83)]
variants=('baseline','candidate','baseline_sketch','candidate_sketch','baseline_device','candidate_device','baseline_device_sketch','candidate_device_sketch')
def fit(v,X,y,w,case,Xm,ym,wm):
 candidate=v.startswith('candidate');sketch=v.endswith('sketch');dv='device' in v
 key=('candidate' if candidate else 'baseline')+('_sketch' if not dv and sketch else '')
 if dv:
  device.source_for=candidate_source if candidate else reference_source;device.metal_loop=proxies[key];proxies[key].calls.clear()
 else:
  native_command._source=candidate_source if candidate else reference_source;native_command._metal_loop=proxies[key];proxies[key].calls.clear()
 with warnings.catch_warnings(record=True) as caught:
  warnings.simplefilter('always');mx.synchronize();enabled=gc.isenabled();gc.disable()
  try:
   start=time.perf_counter()
   if dv: m=device.fit_logistic(Xm,ym,sample_weight=wm,C=case.C,tol=1e-4,max_iter=200,sketch_size=4 if sketch else 0)
   else:
    with tuning_context(force_backend='mlx',lbfgs_sketch_size=4 if sketch else 0):m=LogisticRegression(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=w)
   mx.synchronize();elapsed=1000*(time.perf_counter()-start)
  finally:
   if enabled:gc.enable()
  details={'warnings':[{'category':type(z.message).__name__,'message':str(z.message)} for z in caught], 'n_iter':m.n_iter if dv else m.n_iter_.tolist(),'converged':m.converged if dv else True,'native_calls':proxies[key].calls.copy()}
  return m,elapsed,details

def hashes():
 paths=[q for d in [base/'candidate',base/'baseline'] for q in d.rglob('*') if q.is_file() and '__pycache__' not in q.parts]
 paths += [base/'prepare.py',base/'panel.py',base/'weighted_screen.py']
 return {str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in paths}
def main():
 out={'source_before':hashes(),'cases':[],'method':'rotated complete fits, 1 warmup + 5 timed fits; resident-device upload excluded; tight sklearn reference independently audited'}
 with threadpool_limits(limits=1):
  for kind,seed in cases:
   case=Case(kind,20000,1024,seed=seed,weighted=True,shifted=kind=='shifted',rank_deficient=kind=='rank',ill_conditioned=kind=='ill',C=1e6 if kind=='rank' else 1)
   X,y,w,ratio=dataset(case)
   if kind=='unbalanced': y=(X[:,0]>np.quantile(X[:,0],.90)).astype(np.int32)
   if kind=='rare': y=(X[:,0]>np.quantile(X[:,0],.98)).astype(np.int32)
   if kind=='effective': w=w*np.where(y==1,.1,2.)
   Xm=mx.array(X);ym=mx.array(y);wm=mx.array(w,dtype=mx.float32);mx.eval(Xm,ym,wm);mx.synchronize()
   samples={v:[] for v in variants};models={v:[] for v in variants};details={v:[] for v in variants}
   for rep in range(6):
    seq=variants[rep%len(variants):]+variants[:rep%len(variants)]
    if rep%2:seq=seq[::-1]
    for v in seq:
     model,t,d=fit(v,X,y,w,case,Xm,ym,wm)
     if rep: samples[v].append(t);models[v].append(model);details[v].append(d)
   scores={v:[independent_score(m,X,y,w,case.C,ratio)[0] for m in group] for v,group in models.items()}
   center=X.mean(axis=0,dtype=np.float64); XX=np.asarray(X,dtype=np.float64)-center
   with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always');ref=SK(C=case.C,tol=1e-9,max_iter=3000).fit(XX,y,sample_weight=w)
   ref.intercept_=ref.intercept_-ref.coef_@center; refscore,_=independent_score(ref,X,y,w,case.C,ratio);del XX
   refvalid=refscore['gradient_max_abs_float64']<=1e-7 and not any(issubclass(z.category,ConvergenceWarning) for z in caught)
   failures=[]
   for v in variants:
    if not v.startswith('candidate'):continue
    prior=v.replace('candidate','baseline',1)
    for i,(a,b,d) in enumerate(zip(scores[v],scores[prior],details[v])):
     gap=(a['objective_float64']-b['objective_float64'])/abs(b['objective_float64'])
     refgap=(a['objective_float64']-refscore['objective_float64'])/abs(refscore['objective_float64'])
     if gap>1e-5 or (refvalid and refgap>1e-5) or a['gradient_max_abs_float64']>1e-4 or d['warnings'] or not d['native_calls'] or not d['converged']:
      failures.append({'variant':v,'fit':i,'gap':gap,'reference_gap':refgap,'detail':d,'score':a})
   row={'case':kind,'seed':seed,'median_ms':{v:statistics.median(z) for v,z in samples.items()},'samples':samples,'scores':scores,'details':details,'reference':refscore,'reference_valid':refvalid,'reference_warnings':[str(z.message) for z in caught],'failures':failures}
   out['cases'].append(row);print(kind,seed,row['median_ms'],'refvalid',refvalid,'failures',failures[:2],flush=True)
   (base/'weighted-screen.json').write_text(json.dumps(out,indent=2)+'\n')
 out['source_after']=hashes();out['source_integrity']=out['source_before']==out['source_after'];(base/'weighted-screen.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
