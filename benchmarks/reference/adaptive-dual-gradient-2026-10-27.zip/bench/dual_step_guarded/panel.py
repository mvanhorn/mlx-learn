"""Exploratory adaptive two-gradient line search; isolated frozen package."""
import ast, gc, hashlib, importlib.util, json, statistics, sys, time, warnings
from pathlib import Path
base=Path(__file__).resolve().parent
sys.path.insert(0,str(base.parents[1]))
sys.path.insert(0,str(base/'baseline'))
import mlx.core as mx
import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case,dataset,independent_score
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression

p=base/'candidate/mlxlearn/_solvers/native_command.py'
tree=ast.parse(p.read_text()); names={'_kernel_source','_kernel','_source'}
nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names]
namespace={'Path':Path,'ast':ast,'functools':__import__('functools'),'__file__':str(p)}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(p),'exec'),namespace)
candidate_source=namespace['_source']; reference_source=native_command._source
spec=importlib.util.spec_from_file_location('_dual._metal_loop', base/'candidate/mlxlearn/_solvers/_metal_loop.abi3.so')
candidate_extension=importlib.util.module_from_spec(spec); spec.loader.exec_module(candidate_extension)
reference_extension=native_command._metal_loop
class Proxy:
 def __init__(self,mod): self.mod=mod; self.calls=[]
 def run(self,*args):
  result=self.mod.run(*args);self.calls.append({'iterations':result[1],'status':result[2]});return result
proxies={k:Proxy(v) for k,v in [('baseline',reference_extension),('candidate',candidate_extension),('baseline_sketch',reference_extension),('candidate_sketch',candidate_extension)]}
cases=[Case('wide_1024',20000,1024,seed=41),Case('wide_1024_seed83',20000,1024,seed=83),Case('wide_4096',20000,4096,seed=41),Case('weighted_ill_1024',20000,1024,seed=83,weighted=True,ill_conditioned=True),Case('shifted_1024',20000,1024,seed=41,shifted=True),Case('rank_1024',20000,1024,seed=41,rank_deficient=True,C=1e6),Case('unbalanced_1024',20000,1024,seed=41,weighted=True),Case('unbalanced_1024_seed83',20000,1024,seed=83,weighted=True),Case('unbalanced_1024_seed2027',20000,1024,seed=2027,weighted=True)]
def hashes():
 paths=[q for d in [base/'candidate',base/'baseline'] for q in d.rglob('*') if q.is_file() and '__pycache__' not in q.parts]
 paths += [base/'prepare.py',base/'panel.py']
 return {str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in paths}
def fit(v,X,y,w,case):
 native_command._source=candidate_source if v.startswith('candidate') else reference_source
 native_command._metal_loop=proxies[v];proxies[v].calls.clear()
 with warnings.catch_warnings(record=True) as caught,tuning_context(force_backend='mlx',lbfgs_sketch_size=4 if v.endswith('sketch') else 0):
  warnings.simplefilter('always');mx.synchronize(); enabled=gc.isenabled();gc.disable()
  try:
   start=time.perf_counter();m=LogisticRegression(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=w);mx.synchronize();elapsed=1000*(time.perf_counter()-start)
  finally:
   if enabled:gc.enable()
 return m,elapsed,{'warnings':[{'category':z.category.__name__,'message':str(z.message)} for z in caught], 'n_iter':m.n_iter_.tolist(),'native_calls':proxies[v].calls.copy()}
def main():
 output={'source_hash_before':hashes(),'method':'interleaved fresh fits, 2 warmups + 6 timings; float64 original objective and gradient; frozen initial binary only','cases':[]}
 try:
  with threadpool_limits(limits=1):
   for case in cases:
    X,y,w,ratio=dataset(case)
    if case.name.startswith('unbalanced_1024'): y=(X[:,0]>np.quantile(X[:,0],.90)).astype(np.int32)
    samples={k:[] for k in proxies};models={k:[] for k in proxies};details={k:[] for k in proxies}
    for rep in range(8):
     order=('baseline','candidate','baseline_sketch','candidate_sketch') if rep%2==0 else ('candidate_sketch','baseline_sketch','candidate','baseline')
     for v in order:
      m,t,d=fit(v,X,y,w,case)
      if rep>=2:samples[v].append(t);models[v].append(m);details[v].append(d)
    scores={v:[independent_score(m,X,y,w,case.C,ratio)[0] for m in group] for v,group in models.items()}
    failures=[]
    center=X.mean(axis=0,dtype=np.float64); refX=np.asarray(X,dtype=np.float64)-center
    with warnings.catch_warnings(record=True) as refwarn:
     warnings.simplefilter('always'); ref=SK(C=case.C,tol=1e-9,max_iter=3000).fit(refX,y,sample_weight=w)
    ref.intercept_=ref.intercept_-ref.coef_@center
    reference,_=independent_score(ref,X,y,w,case.C,ratio)
    del refX
    if reference['gradient_max_abs_float64']>1e-7 or refwarn:
     failures.append({'reference_invalid':reference,'warnings':[str(z.message) for z in refwarn]})
    for variant, prior in (('candidate','baseline'),('candidate_sketch','baseline_sketch')):
     for i,(x,b,d) in enumerate(zip(scores[variant],scores[prior],details[variant])):
      gap=(x['objective_float64']-b['objective_float64'])/abs(b['objective_float64'])
      tight_gap=(x['objective_float64']-reference['objective_float64'])/abs(reference['objective_float64'])
      if gap>1e-5 or tight_gap>1e-5 or x['gradient_max_abs_float64']>1e-4 or d['warnings'] or not d['native_calls']:
       failures.append({'variant':variant,'fit':i,'gap':gap,'tight_gap':tight_gap,'gradient':x['gradient_max_abs_float64'],'detail':d})
    row={'case':case.name,'median_ms':{k:statistics.median(v) for k,v in samples.items()},'samples':samples,'quality':scores,'tight_reference':reference,'details':details,'failures':failures}
    output['cases'].append(row);print(row['case'],row['median_ms'],'failures',failures[:2],flush=True)
    (base/'results.json').write_text(json.dumps(output,indent=2)+'\n')
 finally:
  native_command._source=reference_source;native_command._metal_loop=reference_extension
 output['source_hash_after']=hashes();output['source_integrity_pass']=output['source_hash_after']==output['source_hash_before']
 (base/'results.json').write_text(json.dumps(output,indent=2)+'\n')
if __name__=='__main__':main()
