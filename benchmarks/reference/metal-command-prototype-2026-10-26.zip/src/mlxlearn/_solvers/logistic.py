"""The penalized logistic objective and its gradient, in MLX.

Same contract as every solver here: arrays and a frozen :class:`LogisticConfig`
in, a frozen :class:`LogisticSolution` out. No estimator, no scikit-learn import,
no global configuration.

The objective is scikit-learn's, exactly
------------------------------------------
For weights ``W`` (the intercept excluded) and per-sample weights ``sw`` summing to
``sw_sum``::

    J(W, b) = (1 / sw_sum) * Σᵢ swᵢ · lossᵢ  +  0.5 · (1 / (C · sw_sum)) · ‖W‖²

That is scikit-learn's ``LinearModelLoss`` with ``l2_reg_strength = 1/(C·sw_sum)``,
where ``sw_sum`` is ``n_samples`` when unweighted and the sum of the sample weights
*after* class weights have been folded in otherwise. The intercept is never
penalized. Matching this expression exactly is what makes objective-value parity a
meaningful assertion: two solvers minimizing the same function must agree on the
value at their respective solutions even when they disagree on the argument.

``lossᵢ`` is the negative log-likelihood — ``HalfBinomialLoss`` and
``HalfMultinomialLoss`` in scikit-learn's vocabulary::

    binary       log(1 + exp(raw)) − y·raw          y ∈ {0, 1}
    multinomial  logsumexp(raw) − raw[y]

Numerical stability is not optional here
----------------------------------------
Both forms above are written with ``logaddexp``/``logsumexp`` and never exponentiate
a raw score. The ancestor computed ``sigmoid(clip(score, -80, 80))`` and then
``log(clip(p, 1e-12, 1))``; in float32 a sigmoid saturates to exactly 1.0 by
``raw ≈ 17``, so every confidently classified sample contributed the same floored
``−log(1e-12) = 27.63`` and the loss surface acquired flat plateaus that no line
search can descend. Worse, its *gradient* was the exact derivative of the
*unclipped* objective, so the value and the slope described different functions —
which is what produced line-search failures reported as ordinary non-convergence.

Here the value and the gradient are derived from the same expression, and
``p − y`` is obtained from ``mx.sigmoid`` / ``exp(raw − logsumexp(raw))``, both of
which are the exact derivatives of the stable loss forms.

Layout
------
The objective parameter is a single ``(n_targets, n_features + fit_intercept)``
MLX array. Binary GPU fits use native Metal kernels with batched Armijo search
and device-resident optimizer history; the generic fused optimizer handles the
remaining cases with host strong-Wolfe control. Both verify the direct objective
and gradient at the returned parameters. ``n_targets`` is 1 for binary
— scikit-learn fits a single weight vector for the positive class ``classes_[1]``,
not a two-row softmax — and ``n_classes`` otherwise.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import mlx.core as mx
import numpy as np

from .._common.arrays import NUMPY_FLOAT
from .._common.device import use_device
from .fused_lbfgs import minimize
from .lbfgs import LBFGSConfig

__all__ = [
    "LogisticConfig",
    "LogisticSolution",
    "solve_logistic",
    "reference_objective",
]


@dataclass(frozen=True, slots=True)
class LogisticConfig:
    """Problem-independent settings for one logistic fit.

    Parameters
    ----------
    C : float, default=1.0
        Inverse regularization strength, scikit-learn's meaning. ``math.inf``
        expresses an unpenalized fit, which is how scikit-learn itself encodes
        ``penalty=None``.
    fit_intercept : bool, default=True
        The intercept column is appended to the parameter array and excluded from
        the penalty.
    tol : float, default=1e-4
        Forwarded to L-BFGS as the tolerance on ``max|gradient|``.
    max_iter : int, default=100
    history_size : int, default=10
    max_line_search : int, default=32
    device : {"auto", "gpu", "cpu"}, default="auto"
        Passed straight to :func:`~mlxlearn._common.device.use_device`. Explicit,
        because a solver that reads global configuration cannot be tested in
        isolation.
    """

    C: float = 1.0
    fit_intercept: bool = True
    tol: float = 1e-4
    max_iter: int = 100
    history_size: int = 10
    max_line_search: int = 32
    device: str = "auto"

    def __post_init__(self) -> None:
        if not (self.C > 0.0):
            raise ValueError(f"C must be strictly positive, got {self.C!r}")
        if self.max_iter < 0:
            raise ValueError(f"max_iter must be non-negative, got {self.max_iter}")
        if self.tol < 0 or not math.isfinite(self.tol):
            raise ValueError(f"tol must be finite and non-negative, got {self.tol}")


@dataclass(frozen=True, slots=True)
class LogisticSolution:
    """Fitted coefficients and everything needed to explain the run.

    Attributes
    ----------
    coef : ndarray of shape (n_targets, n_features), float64
    intercept : ndarray of shape (n_targets,), float64
        Zeros when ``fit_intercept=False``, matching scikit-learn.
    n_iter : int
        Accepted L-BFGS steps.
    objective : float
        Penalized objective at the solution, as computed in float32.
    grad_max_abs : float
        ``max|gradient|`` at the solution — the quantity ``tol`` bounds.
    converged : bool
    stop_reason : str
        See :class:`~mlxlearn._solvers.lbfgs.LBFGSState`.
    """

    coef: np.ndarray
    intercept: np.ndarray
    n_iter: int
    objective: float
    grad_max_abs: float
    converged: bool
    stop_reason: str


def _l2_reg_strength(C: float, sw_sum: float) -> float:
    """``1/(C·sw_sum)``, with ``C = inf`` meaning "no penalty".

    scikit-learn's own ``penalty=None`` path sets ``C_ = np.inf`` and reuses the
    same expression, so this reproduces it rather than branching on a separate
    flag that could disagree with it.
    """
    if math.isinf(C):
        return 0.0
    return 1.0 / (C * sw_sum)


# --------------------------------------------------------------------- objectives

#: Partial sums brought back per objective evaluation instead of one total.
#:
#: The line search compares objective values, so the *resolution* of the returned
#: value sets how far the solver can descend before every candidate step looks
#: like a tie. A float32 total of ``n`` log-loss terms has an absolute error of
#: order ``eps·Σloss``; divided by ``sw_sum`` that leaves roughly ``5e-8`` of
#: resolution on a mean loss of ``0.54``, and the last few L-BFGS iterations
#: — the ones that take ``max|g|`` from ``2e-4`` down past ``1e-4`` — move the
#: objective by about ``1e-8``. Measured: the solver stalled at ``max|g| = 1.9e-4``
#: after 20 iterations and then spent 80 more taking null steps.
#:
#: Reducing to this many partial sums on the device and finishing the addition in
#: float64 on the host cuts that error by ``√n_blocks``, to about ``1e-9``, which
#: is enough to reach scikit-learn's own ``gtol``. It costs one 4 KiB transfer per
#: evaluation — the same synchronization that reading the scalar already required.
_SUM_BLOCKS = 1024


def _blocked_sum(mx, values):
    """Reduce ``values`` to at most ``_SUM_BLOCKS`` partial sums, on the device."""
    n = values.shape[0]
    if n <= _SUM_BLOCKS:
        return values
    chunk = -(-n // _SUM_BLOCKS)
    padding = chunk * _SUM_BLOCKS - n
    if padding:
        # Zero padding is exact and cannot shift the total.
        values = mx.pad(values, (0, padding))
    return mx.sum(mx.reshape(values, (_SUM_BLOCKS, chunk)), axis=1)


def _total(parts, penalty, sw_sum: float) -> float:
    """Finish the reduction in float64 on the host. Assumes both are evaluated."""
    value = float(np.asarray(parts).astype(np.float64).sum() / sw_sum)
    return value if penalty is None else value + float(penalty)


@mx.compile
def _binary_arrays(theta, X, y, sw, sw_sum, l2, fit_intercept, penalized, direction):
    """Array-only loss, gradient and slope, with fusible regions compiled by MLX."""
    n_features = X.shape[1]
    w = theta[0, :n_features]
    raw = X @ w
    if fit_intercept:
        raw = raw + theta[0, n_features]

    # The signed-logit form avoids subtracting raw from logaddexp(raw) or
    # subtracting 1 from a saturated sigmoid for positive-class examples.
    sign = 1.0 - 2.0 * y
    signed_raw = sign * raw
    loss = mx.logaddexp(mx.zeros_like(signed_raw), signed_raw)
    residual = sign * mx.sigmoid(signed_raw)
    if sw is not None:
        loss = loss * sw
        residual = residual * sw

    grad_w = (residual @ X) / sw_sum
    if penalized:
        grad_w = grad_w + l2 * w
    if fit_intercept:
        grad_b = mx.sum(residual) / sw_sum
        grad_w = mx.concatenate([grad_w, mx.reshape(grad_b, (1,))])
    grad = mx.reshape(grad_w, theta.shape)
    parts = _blocked_sum(mx, loss)
    # The absent penalty must not square large finite weights: inf * 0 is NaN.
    # l2 is an explicit zero array input in the unpenalized graph.
    penalty = mx.sum(w * w) * (0.5 * l2) if penalized else l2
    slope = mx.sum(grad * direction)
    return parts, penalty, grad, slope


@mx.compile
def _multinomial_arrays(
    theta, X, y_index, y_onehot, sw, sw_sum, l2, fit_intercept, penalized, direction
):
    n_features = X.shape[1]
    W = theta[:, :n_features]
    raw = X @ W.T
    if fit_intercept:
        raw = raw + theta[:, n_features]

    # Keep logits shifted through the subtraction. Re-adding the row maximum
    # before subtracting the correct logit loses small losses in float32.
    shifted = raw - mx.max(raw, axis=1, keepdims=True)
    log_norm = mx.logsumexp(shifted, axis=1)
    correct = mx.take_along_axis(shifted, y_index, axis=1)[:, 0]
    loss = log_norm - correct
    residual = mx.exp(shifted - mx.reshape(log_norm, (-1, 1))) - y_onehot
    if sw is not None:
        loss = loss * sw
        residual = residual * mx.reshape(sw, (-1, 1))

    grad = (residual.T @ X) / sw_sum
    if penalized:
        grad = grad + l2 * W
    if fit_intercept:
        grad_b = mx.sum(residual, axis=0) / sw_sum
        grad = mx.concatenate([grad, mx.reshape(grad_b, (-1, 1))], axis=1)
    parts = _blocked_sum(mx, loss)
    penalty = mx.sum(W * W) * (0.5 * l2) if penalized else l2
    slope = mx.sum(grad * direction)
    return parts, penalty, grad, slope


def _evaluated_objective(compute, sw_sum):
    """Host precision boundary shared by ordinary and line-search evaluations."""

    def evaluate(theta, direction):
        if direction is None:
            # MLX 0.32 cannot compile a standalone constant output. Supplying a
            # zero direction also keeps ordinary/probe evaluations in one graph.
            direction = mx.zeros_like(theta)
        parts, penalty, grad, slope = compute(theta, direction)
        # One evaluation boundary for the loss, gradient and directional derivative.
        mx.eval(parts, penalty, grad, slope)
        return _total(parts, penalty, sw_sum), grad, float(slope)

    def fun(theta):
        value, gradient, _ = evaluate(theta, None)
        return value, gradient

    fun.value_gradient_slope = evaluate
    return fun


def _binary_objective(mx, X, y, sw, sw_sum, l2, fit_intercept, n_features):
    scale, penalty = mx.array(sw_sum, dtype=X.dtype), mx.array(l2, dtype=X.dtype)
    return _evaluated_objective(
        lambda theta, direction: _binary_arrays(
            theta, X, y, sw, scale, penalty, fit_intercept, bool(l2), direction
        ),
        sw_sum,
    )


@mx.compile
def _native_binary_arrays(theta, X, y, sw, denominator, l2, fit_intercept):
    from .native_logistic import direct_arrays

    loss, penalty, gradient = direct_arrays(
        theta, X, y, sw, denominator, l2, fit_intercept
    )
    return _blocked_sum(mx, loss), penalty, gradient


def _native_binary_objective(X, y, sw, sw_sum, l2, fit_intercept):
    """Direct native evaluation, independent of the optimizer's cached logits."""
    denominator = mx.array(sw_sum, dtype=X.dtype)

    def fun(theta):
        parts, penalty, gradient = _native_binary_arrays(
            theta, X, y, sw, denominator, l2, fit_intercept
        )
        mx.eval(parts, penalty, gradient)
        return _total(parts, penalty, sw_sum), gradient

    return fun


@mx.compile
def _center_gpu(X):
    """A shifted, scaled mean avoids overflow and preserves constant columns.

    Quarter-sized differences are bounded by half the float32 range. Scale
    before summing, and restore the actual applied shift with the fitted bias.
    """
    anchor = X[0] * 0.25
    correction = mx.sum((X * 0.25 - anchor) * (1.0 / X.shape[0]), axis=0)
    bound = float(np.finfo(np.float32).max) * 0.25
    center = mx.clip(anchor + correction, -bound, bound) * 4.0
    return X - center, center


def _multinomial_objective(
    mx, X, y_index, y_onehot, sw, sw_sum, l2, fit_intercept, n_features
):
    scale, penalty = mx.array(sw_sum, dtype=X.dtype), mx.array(l2, dtype=X.dtype)
    return _evaluated_objective(
        lambda theta, direction: _multinomial_arrays(
            theta, X, y_index, y_onehot, sw, scale, penalty, fit_intercept, bool(l2), direction
        ),
        sw_sum,
    )


# ------------------------------------------------------------------------- solve


def _use_native_solver(config, n_targets, n_features):
    """Bound the register workspace of the binary Metal optimizer.

    This is a numerical implementation choice within the GPU backend. Device
    availability is resolved by ``use_device`` before this predicate is used.
    The generic fused solver handles multinomial, CPU, and larger workspaces.
    """
    return (
        config.device != "cpu"
        and n_targets == 1
        and n_features <= 4096
        and 1 <= config.history_size <= 32
        and 1 <= config.max_line_search <= 32
        # The device status vector uses float32 counters, exact through 2**24.
        and (config.max_iter + 1) * config.max_line_search <= 2**24
    )


def solve_logistic(
    X: np.ndarray,
    y: np.ndarray,
    *,
    n_classes: int,
    sample_weight: np.ndarray | None = None,
    config: LogisticConfig,
    X_device=None,
    X_center=None,
    initial_parts=None,
) -> LogisticSolution:
    """Fit penalized logistic regression by native or fused MLX L-BFGS.

    Parameters
    ----------
    X : ndarray of shape (n_samples, n_features)
        Dense and finite. Converted to float32 for computation.
    y : ndarray of shape (n_samples,)
        Integer class codes in ``[0, n_classes)``. Encoding labels is the caller's
        job; this function never sees the original labels.
    n_classes : int
        Two selects the binary objective — one weight vector for code 1 — and more
        selects the unconstrained multinomial objective.
    sample_weight : ndarray of shape (n_samples,), optional
        float64, non-negative, with any class weights already folded in. ``None``
        means unweighted, and takes a code path that never multiplies by ones.
    config : LogisticConfig
    X_device : mx.array, optional
        An already validated, privately owned float32 copy of ``X``. The
        estimator supplies this to reuse GPU validation and input preparation.
    X_center : mx.array, optional
        When supplied, ``X_device`` already contains ``X - X_center``. The
        exact applied shift is reused to restore the fitted intercept.
    initial_parts : mx.array, optional
        Native binary gradient/curvature partials accumulated while preparing
        ``X_device``. They use the same row blocks as the native initialization.

    Returns
    -------
    LogisticSolution

    Notes
    -----
    The starting point is always zero. There is no warm start and no cache: the
    ancestor's continuation cache was keyed on the *address* of the training array
    and enabled by default, which made ``fit`` depend on what had been fitted
    earlier in the same process. A fit here is a pure function of its arguments.
    """
    import mlx.core as mx

    if n_classes < 2:
        raise ValueError(f"n_classes must be at least 2, got {n_classes}")

    X_host = np.ascontiguousarray(X, dtype=NUMPY_FLOAT)
    n_samples, n_features = X_host.shape
    y_host = np.asarray(y)

    # Centering. With an intercept this is exact, not an approximation:
    #     w·(x − μ) + b′  ≡  w·x + (b′ − w·μ)
    # so the model is unchanged and the intercept is corrected afterwards.
    #
    # Without it, features carrying a large constant offset destroy the fit in
    # float32. Measured on 2000 x 8 with an offset of 1e4 added to every feature:
    # the solver stopped after 3 iterations with an all-zero coefficient vector,
    # an objective of exactly log 2 — the null model — and 0.50 accuracy, where
    # scikit-learn reached 0.62. The gradient of the offset-dominated design is
    # numerically parallel to the constant direction, so the first step goes
    # almost entirely into the intercept and the line search then cannot find a
    # decrease. The offset also costs precision directly: at 1e4, float32 spacing
    # is ~1e-3, so the informative part of each feature is quantized away.
    #
    # Centering cannot be applied when fit_intercept is False: there is no
    # intercept to absorb the shift, so the shifted problem is a *different*
    # problem, and silently solving it would be wrong. That case keeps the raw
    # design and the docstring says so.
    center = None
    if y_host.shape != (n_samples,):
        raise ValueError(
            f"y must have shape ({n_samples},) to match X, got {y_host.shape}"
        )

    # Exact unit weights are the unweighted problem. Keep the same compiled
    # graph so fusion cannot introduce different rounding through a multiply
    # by one; class weights have already been folded in by the estimator.
    if sample_weight is not None and np.all(np.asarray(sample_weight) == 1.0):
        sample_weight = None
    if sample_weight is None:
        sw_sum = float(n_samples)
    else:
        sw_sum = float(np.sum(np.asarray(sample_weight, dtype=np.float64)))
        if sw_sum <= 0.0:
            # The wording matters: scikit-learn 1.9's
            # check_all_zero_sample_weights_error matches r"weight.*zero|zero.*weight",
            # and every estimator is expected to say so recognizably.
            raise ValueError(
                "Sample weights sum to zero: every sample weight is zero, so there "
                "is nothing to fit."
            )

    l2 = _l2_reg_strength(config.C, sw_sum)
    n_targets = 1 if n_classes == 2 else n_classes
    n_columns = n_features + int(config.fit_intercept)

    with use_device(config.device) as device:
        if X_device is not None and (
            X_device.shape != X_host.shape or X_device.dtype != mx.float32
        ):
            raise ValueError("X_device must match X's shape and have float32 dtype")
        Xm = mx.array(X_host, dtype=mx.float32) if X_device is None else X_device
        if X_center is not None:
            if (
                X_device is None
                or not config.fit_intercept
                or X_center.shape != (n_features,)
                or X_center.dtype != mx.float32
            ):
                raise ValueError("X_center requires centered X_device and a float32 feature vector")
            center = X_center
        elif config.fit_intercept and n_samples > 0:
            if device == "gpu":
                Xm, center = _center_gpu(Xm)
            else:
                center = mx.array(X_host.mean(axis=0, dtype=np.float64).astype(NUMPY_FLOAT))
                Xm = Xm - center
        swm = (
            None
            if sample_weight is None
            else mx.array(np.asarray(sample_weight, dtype=NUMPY_FLOAT), dtype=mx.float32)
        )

        native = device == "gpu" and _use_native_solver(config, n_targets, n_features)
        if initial_parts is not None and not native:
            raise ValueError("initial_parts requires the native binary GPU solver")
        if native:
            fun = _native_binary_objective(
                Xm, mx.array(y_host, dtype=mx.float32), swm, sw_sum, l2, config.fit_intercept
            )
        elif n_targets == 1:
            fun = _binary_objective(
                mx,
                Xm,
                mx.array(y_host.astype(NUMPY_FLOAT), dtype=mx.float32),
                swm,
                sw_sum,
                l2,
                config.fit_intercept,
                n_features,
            )
        else:
            codes = y_host.astype(np.int32)
            fun = _multinomial_objective(
                mx,
                Xm,
                mx.array(codes.reshape(-1, 1), dtype=mx.int32),
                mx.array(
                    np.eye(n_classes, dtype=NUMPY_FLOAT)[codes], dtype=mx.float32
                ),
                swm,
                sw_sum,
                l2,
                config.fit_intercept,
                n_features,
            )

        optimizer_config = LBFGSConfig(
            max_iter=config.max_iter,
            tol=config.tol,
            history_size=config.history_size,
            max_line_search=config.max_line_search,
        )
        if native:
            from .native_logistic import minimize_binary

            state = minimize_binary(
                Xm,
                mx.array(y_host, dtype=mx.float32),
                swm,
                sw_sum,
                l2,
                config.fit_intercept,
                optimizer_config,
                fun,
                initial_parts=initial_parts,
            )
        else:
            theta0 = mx.zeros((n_targets, n_columns), dtype=mx.float32)
            state = minimize(fun, theta0, optimizer_config)
        mx.eval(state.x)
        theta = np.asarray(state.x, dtype=NUMPY_FLOAT).astype(np.float64)
        if center is not None:
            center = np.asarray(center).astype(np.float64)

    coef = np.ascontiguousarray(theta[:, :n_features])
    intercept = (
        np.ascontiguousarray(theta[:, n_features])
        if config.fit_intercept
        else np.zeros(n_targets, dtype=np.float64)
    )
    if center is not None:
        # Undo the centering exactly: b = b′ − w·μ, in float64.
        intercept = intercept - coef @ center
    return LogisticSolution(
        coef=coef,
        intercept=intercept,
        n_iter=state.n_iter,
        objective=state.objective,
        grad_max_abs=state.grad_max_abs,
        converged=state.converged,
        stop_reason=state.stop_reason,
    )


# --------------------------------------------------------------------- reference


def reference_objective(
    coef: np.ndarray,
    intercept: np.ndarray,
    X: np.ndarray,
    y: np.ndarray,
    *,
    n_classes: int,
    C: float = 1.0,
    sample_weight: np.ndarray | None = None,
) -> float:
    """The same objective in float64 NumPy, for parity assertions.

    ``docs/fp32_policy.md`` §3 makes the objective value the *strong* parity
    assertion and the coefficients the weak one, because two solvers can reach
    materially different coefficients that are equally optimal on an
    ill-conditioned problem. That assertion is only meaningful if both coefficient
    sets are scored by one function at one precision — this one.

    Parameters mirror :func:`solve_logistic`; ``coef`` is ``(n_targets, n_features)``
    with ``n_targets == 1`` for binary.

    Examples
    --------
    >>> import numpy as np
    >>> from mlxlearn._solvers.logistic import reference_objective
    >>> X = np.array([[0.0], [1.0], [2.0], [3.0]])
    >>> y = np.array([0, 0, 1, 1])
    >>> float(round(reference_objective(np.zeros((1, 1)), np.zeros(1), X, y,
    ...                                 n_classes=2, C=1.0), 12))
    0.69314718056
    """
    Xd = np.asarray(X, dtype=np.float64)
    codes = np.asarray(y).astype(np.int64)
    W = np.atleast_2d(np.asarray(coef, dtype=np.float64))
    b = np.asarray(intercept, dtype=np.float64).ravel()

    n_samples = Xd.shape[0]
    if sample_weight is None:
        sw = None
        sw_sum = float(n_samples)
    else:
        sw = np.asarray(sample_weight, dtype=np.float64)
        sw_sum = float(sw.sum())

    raw = Xd @ W.T + b
    if n_classes == 2:
        score = raw[:, 0]
        target = codes.astype(np.float64)
        loss = np.logaddexp(0.0, score) - target * score
    else:
        shift = raw.max(axis=1, keepdims=True)
        log_norm = shift[:, 0] + np.log(np.exp(raw - shift).sum(axis=1))
        loss = log_norm - raw[np.arange(n_samples), codes]

    weighted = loss if sw is None else loss * sw
    penalty = 0.0 if math.isinf(C) else 0.5 * float((W * W).sum()) / (C * sw_sum)
    return float(weighted.sum() / sw_sum + penalty)
