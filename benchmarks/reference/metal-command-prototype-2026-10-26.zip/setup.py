"""Build the optional Apple Silicon native Metal command-loop extension."""

from __future__ import annotations

import platform
import sys

from setuptools import Extension, setup
from setuptools.command.build_ext import build_ext


class MetalBuildExt(build_ext):
    """Teach distutils to compile Objective-C++ sources with clang."""

    def build_extensions(self):
        if ".mm" not in self.compiler.src_extensions:
            self.compiler.src_extensions.append(".mm")
        super().build_extensions()


extensions = []
options = {}
if sys.platform == "darwin" and platform.machine() == "arm64":
    extensions.append(
        Extension(
            "mlxlearn._solvers._metal_loop",
            ["src/mlxlearn/_solvers/_metal_loop.mm"],
            language="c++",
            define_macros=[("Py_LIMITED_API", "0x030A0000")],
            py_limited_api=True,
            extra_compile_args=["-std=c++17", "-fobjc-arc"],
            extra_link_args=["-framework", "Foundation", "-framework", "Metal"],
            optional=True,
        )
    )
    options["bdist_wheel"] = {"py_limited_api": "cp310"}

setup(ext_modules=extensions, cmdclass={"build_ext": MetalBuildExt}, options=options)
