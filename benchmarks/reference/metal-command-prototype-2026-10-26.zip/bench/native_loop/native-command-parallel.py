"""Optional batched Metal command loop for the wide binary solver.

The extension consumes Metal DLPack buffers, and completes all external work
before returning.  A direct objective/gradient evaluation remains authoritative;
unhandled line searches and precision reanchors use the existing MLX solver.
"""

from __future__ import annotations

import ast
import functools
import importlib
import math
from pathlib import Path

import mlx.core as mx
import numpy as np

from .lbfgs import LBFGSState

try:
    _metal_loop = importlib.import_module(f"{__package__}._metal_loop")
except ModuleNotFoundError as exc:
    if exc.name != f"{__package__}._metal_loop":
        raise
    _metal_loop = None


def _kernel_source(path, name):
    """Extract the existing single source of truth for an MLX Metal kernel."""
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for item in tree.body:
        if isinstance(item, ast.Assign) and any(
            isinstance(target, ast.Name) and target.id == name for target in item.targets
        ):
            if isinstance(item.value, ast.Constant):
                return item.value.value
            for keyword in item.value.keywords:
                if keyword.arg == "source":
                    return ast.literal_eval(keyword.value)
    raise RuntimeError(f"missing Metal source for {name}")


def _kernel(name, args, body):
    declaration = ",\n".join(f"{kind} {arg} [[buffer({i})]]" for i, (kind, arg) in enumerate(args))
    return f"kernel void {name}(\n{declaration},\nuint3 thread_position_in_grid [[thread_position_in_grid]],\nuint3 thread_position_in_threadgroup [[thread_position_in_threadgroup]],\nuint3 threadgroup_position_in_grid [[threadgroup_position_in_grid]]) {{\n{body}\n}}\n"


@functools.lru_cache(maxsize=32)
def _source(n, d, p, m, cand, blocks, groups, rows, feature_groups):
    directory = Path(__file__).parent
    core = directory / "native_logistic.py"
    fused = directory / "native_logistic_fused.py"
    defines = f"#define N {n}\n#define D {d}\n#define P {p}\n#define M {m}\n#define CAND {cand}\n#define B {blocks}\n#define GROUPS {groups}\n#define ROWS {rows}\n#define FEATURE_GROUPS {feature_groups}\n"
    # The MLX JIT includes its own accurate log1p helper; the two call sites
    # here use finite arguments between -1 and 1. Preserve small increments.
    log1p = "inline float log1p(float x){float y=1.0f+x;return y==1.0f?x:x*(log(y)/(y-1.0f));}\n"
    header = "#include <metal_stdlib>\nusing namespace metal;\n" + defines + log1p + _kernel_source(core, "_REDUCE")
    inputs = lambda *names: [("device const float*", name) for name in names]
    outputs = lambda *names: [("device float*", name) for name in names]
    direction = (inputs("w", "g", "oldw", "oldg", "hs", "hy", "hc", "meta", "reg")
                 + [("constant float&", "tol")] + inputs("h0inv")
                 + [("constant float&", "min_curvature"), ("constant float&", "alpha_start")]
                 + outputs("direction", "newhs", "newhy", "newhc", "stats"))
    speculative = inputs("X", "direction", "raw", "y", "sw", "stats") + [("constant float&", "denom")] + outputs("dr", "partial", "gradient_parts")
    accept = inputs("w", "raw", "direction", "dr", "y", "sw", "stats", "diffs") + [("constant float&", "c1")] + outputs("neww", "newraw", "residual", "newmeta")
    backward = inputs("X", "r") + [("device const bool&", "active")] + outputs("parts")
    header += _kernel("direction_kernel", direction, _kernel_source(core, "_direction"))
    header += _kernel("speculative_kernel", speculative, _kernel_source(fused, "_speculative"))
    header += _kernel("accept_kernel", accept, _kernel_source(core, "_accept"))
    header += _kernel("backward_kernel", backward, _kernel_source(core, "_backward"))
    header += r"""
kernel void reduce_spec(device const float* losses [[buffer(0)]],
                        device const float* parts [[buffer(1)]],
                        constant float& denom [[buffer(2)]],
                        device float* diffs [[buffer(3)]],
                        device float* gradient [[buffer(4)]],
                        uint t [[thread_position_in_threadgroup]],
                        uint group [[threadgroup_position_in_grid]]) {
 uint lane=t%32,sg=t/32,col=group*32+lane;
 float value=0, loss=0;
 for(uint i=sg;i<B;i+=4){
   if(col<P)value+=parts[ulong(i)*P+col];
   if(group==0 && lane<CAND)loss+=losses[ulong(lane)*B+i];
 }
 threadgroup float shared[128], shared_loss[128];
 shared[t]=value;shared_loss[t]=loss;
 threadgroup_barrier(mem_flags::mem_threadgroup);
 if(sg==0){
   if(col<P)gradient[col]=(shared[t]+shared[t+32]+shared[t+64]+shared[t+96])/denom;
   if(group==0 && lane<CAND)diffs[lane]=shared_loss[t]+shared_loss[t+32]+shared_loss[t+64]+shared_loss[t+96];
 }
}
kernel void make_active(device const float* meta [[buffer(0)]],
                        constant float& alpha [[buffer(1)]],
                        device bool* active [[buffer(2)]]) {
 active[0]=meta[1]==0 && meta[8]!=alpha;
}
kernel void finish_grad(device const float* parts [[buffer(0)]],
                        device const float* first [[buffer(1)]],
                        device const float* meta [[buffer(2)]],
                        constant float& alpha [[buffer(3)]],
                        device const float* oldg [[buffer(4)]],
                        device const float* w [[buffer(5)]],
                        device const float* reg [[buffer(6)]],
                        constant float& denom [[buffer(7)]],
                        device float* g [[buffer(8)]],
                        uint t [[thread_position_in_grid]]) {
 if(t<P){float value=first[t];
  if(meta[1]==0 && meta[8]!=alpha){value=0;for(uint i=0;i<(N+255)/256;i++)value+=parts[ulong(i)*P+t];value/=denom;}
  g[t]=meta[1]==0?value+reg[t]*w[t]:oldg[t];
 }
}
"""
    return header


def run_native_loop(X, y, sw, sw_sum, l2, fit_intercept, config, fun, *, initial_parts=None):
    """Return a certified native result, or None when the MLX solver should run."""
    if _metal_loop is None or initial_parts is None or not fit_intercept:
        return None
    n, d = X.shape
    if not (512 <= d <= 4096 and config.history_size == 10 and config.max_line_search >= 8):
        return None
    from .native_logistic import initial_from_parts

    p = d + 1
    if initial_parts.shape != (2, (n + 255) // 256, p) or initial_parts.dtype != mx.float32:
        raise ValueError("initial_parts must match the native solver design")
    if sw is None:
        sw = mx.ones(n, dtype=mx.float32)
    reg = mx.concatenate([mx.full(d, l2, dtype=mx.float32), mx.zeros(1, dtype=mx.float32)])
    denom = mx.array(sw_sum, dtype=mx.float32)
    g, h0 = initial_from_parts(initial_parts, reg, denom)
    # Export synchronizes the producer; keep every capsule and array alive
    # until the native command buffer has finished executing.
    mx.eval(X, y, sw, g, h0, reg)
    mx.synchronize()
    capsules = tuple(value.__dlpack__() for value in (X, y, sw, g, h0, reg))
    if n >= 16384:
        groups, feature_groups, rows = (4, 1, 32) if d <= 1024 else (8, 4, 32 if d <= 2048 else 64)
    else:
        groups, feature_groups, rows = (2, 1, 16) if d <= 1024 else (8, 4, 8)
    blocks = (n + (groups // feature_groups) * rows - 1) // ((groups // feature_groups) * rows)
    src = _source(n, d, p, config.history_size, 8, blocks, groups, rows, feature_groups)
    tol = np.float32(config.tol)
    if float(tol) > config.tol:
        tol = np.nextafter(tol, np.float32(0))
    result = _metal_loop.run(src, capsules, n, d, p, config.history_size, blocks, groups,
                             config.max_iter, float(np.float32(sw_sum)), float(tol), config.c1, config.min_curvature)
    raw, n_iter, status, n_fev = result
    if status != 1:
        return None
    w = mx.array(np.frombuffer(raw, dtype=np.float32).copy()).reshape(1, p)
    objective, gradient = fun(w)
    grad_max = float(mx.max(mx.abs(gradient)))
    if not math.isfinite(objective) or not math.isfinite(grad_max) or grad_max > config.tol:
        return None
    return LBFGSState(x=w, objective=objective, grad_max_abs=grad_max, n_iter=n_iter,
                      n_fev=n_fev + 1, converged=True, stop_reason="gtol")
