exec(open('bench/native_loop/compare.py').read().split('results=')[0])
from mlxlearn._solvers import native_logistic
metrics=[];record={}
class MX:
 def __getattr__(self,k): return getattr(mx,k)
 def eval(self,*a):
  t=time.perf_counter();v=mx.eval(*a);record['eval']=1000*(time.perf_counter()-t);return v
 def synchronize(self,*a):
  t=time.perf_counter();v=mx.synchronize(*a);record['sync']=1000*(time.perf_counter()-t);return v
class Ext:
 def run(self,*a):
  t=time.perf_counter();v=ext.run(*a);record['ext']=1000*(time.perf_counter()-t);return v
native_command.mx=MX();native_command._metal_loop=Ext(); orig=native_command.run_native_loop
def wrap(*args,**kwargs):
 t=time.perf_counter();ret=orig(*args,**kwargs);record['total']=1000*(time.perf_counter()-t);return ret
native_command.run_native_loop=wrap
with threadpool_limits(1),tuning_context(force_backend='mlx'):
 for i in range(12):
  mx.synchronize();t=time.perf_counter();m=LogisticRegression(max_iter=200).fit(X,y);mx.synchronize();t=1000*(time.perf_counter()-t)
  if i>2:metrics.append((round(t,3),{k:round(v,3) for k,v in record.items()}))
print(metrics)
