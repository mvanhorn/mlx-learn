import numpy as np,time,statistics
import mlx.core as mx
from threadpoolctl import threadpool_limits
from sklearn.linear_model import LogisticRegression as SK
from mlxlearn.linear_model import LogisticRegression
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
rng=np.random.default_rng(41);X=rng.normal(size=(60000,1024)).astype('f');y=(X[:,0]+rng.normal(scale=.5,size=60000)>0).astype('i')
ext=native_command._metal_loop
results={'new':[],'old':[],'sk':[]};models={}
with threadpool_limits(1),tuning_context(force_backend='mlx'):
  for i in range(12):
   for name in [('new','old','sk'),('sk','old','new'),('old','new','sk'),('sk','new','old')][i%4]:
    native_command._metal_loop=ext if name=='new' else None
    mx.synchronize(); t=time.perf_counter();m=(SK if name=='sk' else LogisticRegression)(max_iter=200).fit(X,y);mx.synchronize(); t=time.perf_counter()-t
    if i>=3:results[name].append(t*1000)
    models[name]=m
for name,vals in results.items():print(name,round(statistics.median(vals),4),round(statistics.mean(vals),4),[round(x,3) for x in vals],models[name].n_iter_)
for name in ('new','old'):
 a=models[name];b=models['sk'];print(name,'agree',np.mean(a.predict(X)==b.predict(X)), 'coef diff',np.max(np.abs(a.coef_-b.coef_)))
