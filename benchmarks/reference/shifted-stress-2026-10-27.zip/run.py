"""Deferred CPU-only numerical stress sweep for shifted logistic solutions."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from scipy.special import expit, softmax
from mlxlearn._solvers.logistic import LogisticConfig, solve_logistic


def generate(seed, n, d, offset, scale, n_classes, weighted):
    rng=np.random.default_rng(seed)
    X=(rng.normal(size=(n,d))*scale).astype(np.float32)
    t=X[:,0]/scale + rng.normal(scale=.5,size=n)
    y=(t>0).astype(int) if n_classes==2 else np.digitize(t,[-.5,.5])
    X += np.float32(offset)
    sw=rng.uniform(.1,3,n) if weighted else None
    if weighted:
        sw[::7]=0
    return X,y,sw


def score(s,X,y,sw,n_classes):
    X=X.astype(np.float64);n=len(y);den=n if sw is None else sw.sum()
    raw=X@s.coef.T+s.intercept
    r=(expit(raw[:,0])-y)[:,None] if n_classes==2 else softmax(raw,axis=1)
    if n_classes!=2: r[np.arange(n),y]-=1
    if sw is not None:r*=sw[:,None]
    return max(np.max(np.abs(r.T@X/den+s.coef/den)),np.max(np.abs(r.sum(axis=0)/den)))


def main():
    out=[]
    for n_classes in (2,3):
      for seed in (1,9):
       for offset in (0,1000,-1000,10000):
        for scale in (.1,1):
         for weighted in (False,True):
          X,y,sw=generate(seed,259,8,offset,scale,n_classes,weighted)
          s=solve_logistic(X,y,n_classes=n_classes,sample_weight=sw,
                           config=LogisticConfig(C=1,tol=1e-4,max_iter=200,device='cpu'))
          actual=score(s,X,y,sw,n_classes)
          row={'classes':n_classes,'seed':seed,'offset':offset,'scale':scale,
               'weighted':weighted,'converged':s.converged,'reason':s.stop_reason,
               'iterations':s.n_iter,'reported':s.grad_max_abs,'independent':float(actual),
               'falsely_converged':bool(s.converged and actual>1e-4)}
          out.append(row)
          print(row,flush=True)
    p=Path('bench/shifted_stress/results.json');p.write_text(json.dumps(out,indent=2)+'\n')
    print('false convergences',sum(r['falsely_converged'] for r in out),'not converged',sum(not r['converged'] for r in out))

if __name__=='__main__':main()
