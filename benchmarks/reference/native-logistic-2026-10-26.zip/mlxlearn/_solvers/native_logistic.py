"""Native Metal binary logistic L-BFGS with a curvature-scaled initial metric.

The optimizer and its ring history remain on the GPU. Native Metal C++ kernels
fuse the two-loop recurrence, directional projection and Armijo loss differences,
accepted-step residuals, and gradient reductions. Host checks occur once per
bounded chunk, then the caller's direct objective certifies the final result.
"""

from __future__ import annotations

import math

import mlx.core as mx
import numpy as np

from .lbfgs import LBFGSConfig, LBFGSState, ObjectiveGradient

__all__ = ["minimize_binary"]

_REDUCE = r"""
inline float sigmoid_stable(float z) {
    float e = exp(-abs(z));
    return z >= 0.0f ? 1.0f/(1.0f+e) : e/(1.0f+e);
}
inline float expm1_small(float x) {
    // Metal has no expm1 intrinsic. On |x| < 0.5, the omitted terms are below
    // one float32 ULP; factoring out x also preserves very small changes.
    return x*(1.0f+x*(0.5f+x*(1.0f/6.0f+x*(1.0f/24.0f+x*(1.0f/120.0f+x*(1.0f/720.0f+x*(1.0f/5040.0f+x/40320.0f)))))));
}
inline float softplus_stable(float z) {
    return max(z,0.0f)+log1p(exp(-abs(z)));
}
"""

# meta: accepted iterations, status (0 active,1 converged,2 search failure,
# 3 nonfinite), history count, next slot, max-gradient, directional derivative,
# penalty linear term, penalty quadratic term, initial alpha, loss evaluations.
_direction = mx.fast.metal_kernel(
    name="mlxlearn_native_lbfgs_direction",
    header=_REDUCE,
    input_names=[
        "w",
        "g",
        "oldw",
        "oldg",
        "hs",
        "hy",
        "hc",
        "meta",
        "reg",
        "tol",
        "h0inv",
        "min_curvature",
        "alpha_start",
    ],
    output_names=["direction", "newhs", "newhy", "newhc", "stats"],
    source=r"""
// One SIMD group owns the complete ring history and recurrence. Reductions
// use SIMD shuffles; only publishing history updates needs device barriers.
uint t=thread_position_in_threadgroup.x;
float alphas[M];
float q[(P+31)/32];
float localmax=0.0f, bad=0.0f, gg=0.0f;
for(uint k=0;k<(P+31)/32;++k){
    uint j=t+k*32; float v=j<P?g[j]:0.0f; q[k]=v;
    localmax=max(localmax,abs(v));bad+=isfinite(v)?0.0f:1.0f;
    gg+=j<P?v*v*h0inv[j]:0.0f;
}
float maxgrad=simd_max(localmax);
bad=simd_sum(bad);
gg=simd_sum(gg);
uint status=uint(meta[1]), count=uint(meta[2]), head=uint(meta[3]);
if(status==0){if(bad>0)status=3;else if(maxgrad<=tol)status=1;}
bool active=status==0;
for(uint j=t;j<M*P;j+=32){newhs[j]=hs[j];newhy[j]=hy[j];}
for(uint j=t;j<M*2;j+=32)newhc[j]=hc[j];
threadgroup_barrier(mem_flags::mem_device);
if(active && meta[0]>0){
    float sy=0,yy=0;
    for(uint j=t;j<P;j+=32){float s=w[j]-oldw[j],y=g[j]-oldg[j];sy+=s*y;yy+=y*y*h0inv[j];}
    sy=simd_sum(sy);yy=simd_sum(yy);
    if(isfinite(sy) && sy>min_curvature*max(yy,1.0f) && yy>0){
        for(uint j=t;j<P;j+=32){newhs[head*P+j]=w[j]-oldw[j];newhy[head*P+j]=g[j]-oldg[j];}
        if(t==0){newhc[2*head]=1.0f/sy;newhc[2*head+1]=sy/yy;}
        head=(head+1)%M;count=min(count+1,uint(M));
    }
}
threadgroup_barrier(mem_flags::mem_device);
if(active){
    for(uint a=0;a<count;++a){
        uint h=(head+M-1-a)%M;float dot=0;
        for(uint k=0;k<(P+31)/32;++k){uint j=t+32*k;if(j<P)dot+=newhs[h*P+j]*q[k];}
        float alpha=simd_sum(dot)*newhc[2*h];
        alphas[a]=alpha;
        for(uint k=0;k<(P+31)/32;++k){uint j=t+32*k;if(j<P)q[k]-=alpha*newhy[h*P+j];}
    }
    float gamma=count?newhc[2*((head+M-1)%M)+1]:1.0f;
    for(uint k=0;k<(P+31)/32;++k){uint j=t+32*k;if(j<P)q[k]*=gamma*h0inv[j];}
    for(uint a=0;a<count;++a){
        uint h=(head+M-count+a)%M;float dot=0;
        for(uint k=0;k<(P+31)/32;++k){uint j=t+32*k;if(j<P)dot+=newhy[h*P+j]*q[k];}
        float beta=simd_sum(dot)*newhc[2*h];
        float alpha=alphas[count-1-a];
        for(uint k=0;k<(P+31)/32;++k){uint j=t+32*k;if(j<P)q[k]+=newhs[h*P+j]*(alpha-beta);}
    }
}
float slope=0;
for(uint k=0;k<(P+31)/32;++k){uint j=t+k*32;if(j<P)slope-=q[k]*g[j];}
slope=simd_sum(slope);
bool reset=active && (!isfinite(slope) || slope>=0);
if(reset){count=0;head=0;slope=-gg;}
float penlin=0,penquad=0;
for(uint k=0;k<(P+31)/32;++k){uint j=t+k*32;
 if(j<P){float d=active?(reset?-g[j]*h0inv[j]:-q[k]):0.0f;direction[j]=d;if(reg[j]>0){penlin+=reg[j]*w[j]*d;penquad+=reg[j]*d*d;}}}
penlin=simd_sum(penlin);penquad=simd_sum(penquad);
if(t==0){
 stats[0]=meta[0];stats[1]=float(status);stats[2]=float(count);stats[3]=float(head);
 stats[4]=maxgrad;stats[5]=active?slope:0.0f;stats[6]=penlin;stats[7]=penquad;
 stats[8]=alpha_start;stats[9]=meta[9];
}
""",
)

_forward_search = mx.fast.metal_kernel(
    name="mlxlearn_native_lbfgs_forward_search",
    header=_REDUCE,
    input_names=["X", "direction", "raw", "y", "sw", "stats", "denom"],
    output_names=["dr", "partial"],
    source=r"""
// Eight SIMD groups process eight rows. Every lane shares its row's dot
// product; lanes then evaluate distinct backtracking candidates in parallel.
uint tid=thread_position_in_threadgroup.x,lane=tid%32,sg=tid/32;
uint row=threadgroup_position_in_grid.x*8+sg;
float z=0;
if(row<N && stats[1]==0){for(uint j=lane;j<D;j+=32)z=fma(X[row*D+j],direction[j],z);}
z=simd_sum(z);if(P>D)z+=direction[D];
if(lane==0 && row<N)dr[row]=z;
threadgroup float shared[8*CAND];
if(lane<CAND){float value=0;
 if(row<N && stats[1]==0 && sw[row]>0){
  float alpha=stats[8]*exp2(-float(lane)),sign=1.0f-2.0f*y[row];
  float u=sign*raw[row],dz=sign*z*alpha;
  float diff=abs(dz)<0.5f?log1p(sigmoid_stable(u)*expm1_small(dz)):softplus_stable(u+dz)-softplus_stable(u);
  value=sw[row]*diff/denom;
 }
 shared[sg*CAND+lane]=value;
}
threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==0 && lane<CAND){float value=0;for(uint r=0;r<8;++r)value+=shared[r*CAND+lane];partial[lane*B+threadgroup_position_in_grid.x]=value;}
""",
)

_accept = mx.fast.metal_kernel(
    name="mlxlearn_native_lbfgs_accept",
    header=_REDUCE,
    input_names=["w", "raw", "direction", "dr", "y", "sw", "stats", "diffs", "c1"],
    output_names=["neww", "newraw", "residual", "newmeta"],
    source=r"""
uint i=thread_position_in_grid.x;
uint status=uint(stats[1]);float alpha=0;bool accepted=false;
if(status==0){
 for(uint k=0;k<CAND;++k){
  float a=stats[8]*exp2(-float(k));
  float df=diffs[k]+a*stats[6]+0.5f*a*a*stats[7];
  if(isfinite(df) && df<=c1*a*stats[5] && stats[5]<0){alpha=a;accepted=true;break;}
 }
 if(!accepted)status=2;
}
if(i<P)neww[i]=accepted?fma(alpha,direction[i],w[i]):w[i];
if(i<N){float z=accepted?fma(alpha,dr[i],raw[i]):raw[i];newraw[i]=z;float sign=1.0f-2.0f*y[i];residual[i]=sw[i]>0?sw[i]*sign*sigmoid_stable(sign*z):0.0f;}
if(i<10)newmeta[i]=i==0?stats[0]+float(accepted):(i==1?float(status):(i==9?stats[9]+(stats[1]==0?CAND:0):stats[i]));
""",
)


_backward = mx.fast.metal_kernel(
    name="mlxlearn_native_lbfgs_backward_bias",
    input_names=["X", "r", "active"],
    output_names=["parts"],
    source=r"""
// Coalesced feature loads, four row accumulators per feature, then a small
// partial reduction. The intercept is implicit, avoiding an augmented X copy.
uint col=threadgroup_position_in_grid.x*32+(thread_position_in_threadgroup.x % 32);
uint block=threadgroup_position_in_grid.y,sg=(thread_position_in_threadgroup.x / 32);
uint start=block*256+sg;float value=0;
if(col<P && active){for(uint row=start;row<min(uint(N),(block+1)*256);row+=4)value=fma(col<D?X[row*D+col]:1.0f,r[row],value);}
threadgroup float partial[128];uint tid=thread_position_in_threadgroup.x;
partial[tid]=value;threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==0 && col<P)parts[block*P+col]=partial[tid]+partial[tid+32]+partial[tid+64]+partial[tid+96];
""",
)


def bwd(X, r, p, active=None):
    n, d = X.shape
    nb = (n + 255) // 256
    if active is None:
        active = mx.array(True)
    return mx.sum(
        _backward(
            inputs=[X, r, active],
            template=[("N", n), ("D", d), ("P", p)],
            grid=(((p + 31) // 32) * 128, nb, 1),
            threadgroup=(128, 1, 1),
            output_shapes=[(nb, p)],
            output_dtypes=[mx.float32],
        )[0],
        axis=0,
    )


_direct_forward = mx.fast.metal_kernel(
    name="mlxlearn_native_lbfgs_direct_forward",
    header=_REDUCE,
    input_names=["X", "theta", "y", "sw"],
    output_names=["loss", "residual"],
    source=r"""
uint tid=thread_position_in_threadgroup.x,lane=tid%32;
uint row=threadgroup_position_in_grid.x*4+tid/32;
float z=0.0f;
if(row<N){for(uint j=lane;j<D;j+=32)z=fma(X[row*D+j],theta[j],z);}
z=simd_sum(z);
if(lane==0 && row<N){
 if(P>D)z+=theta[D];
 float weight=sw[row];
 if(weight>0){
  float sign=1.0f-2.0f*y[row],u=sign*z;
  loss[row]=weight*softplus_stable(u);
  residual[row]=weight*sign*sigmoid_stable(u);
 }else{loss[row]=0.0f;residual[row]=0.0f;}
}
""",
)


@mx.compile
def direct_arrays(theta, X, y, sw, denom, l2, fit_intercept):
    """Evaluate loss and gradient from actual parameters using native kernels.

    ``l2`` is a Python float, making the unpenalized branch static. The caller
    reduces returned sample losses in blocks and finishes accumulation in host
    float64, exactly as for the generic logistic objective.
    """
    n, d = X.shape
    p = d + int(fit_intercept)
    if sw is None:
        sw = mx.ones(n, dtype=X.dtype)
    loss, residual = _direct_forward(
        inputs=[X, theta, y, sw],
        template=[("N", n), ("D", d), ("P", p)],
        grid=(((n + 3) // 4) * 128, 1, 1),
        threadgroup=(128, 1, 1),
        output_shapes=[(n,), (n,)],
        output_dtypes=[mx.float32, mx.float32],
    )
    gradient = bwd(X, residual, p) / denom
    if l2 > 0:
        weights = theta[0, :d]
        grad_penalty = l2 * weights
        if fit_intercept:
            grad_penalty = mx.concatenate([grad_penalty, mx.zeros(1, dtype=X.dtype)])
        gradient = gradient + grad_penalty
        penalty = (0.5 * l2) * mx.sum(weights * weights)
    else:
        # Keep the zero output dependent on an input for mx.compile, without
        # squaring unpenalized parameters or multiplying a possible infinity.
        penalty = denom - denom
    return loss, penalty, gradient.reshape(theta.shape)


_initial = mx.fast.metal_kernel(
    name="mlxlearn_native_lbfgs_initial",
    input_names=["X", "y", "sw"],
    output_names=["parts"],
    source=r"""
uint tid=thread_position_in_threadgroup.x,col=threadgroup_position_in_grid.x*32+tid%32;
uint block=threadgroup_position_in_grid.y,sg=tid/32,start=block*256+sg;
float grad=0,diag=0;
if(col<P){for(uint row=start;row<min(uint(N),(block+1)*256);row+=4){float weight=sw[row];if(weight>0){float x=col<D?X[row*D+col]:1.0f;grad+=x*(.5f-y[row])*weight;diag+=.25f*x*x*weight;}}}
threadgroup float gp[128],hp[128];gp[tid]=grad;hp[tid]=diag;threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==0 && col<P){parts[block*P+col]=gp[tid]+gp[tid+32]+gp[tid+64]+gp[tid+96];parts[B*P+block*P+col]=hp[tid]+hp[tid+32]+hp[tid+64]+hp[tid+96];}
""",
)


@mx.compile
def initial(X, y, sw, p, reg, denom):
    n, d = X.shape
    nb = (n + 255) // 256
    out = (
        mx.sum(
            _initial(
                inputs=[X, y, sw],
                template=[("N", n), ("D", d), ("P", p), ("B", nb)],
                grid=(((p + 31) // 32) * 128, nb, 1),
                threadgroup=(128, 1, 1),
                output_shapes=[(2, nb, p)],
                output_dtypes=[mx.float32],
            )[0],
            axis=1,
        )
        / denom
    )
    diagonal = mx.mean(out[1] + reg)
    # A scalar metric preserves the data's row space on rank-deficient designs.
    # A per-feature Jacobi metric can introduce null-space coefficients that a
    # weak penalty does not remove before the gradient stopping criterion fires.
    scale = mx.where(mx.isfinite(diagonal) & (diagonal > 1e-12), 1 / diagonal, 1.0)
    return out[0], mx.ones_like(out[0]) * scale


@mx.compile
def step(
    X,
    y,
    sw,
    reg,
    denom,
    tol,
    h0inv,
    c1,
    min_curvature,
    candidates,
    alpha_start,
    w,
    g,
    oldw,
    oldg,
    hs,
    hy,
    hc,
    meta,
    raw,
):
    n, d = X.shape
    p = w.shape[0]
    m = hs.shape[0]
    direction, hs, hy, hc, stats = _direction(
        inputs=[w, g, oldw, oldg, hs, hy, hc, meta, reg, tol, h0inv, min_curvature, alpha_start],
        template=[("P", p), ("M", m)],
        grid=(32, 1, 1),
        threadgroup=(32, 1, 1),
        output_shapes=[(p,), (m, p), (m, p), (m, 2), (10,)],
        output_dtypes=[mx.float32] * 5,
    )
    blocks = (n + 7) // 8
    dr, partial = _forward_search(
        inputs=[X, direction, raw, y, sw, stats, denom],
        template=[("N", n), ("D", d), ("P", p), ("CAND", candidates), ("B", blocks)],
        grid=(blocks * 256, 1, 1),
        threadgroup=(256, 1, 1),
        output_shapes=[(n,), (candidates, blocks)],
        output_dtypes=[mx.float32] * 2,
    )
    diffs = mx.sum(partial, axis=1)
    neww, newraw, resid, meta = _accept(
        inputs=[w, raw, direction, dr, y, sw, stats, diffs, c1],
        template=[("N", n), ("P", p), ("CAND", candidates)],
        grid=(((max(n, p) + 255) // 256) * 256, 1, 1),
        threadgroup=(256, 1, 1),
        output_shapes=[(p,), (n,), (n,), (10,)],
        output_dtypes=[mx.float32] * 4,
    )
    # A rejected first batch is resumed from exactly the same gradient and
    # history. Recomputing an unchanged gradient can perturb the direction.
    active = meta[1] == 0
    newg = mx.where(active, bwd(X, resid, p, active) / denom + reg * neww, g)
    return neww, newg, w, g, hs, hy, hc, meta, newraw


def minimize_binary(
    X: mx.array,
    y: mx.array,
    sw: mx.array | None,
    sw_sum: float,
    l2: float,
    fit_intercept: bool,
    config: LBFGSConfig,
    fun: ObjectiveGradient,
) -> LBFGSState:
    """Minimize a binary logistic objective on the current GPU stream.

    ``X`` is already prepared by the caller; this function performs no host
    preprocessing or dtype conversion. Backtracking first evaluates eight
    geometrically decreasing steps. A rejected batch resumes the same direction
    with the remaining search budget, up to 32 candidates in total.
    The line search uses Armijo decrease rather than strong Wolfe curvature.
    A positive curvature check protects each L-BFGS history insertion.

    Cached logits avoid repeated matrix-vector products. They are never the
    authority for returned objective or convergence: ``fun`` recomputes both
    directly, and a premature cached convergence restarts from that gradient
    while preserving the remaining accepted-step budget.
    """
    if not 1 <= config.max_line_search <= 32:
        raise ValueError("native binary L-BFGS requires max_line_search in [1, 32]")
    n, d = X.shape
    p = d + int(fit_intercept)
    w = mx.zeros(p, dtype=X.dtype)

    if config.max_iter == 0:
        objective, gradient = fun(w.reshape(1, p))
        grad_max = float(mx.max(mx.abs(gradient)))
        finite = math.isfinite(objective) and math.isfinite(grad_max)
        converged = finite and grad_max <= config.tol
        return LBFGSState(
            x=w.reshape(1, p),
            objective=objective,
            grad_max_abs=grad_max,
            n_iter=0,
            n_fev=1,
            converged=converged,
            stop_reason="gtol" if converged else ("max_iter" if finite else "non-finite-objective"),
        )

    if sw is None:
        sw = mx.ones(n, dtype=X.dtype)
    reg = mx.full(d, l2, dtype=X.dtype)
    if fit_intercept:
        reg = mx.concatenate([reg, mx.zeros(1, dtype=X.dtype)])
    denom = mx.array(sw_sum, dtype=X.dtype)
    # Rounding the threshold upward could let the device stop at a gradient
    # that the host rejects, without taking any step after a reanchor.
    device_tol = np.float32(config.tol)
    if float(device_tol) > config.tol:
        device_tol = np.nextafter(device_tol, np.float32(0))
    tol = mx.array(device_tol, dtype=X.dtype)
    c1 = mx.array(config.c1, dtype=X.dtype)
    min_curvature = mx.array(config.min_curvature, dtype=X.dtype)
    g, h0inv = initial(X, y, sw, p, reg, denom)
    hs = mx.zeros((config.history_size, p), dtype=X.dtype)
    hy = mx.zeros_like(hs)
    hc = mx.zeros((config.history_size, 2), dtype=X.dtype)
    meta = mx.zeros(10, dtype=X.dtype)
    raw = mx.zeros(n, dtype=X.dtype)
    state = (w, g, w, g, hs, hy, hc, meta, raw)
    n_iter = 0
    direct_evaluations = 0
    last_reanchor_iteration = -1
    first_batch = min(8, config.max_line_search)
    search_offset = 0

    while True:
        # Four steps amortize Python evaluation boundaries without allowing a
        # long tail of redundant GEMVs after device convergence.
        candidates = first_batch if search_offset == 0 else config.max_line_search - search_offset
        alpha_start = mx.array(2.0 ** (-search_offset), dtype=X.dtype)
        # A resumed search executes only one step: the next iteration starts at
        # unit step size again rather than inheriting the continuation offset.
        chunk = 4 if search_offset == 0 else 1
        for _ in range(min(chunk, config.max_iter - n_iter)):
            state = step(
                X,
                y,
                sw,
                reg,
                denom,
                tol,
                h0inv,
                c1,
                min_curvature,
                candidates,
                alpha_start,
                *state,
            )
        # The last accepted update may meet the tolerance before a following
        # direction kernel can set status=1. Check its gradient at this same
        # evaluation boundary, avoiding another whole frozen iteration chunk.
        chunk_grad_max = mx.max(mx.abs(state[1]))
        mx.eval(state, chunk_grad_max)
        host_meta = np.asarray(state[7]).copy()
        n_iter, status = int(host_meta[0]), int(host_meta[1])
        if status == 0 and float(chunk_grad_max) <= float(device_tol):
            status = 1
        if status == 2 and search_offset == 0 and first_batch < config.max_line_search:
            search_offset = first_batch
            host_meta[1] = 0
            state = (*state[:7], mx.array(host_meta, dtype=X.dtype), state[8])
            continue
        if status == 0:
            search_offset = 0
        if status == 0 and n_iter < config.max_iter:
            continue

        x = state[0].reshape(1, p)
        objective, direct_gradient = fun(x)
        direct_evaluations += 1
        grad_max = float(mx.max(mx.abs(direct_gradient)))
        finite = math.isfinite(objective) and math.isfinite(grad_max)
        converged = finite and grad_max <= config.tol
        if status == 1 and finite and not converged and n_iter < config.max_iter:
            if n_iter == last_reanchor_iteration:
                # No accepted step separates these two direct checks. Report
                # precision stagnation through the existing failure contract.
                return LBFGSState(
                    x=x,
                    objective=objective,
                    grad_max_abs=grad_max,
                    n_iter=n_iter,
                    n_fev=int(host_meta[9]) + direct_evaluations,
                    converged=False,
                    stop_reason="line-search-failure",
                )
            last_reanchor_iteration = n_iter
            # Rebuild from the actual parameters, not from accumulated logits.
            # A history reset avoids mixing gradients from the two paths.
            w = state[0]
            g = direct_gradient.reshape(p)
            raw = X @ w[:d]
            if fit_intercept:
                raw = raw + w[d]
            host_meta[1:9] = 0
            search_offset = 0
            meta = mx.array(host_meta, dtype=X.dtype)
            state = (w, g, w, g, mx.zeros_like(hs), mx.zeros_like(hy), mx.zeros_like(hc), meta, raw)
            continue

        if not finite:
            reason = "non-finite-objective"
        elif converged:
            reason = "gtol"
        elif status == 2:
            reason = "line-search-failure"
        elif status == 3:
            reason = "non-finite-objective"
        else:
            reason = "max_iter"
        return LBFGSState(
            x=x,
            objective=objective,
            grad_max_abs=grad_max,
            n_iter=n_iter,
            n_fev=int(host_meta[9]) + direct_evaluations,
            converged=converged,
            stop_reason=reason,
        )
