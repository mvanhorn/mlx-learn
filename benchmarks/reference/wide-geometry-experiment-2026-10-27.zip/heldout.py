"""Accuracy and complete-fit timing on held-out tile geometries and seeds."""
import argparse
import json
import math
import statistics
from dataclasses import asdict
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits

from bench.wide_tile import panel
from benchmarks.hessian_logistic import Case, dataset, independent_score


def geometry(value):
    if not value:
        return None
    values = tuple(int(x) for x in value.split(","))
    if len(values) != 3:
        raise ValueError("geometry must have three comma-separated integers")
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--g1024")
    parser.add_argument("--g4096")
    parser.add_argument("--repeats", type=int, default=8)
    parser.add_argument("--warmup", type=int, default=2)
    args = parser.parse_args()
    variant = {}
    if args.g1024:
        variant[1024] = geometry(args.g1024)
    if args.g4096:
        variant[4096] = geometry(args.g4096)
    if not variant:
        raise ValueError("select at least one geometry")
    panel.variants["candidate"] = variant
    cases = [
        (Case("normal_1024_seed83", 20000, 1024, seed=83), False),
        (Case("normal_1024_seed2027", 20000, 1024, seed=2027), False),
        (Case("weighted_1024", 20000, 1024, weighted=True), False),
        (Case("weighted_ill_1024", 20000, 1024, seed=83, weighted=True, ill_conditioned=True), False),
        (Case("shifted_1024", 20000, 1024, shifted=True), False),
        (Case("rank_1024", 20000, 1024, rank_deficient=True, C=1e6), False),
        (Case("normal_4096_seed83", 20000, 4096, seed=83), False),
        (Case("sketch_4096", 20000, 4096), True),
        (Case("ill_4096_seed41", 20000, 4096, seed=41, ill_conditioned=True), True),
        (Case("ill_4096_seed83", 20000, 4096, seed=83, ill_conditioned=True), True),
    ]
    paths = [Path(__file__).resolve()]
    hashes = lambda: panel.hashes() | {str(p): panel.hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    output = {"source_integrity_before": hashes(), "variants": variant, "cases": [], "method": "frozen snapshot, interleaved fits, independent float64 score, 1-thread sklearn"}
    try:
        with threadpool_limits(limits=1):
            for case, sketch in cases:
                if case.features not in variant:
                    continue
                X, y, weights, ratio = dataset(case)
                names = ("baseline", "candidate", "sklearn")
                samples = {n:[] for n in names}
                models = {n:[] for n in names}
                details = {n:[] for n in names}
                for rep in range(args.warmup + args.repeats):
                    order = names[rep % len(names):] + names[:rep % len(names)]
                    if rep % 2:
                        order = order[::-1]
                    for name in order:
                        model, ms, detail = panel.fit(X, y, weights, case, name, sketch)
                        if rep >= args.warmup:
                            samples[name].append(ms)
                            models[name].append(model)
                            details[name].append(detail)
                ref, pr = independent_score(models["sklearn"][-1], X, y, weights, case.C, ratio)
                scores = {name:[independent_score(m, X, y, weights, case.C, ratio, (ref["objective_float64"], pr))[0] for m in group] for name, group in models.items()}
                failures = []
                for i, (score, detail) in enumerate(zip(scores["candidate"], details["candidate"], strict=True)):
                    old = scores["baseline"][i]
                    gap = (score["objective_float64"]-old["objective_float64"])/abs(old["objective_float64"])
                    if not math.isfinite(gap) or gap > 1e-5 or score["gradient_max_abs_float64"] > 1e-4 or detail["warnings"] or not detail["native_calls"]:
                        failures.append((i, gap, score["gradient_max_abs_float64"], detail))
                    if ratio is not None and score["nullspace_coefficient_relative"] > 1e-3:
                        failures.append((i, "nullspace", score["nullspace_coefficient_relative"]))
                    if score["prediction_agreement_sklearn"] < 0.995 and not case.shifted:
                        failures.append((i, "predictions", score["prediction_agreement_sklearn"]))
                row = {"case": asdict(case), "sketch": sketch, "median_ms":{n:statistics.median(s) for n,s in samples.items()}, "samples_ms":samples, "quality":scores, "details":details, "failures":failures, "wins":sum(a<b for a,b in zip(samples["candidate"],samples["baseline"],strict=True))}
                output["cases"].append(row)
                print(case.name,row["median_ms"],"wins",row["wins"],"failures",failures[:3],flush=True)
                (panel.base / "heldout-results.json").write_text(json.dumps(output, indent=2)+"\n")
    finally:
        panel.native_command._metal_loop = panel.extension
        panel.native_command.run_native_loop = panel.original
    output["source_integrity_after"] = hashes()
    output["source_integrity_pass"] = output["source_integrity_before"] == output["source_integrity_after"]
    (panel.base / "heldout-results.json").write_text(json.dumps(output, indent=2)+"\n")

if __name__ == "__main__":
    main()
