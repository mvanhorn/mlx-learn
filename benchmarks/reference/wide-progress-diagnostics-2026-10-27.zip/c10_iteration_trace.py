"""Capture native 4096/C=10 iterates via bounded raw extension calls.

Diagnostic only: the proxy replaces the device tolerance with 1e-8 to expose
successive iterates and deliberately interrupts the estimator after synchronous
native execution. No captured model is labeled converged. Independent float64
scoring of each raw iterate occurs after all timed calls. It does not alter
production files or change the public tolerance in sklearn's comparison.
"""
from __future__ import annotations
import hashlib,json,math,time,warnings
from pathlib import Path
import mlx.core as mx
import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits
from benchmarks.logistic_gpu import Case,make_data
from mlxlearn import config_context
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression

class Captured(Exception):pass

class Recorder:
 def __init__(self,extension):self.extension=extension;self.last=None
 def run(self,source,*args):
  values=list(args);values[9]=1e-8
  result=self.extension.run(source,*values)
  raw,n_iter,status,n_fev,last_diff=result
  self.last={'raw':raw,'n_iter':n_iter,'status':status,'n_fev':n_fev,'last_diff':last_diff,'center':values[-1]}
  raise Captured('native iterate recorded; diagnostic interruption')


def score(coef,intercept,X,y,C):
 raw=X@coef+intercept;resid=expit(raw)-y;n=len(y)
 grad=resid@X/n+coef/(C*n);bias=float(resid.mean())
 return {'objective':float(np.mean(np.logaddexp(0.,(1-2*y)*raw))+np.dot(coef,coef)/(2*C*n)),
         'original_gradient_max':max(float(np.abs(grad).max()),abs(bias)),
         'original_gradient_l2':float(np.linalg.norm(np.r_[grad,bias]))}


def run():
 paths=[Path('src/mlxlearn/_solvers')/x for x in ('native_logistic.py','native_command.py','_metal_loop.mm','logistic.py','fused_lbfgs.py')]+[Path(native_command._metal_loop.__file__),Path(__file__)]
 hashes={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 X,y,sw=make_data(Case('wide_20k_4096',20000,4096),41,dtype='float32');assert sw is None
 C=10.;tol=1e-4;extension=native_command._metal_loop;results=[]
 with threadpool_limits(limits=1):
  ref=SkLogisticRegression(C=C,tol=tol,max_iter=200).fit(X,y)
  for budget in range(12,21):
   proxy=Recorder(extension);native_command._metal_loop=proxy
   try:
    with config_context(device='auto'),tuning_context(force_backend='mlx'),warnings.catch_warnings(record=True) as caught:
     warnings.simplefilter('always');mx.synchronize();start=time.perf_counter()
     try:LogisticRegression(C=C,tol=tol,max_iter=budget).fit(X,y)
     except Exception:
      if proxy.last is None:raise
     else:raise RuntimeError('native extension was not intercepted')
     elapsed=time.perf_counter()-start;mx.synchronize()
    d=proxy.last;assert d['n_iter']<=budget and d['status'] in (0,1,2,3)
    theta=np.frombuffer(d.pop('raw'),dtype=np.float32).astype(np.float64);center=np.frombuffer(d.pop('center'),dtype=np.float32).astype(np.float64)
    results.append({'budget':budget,'seconds_diagnostic':elapsed,'native':d,'coef':theta[:-1],'intercept':float(theta[-1]-theta[:-1]@center),'warnings':[str(x.message) for x in caught]})
    print('captured budget',budget,'actual',d['n_iter'],'status',d['status'],flush=True)
   finally:native_command._metal_loop=extension
  data=np.asarray(X,dtype=np.float64);reference=score(ref.coef_[0],float(ref.intercept_[0]),data,y,C)
  out=[]
  for r in results:
   c=r.pop('coef');intercept=r.pop('intercept');q=score(c,intercept,data,y,C)
   q['relative_objective_gap_to_sklearn']=(q['objective']-reference['objective'])/abs(reference['objective'])
   q['last_relative_decrease']=abs(r['native']['last_diff'])/max(abs(q['objective']),1e-12)
   r['quality']=q;out.append(r);print(r['budget'],q,flush=True)
  integrity={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest()==hashes[str(p.resolve())] for p in paths}
  payload={'parameters':{'n':20000,'d':4096,'seed':41,'dtype':'float32','C':C,'requested_tol':tol,'probe_device_tol':1e-8,'sklearn_max_iter':200},'reference':reference,'reference_n_iter':ref.n_iter_.tolist(),'results':out,'hashes':hashes,'source_integrity':integrity,'limitations':'Diagnostic interrupted/truncated native iterates; no convergence status is claimed, timings do not include a completed estimator fit.'}
  Path('bench/objective_accuracy_sweep/c10-iterations.json').write_text(json.dumps(payload,indent=2)+'\n')

if __name__=='__main__':run()
