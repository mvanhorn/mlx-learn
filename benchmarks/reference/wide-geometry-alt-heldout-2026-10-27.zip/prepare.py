"""Materialize a source-verified snapshot for tile experiments."""
import hashlib
import json
import shutil
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
archive = root / "benchmarks/reference/weighted-wide-start-sources-2026-10-27.zip"
manifest = json.loads(archive.with_suffix(".manifest.json").read_text())
assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest["archive"]["sha256"]
out = base / "snapshot"
out.mkdir(exist_ok=True)
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist()) == set(manifest["files"])
    for name in z.namelist():
        data = z.read(name)
        assert hashlib.sha256(data).hexdigest() == manifest["files"][name]
        p = out / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
extension = root / "bench/weighted-wide-start/_metal_loop.abi3.so"
shutil.copyfile(extension, out / "src/mlxlearn/_solvers/_metal_loop.abi3.so")
print("snapshot", out, "extension", hashlib.sha256(extension.read_bytes()).hexdigest())
