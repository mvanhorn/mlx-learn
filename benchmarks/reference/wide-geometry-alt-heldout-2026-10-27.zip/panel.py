"""Explore full-fit speculative Metal geometry against frozen production."""
import gc
import hashlib
import inspect
import json
import statistics
import sys
import time
import warnings
from pathlib import Path

base = Path(__file__).resolve().parent
sys.path.insert(0, str(base / "snapshot/src"))

import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits

from benchmarks.hessian_logistic import Case, dataset, independent_score
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression

original = native_command.run_native_loop
source = inspect.getsource(original)
line = "groups, feature_groups, rows = (4, 1, 32) if d <= 1024 else (8, 4, 32 if d <= 2048 else 64)"
assert source.count(line) == 1
source = source.replace(line, "groups, feature_groups, rows = _experiment_geometry.get(d, ((4, 1, 32) if d <= 1024 else (8, 4, 32 if d <= 2048 else 64)))")
namespace = {}
exec(compile(source, "<scratch tile run_native_loop>", "exec"), native_command.__dict__, namespace)
trial = namespace["run_native_loop"]

class Proxy:
    def __init__(self, module):
        self.module = module
        self.calls = []

    def run(self, *args):
        result = self.module.run(*args)
        self.calls.append({"n_iter": result[1], "status": result[2], "n_fev": result[3]})
        return result

extension = native_command._metal_loop
proxy = Proxy(extension)
native_command._metal_loop = proxy

variants = {
    "baseline": {},
    "g4_f1_r16": {1024:(4,1,16)},
    "g4_f1_r64": {1024:(4,1,64)},
    "g8_f1_r16": {1024:(8,1,16)},
    "g8_f1_r32": {1024:(8,1,32)},
    "g8_f2_r32": {1024:(8,2,32)},
    "g8_f4_r32": {4096:(8,4,32)},
    "g8_f4_r128": {4096:(8,4,128)},
    "g4_f4_r64": {4096:(4,4,64)},
    "g8_f8_r32": {4096:(8,8,32)},
    "g8_f8_r64": {4096:(8,8,64)},
    "g8_f8_r128": {4096:(8,8,128)},
}

cases = [
    (Case("normal_1024", 20000, 1024, seed=41), False),
    (Case("normal_4096", 20000, 4096, seed=41), False),
]

def hashes():
    paths = [p for p in (base / "snapshot/src").rglob("*") if p.is_file() and "__pycache__" not in p.parts]
    paths += [base / "panel.py", base / "prepare.py"]
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}

def fit(X, y, weights, case, variant, sketch):
    native_command._experiment_geometry = variants.get(variant, {})
    native_command.run_native_loop = trial
    proxy.calls.clear()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        mx.synchronize()
        enabled = gc.isenabled()
        gc.disable()
        try:
            t = time.perf_counter()
            if variant == "sklearn":
                model = SkLogisticRegression(C=case.C, tol=1e-4, max_iter=200).fit(X, y, sample_weight=weights)
            else:
                with tuning_context(force_backend="mlx", lbfgs_sketch_size=4 if sketch else 0):
                    model = LogisticRegression(C=case.C, tol=1e-4, max_iter=200).fit(X, y, sample_weight=weights)
            mx.synchronize()
            elapsed = 1000 * (time.perf_counter() - t)
        finally:
            if enabled:
                gc.enable()
    return model, elapsed, {"n_iter": model.n_iter_.tolist(), "warnings": [{"category": w.category.__name__, "message": str(w.message)} for w in caught], "native_calls": proxy.calls.copy()}

def main():
    output = {"source_integrity_before": hashes(), "cases": [], "method": "frozen snapshot, one-thread sklearn, interleaved fresh fits, independent float64 quality, 2 warmups + 5 samples"}
    try:
        with threadpool_limits(limits=1):
            for case, sketch in cases:
                X, y, weights, ratio = dataset(case)
                selected = [v for v in variants if v == "baseline" or case.features in variants[v]] + ["sklearn"]
                samples = {v: [] for v in selected}
                models = {v: [] for v in selected}
                details = {v: [] for v in selected}
                for rep in range(7):
                    order = selected[rep % len(selected):] + selected[:rep % len(selected)]
                    if rep % 2:
                        order = order[::-1]
                    for variant in order:
                        model, elapsed, detail = fit(X, y, weights, case, variant, sketch)
                        if rep >= 2:
                            models[variant].append(model)
                            samples[variant].append(elapsed)
                            details[variant].append(detail)
                reference, prediction = independent_score(models["sklearn"][-1], X, y, weights, case.C, ratio)
                scores = {v:[independent_score(m, X, y, weights, case.C, ratio, (reference["objective_float64"], prediction))[0] for m in group] for v, group in models.items()}
                failures = []
                for variant in selected:
                    if variant in ("baseline", "sklearn"):
                        continue
                    for i, (score, detail) in enumerate(zip(scores[variant], details[variant], strict=True)):
                        base_score = scores["baseline"][i]
                        gap = (score["objective_float64"] - base_score["objective_float64"]) / abs(base_score["objective_float64"])
                        if gap > 1e-5 or score["gradient_max_abs_float64"] > 1e-4 or detail["warnings"] or not detail["native_calls"]:
                            failures.append((variant, i, gap, score["gradient_max_abs_float64"], detail))
                row = {"case": case.name, "median_ms": {v: statistics.median(x) for v,x in samples.items()}, "samples_ms": samples, "quality": scores, "details": details, "failures": failures}
                output["cases"].append(row)
                print(case.name, row["median_ms"], "failures", failures[:4], flush=True)
                (base / "results.json").write_text(json.dumps(output, indent=2) + "\n")
    finally:
        native_command._metal_loop = extension
        native_command.run_native_loop = original
    output["source_integrity_after"] = hashes()
    output["source_integrity_pass"] = output["source_integrity_after"] == output["source_integrity_before"]
    (base / "results.json").write_text(json.dumps(output, indent=2) + "\n")

if __name__ == "__main__":
    main()
