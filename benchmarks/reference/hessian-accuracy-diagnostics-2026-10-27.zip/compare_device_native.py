"""Compare native host/device I/O with identical optimizer state and sketch.

The comparison is diagnostic only. Input generation and independent scoring
use NumPy; both solver calls use the same GPU-resident design/seed arrays.
Run only on an idle GPU, after rebuilding the current native extension.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import mlx.core as mx
import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits

from benchmarks.hessian_logistic import CASES, dataset
from mlxlearn._kernels.logistic_input import prepare_centered
from mlxlearn._solvers import native_command
from mlxlearn._solvers.native_logistic import initial_from_parts
from mlxlearn_device.hessian_sketch import build_sketch_history


def independently_score(X, y, w, center):
    n, d = X.shape
    coef = np.asarray(w[:d], dtype=np.float64)
    center = np.asarray(center, dtype=np.float64)
    bias = float(w[d]) - float(coef @ center)
    loss = bias_grad = 0.0
    grad = np.zeros(d, dtype=np.float64)
    for first in range(0, n, 256):
        last = min(n, first + 256)
        block = np.asarray(X[first:last], dtype=np.float64)
        labels = y[first:last]
        z = block @ coef + bias
        residual = expit(z) - labels
        grad += block.T @ residual
        bias_grad += float(residual.sum())
        loss += float(np.sum(np.logaddexp(0.0, z) - labels * z))
    grad = grad / n + coef / n
    return {
        "objective": loss / n + 0.5 * float(coef @ coef) / n,
        "gradient_max": max(float(np.max(np.abs(grad))), abs(bias_grad / n)),
    }


def run_native(mode, arrays, seeds, count, center, source, n, d, geometry, tol):
    groups, blocks = geometry
    out = mx.zeros((d + 1,), dtype=mx.float32) if mode == "device" else None
    if out is not None:
        mx.eval(out)
    mx.synchronize()
    capsules = tuple(a.__dlpack__() for a in arrays)
    seed_capsules = tuple(a.__dlpack__() for a in seeds)
    owners = (capsules, *arrays, seed_capsules, *seeds)
    if mode == "device":
        external = (center.__dlpack__(), out.__dlpack__())
        owners += (external, center, out)
        extra = (b"", seed_capsules, count, external)
    else:
        extra = (np.asarray(center, dtype=np.float32).tobytes(), seed_capsules, count)
    start = time.perf_counter()
    raw, iterations, status, nfev, last, previous = native_command._metal_loop.run(
        source, capsules, n, d, d + 1, 10, blocks, groups, 200,
        float(n), tol, 1e-4, 1e-12, owners, *extra
    )
    elapsed = time.perf_counter() - start
    if mode == "host":
        values = np.frombuffer(raw, dtype=np.float32).copy()
    else:
        mx.eval(out)
        values = np.asarray(out, dtype=np.float32).copy()
    return values, {"mode": mode, "ms": elapsed * 1000, "iterations": iterations,
                    "status": status, "n_fev": nfev,
                    "last_difference": last, "previous_difference": previous}


def main():
    case = next(c for c in CASES if c.name == "ill_conditioned_4096")
    X, y, _, _ = dataset(case)
    n, d = X.shape
    observations = {"fixture": case.name, "tol": 2.5e-5, "cases": []}
    with mx.stream(mx.gpu), threadpool_limits(limits=1):
        Xd = mx.array(X)
        yd = mx.array(y, dtype=mx.float32)
        sw = mx.ones(n, dtype=mx.float32)
        centered, center, valid, parts = prepare_centered(Xd, yd, sw)
        reg = mx.concatenate([mx.full((d,), 1 / n, dtype=mx.float32), mx.zeros((1,), dtype=mx.float32)])
        denom = mx.array(float(n), dtype=mx.float32)
        gc, hc = initial_from_parts(parts, reg, denom)
        initial = mx.sum(parts, axis=1) / denom
        diagonal = mx.mean(initial[1] + reg)
        scale = mx.where(mx.isfinite(diagonal) & (diagonal > 1e-12), 1 / diagonal, 1.0)
        gu, hu = initial[0], mx.ones_like(initial[0]) * scale
        mx.eval(centered, center, valid, parts, reg, gc, hc, gu, hu)
        observations["initial_metric_differences"] = {
            "g_max_abs": float(mx.max(mx.abs(gc - gu))),
            "h0_max_abs": float(mx.max(mx.abs(hc - hu))),
            "h0_compiled": float(hc[0]), "h0_uncompiled": float(hu[0]),
        }
        pending = []
        for name, grad, h0 in (("compiled", gc, hc), ("uncompiled", gu, hu)):
            seed_s, seed_y, seed_hc, count = build_sketch_history(
                centered, None, float(n), 1 / n, True, h0,
                history_size=10, sketch_size=4, seed=0,
            )
            seeds = (seed_s, seed_y, seed_hc)
            mx.eval(*seeds)
            groups, fg, rows = 8, 4, 64
            blocks = (n + (groups // fg) * rows - 1) // ((groups // fg) * rows)
            source = native_command._source(n, d, d + 1, 10, 8, blocks, groups, rows, fg)
            arrays = (centered, yd, sw, grad, h0, reg)
            for mode in ("host", "device"):
                values, record = run_native(mode, arrays, seeds, count, center, source, n, d, (groups, blocks), 2.5e-5)
                record.update(initial_metric=name, sketch_pairs=count)
                pending.append((values, record))
                print(name, mode, record, flush=True)
        for values, record in pending:
            record["independent"] = independently_score(X, y, values, center)
            observations["cases"].append(record)
        observations["max_parameter_difference"] = {
            metric: float(np.max(np.abs(pending[i][0].astype(np.float64) - pending[i + 1][0].astype(np.float64))))
            for metric, i in (("compiled_host_vs_device", 0), ("uncompiled_host_vs_device", 2))
        }
    Path("bench/accuracy_certificate/compare_device_native.json").write_text(json.dumps(observations, indent=2) + "\n")
    print(observations["initial_metric_differences"], observations["max_parameter_difference"], flush=True)

if __name__ == "__main__":
    main()
