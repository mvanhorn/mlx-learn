"""Scratch GPU relative tolerance sweep; no production source edits."""
import json,time,warnings
from pathlib import Path
from dataclasses import replace
import mlx.core as mx
import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression as SkLR
from threadpoolctl import threadpool_limits
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_logistic
from mlxlearn.linear_model import LogisticRegression
from benchmarks.logistic_gpu import Case,make_data

ORIGINAL=native_logistic.minimize_binary

def initial_data(kind):
 if kind=='weighted_ill1024':
  r=np.random.default_rng(83);n=20000;d=1024
  X=r.standard_normal((n,d),dtype=np.float32); y=(X[:,0]+r.normal(scale=.5,size=n)>0).astype(np.int32)
  X[:,512:]=X[:,:512]+.01*X[:,512:];X*=np.logspace(-1,1,d,dtype=np.float32);sw=r.uniform(.25,3,n)
  return X,y,sw
 if kind=='ill4096': return make_data(Case(kind,20000,4096,ill_conditioned=True),41,dtype='float32')
 if kind=='normal1024': return make_data(Case(kind,20000,1024),41,dtype='float32')
 if kind=='shift1024':
  X,y,sw=make_data(Case(kind,20000,1024),41,dtype='float32');X+=np.float32(1000);return X,y,sw
 raise ValueError(kind)

def score(X,y,sw,m):
 n,d=X.shape; W=np.asarray(m.coef_[0],dtype=np.float64);b=float(m.intercept_[0]);g=np.zeros(d);gb=loss=0.;sw_sum=float(n if sw is None else np.sum(sw))
 for start in range(0,n,256):
  sl=slice(start,min(start+256,n));x=np.asarray(X[sl],dtype=np.float64);z=x@W+b;yi=y[sl];s=np.ones(len(yi)) if sw is None else sw[sl];r=(expit(z)-yi)*s
  g+=x.T@r;gb+=sum(r);loss+=np.dot(s,np.logaddexp(0,z)-yi*z)
 g=g/sw_sum+W/sw_sum;obj=loss/sw_sum+.5*np.dot(W,W)/sw_sum
 return {'objective':obj,'gradient_max':max(float(np.max(np.abs(g))),abs(gb/sw_sum)),'gradient_l2':float(np.linalg.norm(g))}

results=[]
with threadpool_limits(limits=1),tuning_context(force_backend='mlx'):
 for kind in ['weighted_ill1024','ill4096','normal1024','shift1024']:
  X,y,sw=initial_data(kind)
  with warnings.catch_warnings(record=True) as refwarn:
   warnings.simplefilter('always'); ref=SkLR(C=1,tol=1e-4,max_iter=200).fit(X,y,sample_weight=sw)
  refscore=score(X,y,sw,ref)
  row={'kind':kind,'sklearn':refscore,'sklearn_warnings':[str(w.message) for w in refwarn],'models':[]}
  for factor in [1,.5,.25,.1,.05]:
   def restricted(X,y,sw,sw_sum,l2,fit_intercept,config,fun,**kw):
    return ORIGINAL(X,y,sw,sw_sum,l2,fit_intercept,replace(config,tol=config.tol*factor),fun,**kw)
   native_logistic.minimize_binary=restricted
   with warnings.catch_warnings(record=True) as warn:
    warnings.simplefilter('always');mx.synchronize();start=time.perf_counter()
    model=LogisticRegression(C=1,tol=1e-4,max_iter=200).fit(X,y,sample_weight=sw);mx.synchronize();elapsed=time.perf_counter()-start
   quality=score(X,y,sw,model);quality['relative_gap_to_sklearn']=(quality['objective']-refscore['objective'])/abs(refscore['objective'])
   datum={'factor':factor,'ms':elapsed*1000,'iterations':model.n_iter_.tolist(),'warnings':[str(w.message) for w in warn],'quality':quality}
   row['models'].append(datum);print(kind,datum,flush=True)
  results.append(row);Path('bench/accuracy_certificate/gpu_tolerance.json').write_text(json.dumps(results,indent=2)+'\n')
  native_logistic.minimize_binary=ORIGINAL
