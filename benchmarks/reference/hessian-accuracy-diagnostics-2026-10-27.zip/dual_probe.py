"""CPU-only numerical investigation of exact binary logistic primal-dual gaps.

Pure diagnostic; the library optimizer remains GPU-based. Tests whether a
mathematical certificate is practical at default sklearn tolerances.
"""
from pathlib import Path
import json
import warnings
import numpy as np
from scipy.special import expit, xlogy
from scipy.optimize import brentq
from sklearn.linear_model import LogisticRegression
from threadpoolctl import threadpool_limits


def make_case(weighted):
 r=np.random.default_rng(83 if weighted else 41); n=20000; d=1024
 x=r.standard_normal((n,d),dtype=np.float32)
 y=(x[:,0]+r.normal(scale=.5,size=n)>0).astype(int)
 x[:,512:]=x[:,:512]+.01*x[:,512:]
 x*=np.logspace(-1,1,d,dtype=np.float32)
 sw=r.uniform(.25,3,n) if weighted else np.ones(n)
 return x.astype(np.float64), y, sw

def score(x,y,sw,m):
 n,d=x.shape; alpha=sw/sw.sum(); lam=1/sw.sum()
 w=m.coef_[0].astype(np.float64); z=x@w; t=2*y-1
 b=brentq(lambda b: np.dot(alpha,t*expit(-t*(z+b))), -1000,1000,xtol=1e-13)
 q=expit(-t*(z+b)); v=x.T@(alpha*t*q)
 primal=float(np.dot(alpha,np.logaddexp(0,-t*(z+b)))+.5*lam*(w@w))
 dual=float(np.dot(alpha, -xlogy(q,q)-xlogy(1-q,1-q)) - (v@v)/(2*lam))
 g=lam*w-v
 return {'objective':primal,'duality_lower_bound':dual,'duality_gap':primal-dual,'relative_gap':(primal-dual)/primal,'feature_max_grad':float(np.max(np.abs(g))),'feature_l2_grad':float(np.linalg.norm(g)),'bias_adjustment':float(b-m.intercept_[0]),'iterations':m.n_iter_.tolist()}

if __name__=='__main__':
 out=[]
 with threadpool_limits(limits=1):
  for weighted in (False,True):
   x,y,sw=make_case(weighted)
   for tol in (1e-4,1e-5,1e-6,1e-7,1e-8):
    with warnings.catch_warnings(record=True) as w:
     warnings.simplefilter('always'); m=LogisticRegression(C=1,tol=tol,max_iter=2000).fit(x,y,sample_weight=sw if weighted else None)
    s=score(x,y,sw,m);s.update(weighted=weighted,tol=tol,warnings=[str(wi.message) for wi in w]);out.append(s);print(s,flush=True)
    Path('bench/accuracy_certificate/dual_probe.json').write_text(json.dumps(out,indent=2)+'\n')
