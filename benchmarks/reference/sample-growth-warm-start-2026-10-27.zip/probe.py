"""Scratch-only deterministic sample-growth warm-start probe.

The subset is a warm start, not an accuracy authority. Both stages spend the
same accepted-step budget, and the second stage uses the full original design
and existing direct certification. This probe is host-only, uses the managed
GPU continuation rather than an optimized native loop, and does not claim to
implement complete production fallback or evaluation-count accounting.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
import warnings
from pathlib import Path
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import mlx.core as mx
import numpy as np
from benchmarks.hessian_logistic import Case, dataset, independent_score, sources
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits

from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command, native_logistic
from mlxlearn._solvers.fused_lbfgs import _convergence_gradient_max
from mlxlearn._solvers.lbfgs import LBFGSState
from mlxlearn.linear_model import LogisticRegression


def fit_baseline(X, y, sw, C, max_iter):
    with tuning_context(force_backend="mlx", lbfgs_sketch_size=0):
        return LogisticRegression(C=C, tol=1e-4, max_iter=max_iter).fit(X, y, sample_weight=sw)


def fit_growth(X, y, sw, C, max_iter, subset_size, subset_budget, seed):
    rng = np.random.default_rng(seed)
    # A fixed independent permutation cannot assume the input was shuffled.
    idx = rng.choice(len(y), size=subset_size, replace=False)
    sx, sy = X[idx], y[idx]
    ssw = None if sw is None else sw[idx]
    total = float(len(y) if sw is None else np.sum(sw, dtype=np.float64))
    subtotal = float(len(sy) if ssw is None else np.sum(ssw, dtype=np.float64))
    if subtotal <= 0 or np.unique(sy if ssw is None else sy[ssw > 0]).size != 2:
        raise ValueError("sample does not contain two positive-weight classes")
    # Match the full-data L2 coefficient 1/(C * sum(weights)).
    subset_C = C * total / subtotal
    stage_warnings = []
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        small = fit_baseline(sx, sy, ssw, subset_C, subset_budget)
    stage_warnings = [{"category": w.category.__name__, "message": str(w.message)} for w in caught]
    spent = int(small.n_iter_[0])
    if spent >= max_iter:
        raise ValueError("subset exhausted the overall iteration budget")
    coef = np.asarray(small.coef_[0], dtype=np.float32)
    bias = float(small.intercept_[0])
    orig_run, orig_minimize = native_command.run_native_loop, native_logistic.minimize_binary
    events = []

    def initial_attempt(x, labels, weights, wsum, l2, fit_intercept, config, fun, **kw):
        center = kw.get("convergence_center")
        # The full solver optimizes centered coefficients but exports original
        # intercepts. Compute the centered bias from the actual applied center.
        center_host = np.zeros_like(coef) if center is None else np.asarray(center, dtype=np.float32)
        center_bias = np.float32(bias + np.dot(coef.astype(np.float64), center_host.astype(np.float64)))
        point = mx.array(np.append(coef, center_bias).astype(np.float32)).reshape(1, -1)
        objective, gradient = fun(point)
        norm = float(_convergence_gradient_max(gradient, center))
        if not math.isfinite(objective) or not math.isfinite(norm):
            raise ValueError("nonfinite full-data warm-start score")
        state = LBFGSState(x=point, objective=objective, grad_max_abs=norm, n_iter=spent,
                           n_fev=1, converged=False, stop_reason="uncertified")
        events.append({"subset_steps": spent, "full_start_objective": objective,
                       "full_start_gradient": norm})
        return native_command.NativeAttempt(state=state, gradient=gradient, status=1)

    def use_managed(*args, **kwargs):
        kwargs["use_native_loop"] = True
        return orig_minimize(*args, **kwargs)

    try:
        native_command.run_native_loop = initial_attempt
        native_logistic.minimize_binary = use_managed
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            model = fit_baseline(X, y, sw, C, max_iter)
        final_warnings = [{"category": w.category.__name__, "message": str(w.message)} for w in caught]
    finally:
        native_command.run_native_loop = orig_run
        native_logistic.minimize_binary = orig_minimize
    return model, {"subset_steps": spent, "subset_warnings": stage_warnings,
                   "final_warnings": final_warnings, "events": events,
                   "total_steps": int(model.n_iter_[0]), "subset_C": subset_C}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", choices=("normal", "ill", "weighted_ill", "rank"), default="normal")
    parser.add_argument("--seed", type=int, default=41)
    parser.add_argument("--subset", type=int, default=8000)
    parser.add_argument("--stage-steps", type=int, default=12)
    parser.add_argument("--samples", type=int, default=3)
    parser.add_argument("--output", type=Path, default=Path("bench/sample_grow/results.json"))
    args = parser.parse_args()
    case = Case(args.case, 20_000, 4_096, seed=args.seed,
                ill_conditioned=args.case in ("ill", "weighted_ill"),
                weighted=args.case == "weighted_ill", rank_deficient=args.case == "rank",
                C=1e6 if args.case == "rank" else 1)
    hashes = sources([Path(__file__).resolve()])
    with threadpool_limits(limits=1):
        X, y, sw, ratio = dataset(case)
        center = X.mean(axis=0, dtype=np.float64)
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            ref = SK(C=case.C, tol=1e-10, max_iter=3000).fit(X.astype(np.float64) - center, y, sample_weight=sw)
        ref_model = SimpleNamespace(coef_=ref.coef_, intercept_=ref.intercept_ - ref.coef_ @ center)
        reference, pred = independent_score(ref_model, X, y, sw, case.C, ratio)
        out = {"case": args.case, "seed": args.seed, "subset_size": args.subset,
               "subset_budget": args.stage_steps, "source_before": hashes, "reference": reference,
               "reference_warnings": [str(w.message) for w in caught], "samples": []}
        for repeat in range(args.samples + 1):
            row = {"repeat": repeat}
            for variant in (("baseline", "candidate") if repeat % 2 == 0 else ("candidate", "baseline")):
                with warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter("always")
                    mx.synchronize()
                    t = time.perf_counter()
                    if variant == "baseline":
                        model, meta = fit_baseline(X, y, sw, case.C, 200), {}
                    else:
                        model, meta = fit_growth(X, y, sw, case.C, 200, args.subset, args.stage_steps, 10000 + args.seed)
                    mx.synchronize()
                    elapsed = 1000 * (time.perf_counter() - t)
                score, _ = independent_score(model, X, y, sw, case.C, ratio, (reference["objective_float64"], pred))
                row[variant] = {"ms": elapsed, "n_iter": model.n_iter_.tolist(), "score": score,
                                "warnings": [str(w.message) for w in caught], **meta}
            out["samples"].append(row)
            print(json.dumps(row), flush=True)
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(out, indent=2) + "\n")
    out["source_after"] = sources([Path(__file__).resolve()])
    out["source_integrity_pass"] = out["source_before"] == out["source_after"]
    args.output.write_text(json.dumps(out, indent=2) + "\n")


if __name__ == "__main__":
    main()
