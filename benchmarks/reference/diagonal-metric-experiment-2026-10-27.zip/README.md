# Exploratory bounded-diagonal preconditioning

The native solver currently uses a scalar trace preconditioner. This experiment
monkeypatches `native_logistic.initial_from_parts` inside a separate Python
process, testing the scalar metric against reciprocal Hessian diagonals capped
at 2x, 8x, or 128x of the initial average diagonal. The Hessian diagonal was
already computed in the GPU preparation pass; no CPU numerical solver or
production source is changed. The cap does not enforce row-space preservation.

From the repository root run `PYTHONPATH=. python3
bench/diagonal_metric/experiment.py`. It performs two warmups and six
interleaved fresh public estimator fits per variant, with max_iter 200 and
tol 1e-4. Each timed fit is independently evaluated afterward in float64 on
its original data for objective gap, maximum gradient and prediction
agreement vs sklearn. Exact rank-deficient designs use X2=a*X1 where a is
alternately 2 or 0.5 (both exactly representable), C=1e6, and record
`norm(w2-a*w1)/norm(w)`. This residual need not be bounded by 1. It exposes
non-row-space coefficients that can change predictions away from the training
subspace while leaving the observed objective and gradient nearly unchanged.

These short panels are diagnostic, not a final benchmark. They did not record
in-run hashes or which internal loop handled each fit, so timings do not prove
native-loop completion or unchanged source/binary identity. Some scalar and
candidate fits pass the gradient threshold while failing the independent
one-sided objective quality threshold; all observations, including such rows,
are retained. The experiment tested only finite binary dense float32 inputs;
it does not guarantee convergence or quality for arbitrary inputs.

`compare_sklearn.py` adds a 12-repeat, three-warmup balanced comparison for the
two correlated datasets, including stock sklearn, native-loop completion,
source/binary integrity before and after, per-fit independent objective and
gradient, and warning status. Run it from the repository root with
`PYTHONPATH=. python3 bench/diagonal_metric/compare_sklearn.py`.

In the 12-repeat comparison, correlated ill-conditioned scalar/clip8/sklearn
warm medians were 72.13/17.77/56.95 ms; weighted correlated medians were
31.56/20.18/195.28 ms. The clip8 objective in the first case was 1.34e-5
relative worse than scalar. On the weighted case, scalar's objective was
+0.002903 relative to sklearn even though both independently met the 1e-4
gradient threshold and neither warned; clip8's gap was +2.87e-6. This is a
pre-existing failure of gradient convergence to ensure objective parity.

In the initial six-repeat rank-deficient panel at C=1e6, clip8 produced
`norm(w2-a*w1)/norm(w)` about 1.32 on both seeds (clip2 approximately 1.13),
while scalar remained zero. These candidates met the tested gradient and
objective checks but introduce null-space coefficients that can change
predictions outside the observed training subspace. No diagonal candidate is
proposed for production.
