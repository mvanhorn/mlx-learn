"""Scratch native-metric comparison; never patches the library on disk.

Build initial diagonal from the same preparation parts as production and clip
its inverse relative to the scalar trace metric. This prototype intentionally
does not claim the clip prevents null-space artifacts.
"""
import gc
import json
from pathlib import Path
import time
import warnings

import mlx.core as mx
import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits

from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_logistic
from mlxlearn.linear_model import LogisticRegression

orig = native_logistic.initial_from_parts

def limited_metric(ratio):
    @mx.compile
    def metric(parts, reg, denom):
        sums = mx.sum(parts,axis=1)/denom
        diagonal=sums[1]+reg
        average=mx.mean(diagonal)
        valid=mx.isfinite(average)&(average>1e-12)
        safe_average=mx.where(valid,average,1.)
        diag=mx.where(mx.isfinite(diagonal)&(diagonal>1e-12),diagonal,safe_average)
        diag=mx.clip(diag,safe_average/ratio,safe_average*ratio)
        return sums[0],mx.where(valid,1.0/diag,mx.ones_like(diag))
    return metric

metrics={'scalar':orig,'clip2':limited_metric(2.0),'clip8':limited_metric(8.0),'clip128':limited_metric(128.0)}

def data(kind,seed):
    rng=np.random.default_rng(seed);n,d=20000,1024
    X=rng.standard_normal((n,d),dtype=np.float32)
    y=(X[:,0]+rng.normal(scale=.5,size=n)>0).astype(np.int32)
    weights=None;C=1.0;ratio=None
    if kind in ('ill_conditioned','weighted_ill'):
        X[:,512:]=X[:,:512]+.01*X[:,512:]
        X*=np.logspace(-1,1,d,dtype=np.float32)
        if kind=='weighted_ill':weights=rng.uniform(.25,3.,n)
    if kind=='rank_deficient':
        # Powers of two are exactly representable in FP32; this is a true null
        # space, not a small empirical singular value caused by rounding.
        ratio=np.tile(np.array([2.,.5],dtype=np.float32),256)
        X[:,512:]=X[:,:512]*ratio
        C=1e6
    return X,y,weights,C,ratio

def score(m,ref,X,y,sw,C,ratio):
    n,d=X.shape;w=np.asarray(m.coef_[0],dtype=np.float64);b=float(m.intercept_[0])
    g=np.zeros(d);gb=loss=0.;sw_sum=float(n if sw is None else sw.sum()); agree=0
    rw=np.asarray(ref.coef_[0],dtype=np.float64);rb=float(ref.intercept_[0]);ref_loss=0.
    for start in range(0,n,256):
        stop=min(start+256,n);xx=np.asarray(X[start:stop],dtype=np.float64);yy=y[start:stop]
        a=xx@w+b;ra=xx@rw+rb;weight=np.ones(stop-start) if sw is None else sw[start:stop]
        resid=(expit(a)-yy)*weight;g+=xx.T@resid;gb+=resid.sum()
        loss+=np.dot(weight,np.logaddexp(0,a)-yy*a);ref_loss+=np.dot(weight,np.logaddexp(0,ra)-yy*ra)
        agree+=int(np.sum((a>=0)==(ra>=0)))
    g=g/sw_sum+w/(C*sw_sum);gb/=sw_sum
    obj=loss/sw_sum+.5*np.dot(w,w)/(C*sw_sum);ref_obj=ref_loss/sw_sum+.5*np.dot(rw,rw)/(C*sw_sum)
    null=None
    if ratio is not None:
        null=float(np.linalg.norm(w[512:]-ratio*w[:512])/max(np.linalg.norm(w),1e-30))
    return {'objective':obj,'relative_objective_gap_sklearn':(obj-ref_obj)/abs(ref_obj),'gradient_max_abs':max(float(np.max(np.abs(g))),abs(gb)),'prediction_agreement_sklearn':agree/n,'nullspace_coefficient_relative':null}

out={'method':'full fit interleaved, two warmups, original float64 objective and gradient every timed fit, tol 1e-4, max_iter 200','cases':[]}
with threadpool_limits(limits=1),tuning_context(force_backend='mlx'):
 for kind,seed in [('normal',41),('ill_conditioned',41),('weighted_ill',83),('rank_deficient',41),('rank_deficient',83)]:
    X,y,sw,C,ratio=data(kind,seed)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always');ref=SkLogisticRegression(C=C,max_iter=500,tol=1e-4).fit(X,y,sample_weight=sw)
    row={'case':kind,'seed':seed,'C':C,'reference_warnings':[str(w.message) for w in caught], 'records':[]}
    for i in range(-2,6):
      order=list(metrics)
      if i%2:order.reverse()
      order=order[(i%len(order)):]+order[:(i%len(order))]
      for variant in order:
        native_logistic.initial_from_parts=metrics[variant]
        with warnings.catch_warnings(record=True) as caught:
          warnings.simplefilter('always');mx.synchronize();gc.disable();start=time.perf_counter()
          try:
            model=LogisticRegression(C=C,max_iter=200,tol=1e-4).fit(X,y,sample_weight=sw)
            mx.synchronize();elapsed=time.perf_counter()-start
          finally:gc.enable()
        if i>=0:
          q=score(model,ref,X,y,sw,C,ratio)
          row['records'].append({'repeat':i,'variant':variant,'ms':elapsed*1000,'n_iter':model.n_iter_.tolist(),'warnings':[str(w.message) for w in caught],'quality':q})
    out['cases'].append(row)
    print(kind,seed,{v:round(float(np.median([r['ms'] for r in row['records'] if r['variant']==v])),3) for v in metrics},flush=True)
    Path('bench/diagonal_metric/results.json').write_text(json.dumps(out,indent=2)+'\n')
native_logistic.initial_from_parts=orig
