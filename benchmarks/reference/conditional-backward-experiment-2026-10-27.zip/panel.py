"""Interleaved full-fit experiment for conditional backward dispatch."""
import gc
import hashlib
import importlib.util
import json
import statistics
import time
import warnings
from pathlib import Path

import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits

from benchmarks.hessian_logistic import Case, dataset, independent_score
from benchmarks.logistic_wide import package_source_paths
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression

base = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("_metal_loop", base / "_metal_loop.so")
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
original_module, original_source = native_command._metal_loop, native_command._source
events = []


class Proxy:
    def __init__(self, module):
        self.module = module

    def run(self, *args):
        result = self.module.run(*args)
        events.append({"n_iter": result[1], "status": result[2], "n_fev": result[3]})
        return result


proxies = {"baseline": Proxy(original_module), "candidate": Proxy(candidate)}


def candidate_source(*args):
    source = original_source(*args)
    start = source.index("kernel void backward_kernel(")
    end = source.index("kernel void reduce_spec(", start)
    section = source[start:end]
    old = "device const bool& active [[buffer(2)]],\ndevice float* parts [[buffer(3)]]"
    new = "device const float* meta [[buffer(2)]],\nconstant float& alpha [[buffer(3)]],\ndevice float* parts [[buffer(4)]]"
    assert section.count(old) == 1
    section = section.replace(old, new)
    old = "// Coalesced feature loads, four row accumulators per feature, then a small"
    new = "if(meta[1]!=0 || meta[8]==alpha) return;\n// Coalesced feature loads, four row accumulators per feature, then a small"
    assert section.count(old) == 1
    section = section.replace(old, new).replace("if(col<P && active)", "if(col<P)")
    return source[:start] + section + source[end:]


def fit(variant, X, y, weights, case, sketch):
    events.clear()
    if variant == "candidate":
        native_command._metal_loop, native_command._source = proxies[variant], candidate_source
    elif variant == "baseline":
        native_command._metal_loop, native_command._source = proxies[variant], original_source
    else:
        native_command._metal_loop, native_command._source = original_module, original_source
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        mx.synchronize()
        enabled = gc.isenabled()
        gc.disable()
        try:
            start = time.perf_counter()
            if variant == "sklearn":
                model = SkLogisticRegression(C=case.C, tol=1e-4, max_iter=200).fit(X, y, sample_weight=weights)
            else:
                with tuning_context(force_backend="mlx", lbfgs_sketch_size=4 if sketch else 0):
                    model = LogisticRegression(C=case.C, tol=1e-4, max_iter=200).fit(X, y, sample_weight=weights)
            mx.synchronize()
            elapsed = 1000 * (time.perf_counter() - start)
        finally:
            if enabled:
                gc.enable()
    return model, elapsed, {"warnings": [{"category": w.category.__name__, "message": str(w.message)} for w in caught], "native_events": events.copy(), "n_iter": model.n_iter_.tolist()}


cases = [
    (Case("normal_1024", 20000, 1024), False),
    (Case("normal_4096", 20000, 4096), False),
    (Case("sketch_4096", 20000, 4096), True),
    (Case("weighted_ill_1024", 20000, 1024, seed=83, weighted=True, ill_conditioned=True), False),
    (Case("ill_4096", 20000, 4096, seed=41, ill_conditioned=True), True),
    (Case("rank_1024", 20000, 1024, rank_deficient=True, C=1e6), False),
    (Case("shift_1024", 20000, 1024, shifted=True), False),
]


def main():
    paths = package_source_paths() + [Path(original_module.__file__), base / "_metal_loop.so", base / "_metal_loop.mm", base / "build.py", base / "panel.py"]
    hashes = lambda: {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    output = {"source_integrity_before": hashes(), "cases": [], "method": "interleaved complete fits; 3 warmups, 10 samples; independent original float64 scores; one thread sklearn"}
    variants = ("baseline", "candidate", "sklearn")
    try:
        with threadpool_limits(limits=1):
            for case, sketch in cases:
                X, y, weights, ratio = dataset(case)
                samples = {v: [] for v in variants}
                models = {v: [] for v in variants}
                details = {v: [] for v in variants}
                for rep in range(13):
                    order = variants[rep % 3:] + variants[:rep % 3]
                    if rep % 2:
                        order = order[::-1]
                    for variant in order:
                        model, elapsed, detail = fit(variant, X, y, weights, case, sketch)
                        if rep >= 3:
                            samples[variant].append(elapsed)
                            models[variant].append(model)
                            details[variant].append(detail)
                ref, pr = independent_score(models["sklearn"][-1], X, y, weights, case.C, ratio)
                scores = {v: [independent_score(m, X, y, weights, case.C, ratio, (ref["objective_float64"], pr))[0] for m in group] for v, group in models.items()}
                failures = []
                for i, (a, b) in enumerate(zip(models["baseline"], models["candidate"], strict=True)):
                    if not np.array_equal(a.coef_, b.coef_) or not np.array_equal(a.intercept_, b.intercept_):
                        failures.append((i, "parameters"))
                    if details["baseline"][i] != details["candidate"][i]:
                        failures.append((i, "iterations_or_warning"))
                    if not details["candidate"][i]["native_events"]:
                        failures.append((i, "native_route_not_exercised"))
                    if scores["candidate"][i]["gradient_max_abs_float64"] > 1e-4:
                        failures.append((i, "gradient"))
                row = {"case": case.name, "sketch": sketch, "median_ms": {v: statistics.median(s) for v, s in samples.items()}, "samples_ms": samples, "scores": scores, "details": details, "failures": failures}
                output["cases"].append(row)
                print(case.name, row["median_ms"], "failures", failures[:4], flush=True)
                (base / "results.json").write_text(json.dumps(output, indent=2) + "\n")
    finally:
        native_command._metal_loop, native_command._source = original_module, original_source
    output["source_integrity_after"] = hashes()
    output["source_integrity_pass"] = output["source_integrity_before"] == output["source_integrity_after"]
    (base / "results.json").write_text(json.dumps(output, indent=2) + "\n")


if __name__ == "__main__":
    main()
