"""Build a scratch Metal loop with a conditional, fused backward dispatch."""
from pathlib import Path
import subprocess
import sysconfig

root = Path(__file__).resolve().parents[2]
base = Path(__file__).resolve().parent
source = (root / "src/mlxlearn/_solvers/_metal_loop.mm").read_text()
source = source.replace("MLXLearnRetainTestBufferV4", "MLXLearnRetainTestBufferFastBackward")
old = '''              bind(e,meta[next],0);[e setBytes:&alpha length:4 atIndex:1];bind(e,flag,2);
              dispatch(e,pl->active,1,1);
              bind(e,X.buffer,0,X.offset);bind(e,residual,1);bind(e,flag,2);bind(e,backparts,3);'''
new = '''              bind(e,X.buffer,0,X.offset);bind(e,residual,1);bind(e,meta[next],2);
              [e setBytes:&alpha length:4 atIndex:3];bind(e,backparts,4);'''
assert source.count(old) == 1
source = source.replace(old, new)
(base / "_metal_loop.mm").write_text(source)
cmd = ["clang++", "-O3", "-shared", "-fobjc-arc", "-std=c++17", "-undefined", "dynamic_lookup",
       "-framework", "Foundation", "-framework", "Metal", f'-I{sysconfig.get_path("include")}',
       str(base / "_metal_loop.mm"), "-o", str(base / "_metal_loop.so")]
subprocess.run(cmd, check=True)
