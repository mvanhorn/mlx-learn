"""Scratch one-pass Hessian action; production first probe S remains unchanged."""
from __future__ import annotations
import math
import mlx.core as mx

_hessian = mx.fast.metal_kernel(name='mlxlearn_scratch_hessian_only_2026_10_27', input_names=['X','S','sw','denom'], output_names=['parts'], source='\nuint tid=thread_position_in_threadgroup.x,lane=tid%32,sg=tid/32;\nuint group=threadgroup_position_in_grid.x;\nconstexpr uint V=(D+32*FEATURE_GROUPS-1)/(32*FEATURE_GROUPS);\nconstexpr uint CHUNK=V*32,DPAD=CHUNK*FEATURE_GROUPS;\nconstexpr uint ROW_GROUPS=GROUPS/FEATURE_GROUPS;\nconstexpr uint WG=ROW_GROUPS*DPAD, WB=GROUPS*K;\nconstexpr uint SCRATCH=WG>WB?WG:WB;\nuint fs=sg%FEATURE_GROUPS,rs=sg/FEATURE_GROUPS;\nthreadgroup float scratch[SCRATCH];\nfloat acc[K*V],bias[K];\nfor(uint k=0;k<K;++k){bias[k]=0;for(uint v=0;v<V;++v)acc[k*V+v]=0;}\nfor(uint rr=0;rr<ROWS;++rr){\n uint row=group*(ROW_GROUPS*ROWS)+rr*ROW_GROUPS+rs;\n float values[V],z[K];for(uint k=0;k<K;++k)z[k]=0;\n if(row<N && sw[row]>0){\n  for(uint v=0;v<V;++v){\n   uint col=fs*CHUNK+lane+v*32;float x=col<D?X[ulong(row)*D+col]:0.0f;values[v]=x;\n   if(col<D)for(uint k=0;k<K;++k)z[k]=fma(x,S[ulong(col)*K+k],z[k]);\n  }\n }else{for(uint v=0;v<V;++v)values[v]=0;}\n for(uint k=0;k<K;++k)z[k]=simd_sum(z[k]);\n if(FEATURE_GROUPS>1){\n  if(lane==0)for(uint k=0;k<K;++k)scratch[sg*K+k]=z[k];\n  threadgroup_barrier(mem_flags::mem_threadgroup);\n  for(uint k=0;k<K;++k){z[k]=0;for(uint f=0;f<FEATURE_GROUPS;++f)z[k]+=scratch[(rs*FEATURE_GROUPS+f)*K+k];}\n  threadgroup_barrier(mem_flags::mem_threadgroup);\n }\n for(uint k=0;k<K;++k){\n  float a=row<N && sw[row]>0 ? z[k]*denom*sw[row] : 0.0f;\n  if(fs==0 && lane==0)bias[k]+=a;\n  for(uint v=0;v<V;++v)acc[k*V+v]=fma(values[v],a,acc[k*V+v]);\n }\n}\nfor(uint k=0;k<K;++k){\n if(lane==0)scratch[sg]=bias[k];\n threadgroup_barrier(mem_flags::mem_threadgroup);\n if(sg==0 && lane==0 && P>D){float out=0;for(uint g=0;g<GROUPS;++g)out+=scratch[g];parts[(ulong(k)*B+group)*P+D]=out;}\n threadgroup_barrier(mem_flags::mem_threadgroup);\n for(uint v=0;v<V;++v){uint col=fs*CHUNK+lane+v*32;scratch[rs*DPAD+col]=acc[k*V+v];}\n threadgroup_barrier(mem_flags::mem_threadgroup);\n if(rs==0){for(uint v=0;v<V;++v){uint col=fs*CHUNK+lane+v*32;if(col<D){\n  float out=0;for(uint r=0;r<ROW_GROUPS;++r)out+=scratch[r*DPAD+col];\n  parts[(ulong(k)*B+group)*P+col]=out;\n }}}\n threadgroup_barrier(mem_flags::mem_threadgroup);\n}\n')

def _fused_action(X, features, sample_weight, sw_sum, l2, fit_intercept):
    n,d=X.shape;k=features.shape[1];p=d+int(fit_intercept)
    sw=mx.ones((n,),mx.float32) if sample_weight is None else sample_weight
    if d<=1024:groups,fg,rows=(4,1,32) if n>=16384 else (2,1,16)
    else:groups,fg,rows=(8,4,32 if d<=2048 else 64) if n>=16384 else (8,4,8)
    B=(n+(groups//fg)*rows-1)//((groups//fg)*rows)
    parts=_hessian(inputs=[X,features,sw,mx.array(.25/float(sw_sum),mx.float32)],
        template=[('N',n),('D',d),('P',p),('B',B),('K',k),('GROUPS',groups),('ROWS',rows),('FEATURE_GROUPS',fg)],
        grid=(B*groups*32,1,1),threadgroup=(groups*32,1,1),
        output_shapes=[(k,B,p)],output_dtypes=[mx.float32])[0]
    value=mx.sum(parts,axis=1)
    y_features=value[:,:d].T + float(l2)*features
    return y_features, value[:,d] if fit_intercept else None


def build_sketch_history(
    X,
    sample_weight,
    sw_sum,
    l2,
    fit_intercept,
    h0inv,
    *,
    history_size=10,
    sketch_size=4,
    seed=0,
    min_curvature=1e-12,
):
    """Construct GPU-resident curvature pairs for centered binary logistic X.

    The Hessian at zero logits is ``X.T @ diag(sw / 4) @ X / sw_sum + l2 I``.
    With sample-space Rademacher probes ``Omega``, all feature components of
    ``S = X.T @ Omega`` and ``Y = H @ S`` lie in ``range(X.T)`` in exact
    arithmetic.  Each probe has zero initial intercept component; ``Y`` also
    includes the corresponding Hessian cross term for a fitted intercept.

    Returns contiguous MLX float32 arrays ``(s, y, coefficients, count)``
    compatible with the native loop's history ring. Invalid, nonpositive, or
    numerically tiny curvature pairs are omitted. The returned arrays are
    caller-owned and need to remain alive while a submitted Metal command uses
    them. ``count == 0`` indicates the unseeded optimizer should be used.

    This is a preconditioner, not a loss approximation: the supplied design is
    the same float32 centered design that will be used by the optimizer. The
    caller remains responsible for validating input, weights, objective,
    original-coordinate gradient and floating-point precision.
    """
    if X.ndim != 2 or X.dtype != mx.float32:
        raise ValueError("X must be a two-dimensional float32 MLX array")
    n, d = X.shape
    p = d + int(fit_intercept)
    if n < 1 or d < 1:
        raise ValueError("X must have at least one row and column")
    if h0inv.shape != (p,) or h0inv.dtype != mx.float32:
        raise ValueError("h0inv must be a float32 vector matching parameter size")
    if sample_weight is not None and (
        sample_weight.shape != (n,) or sample_weight.dtype != mx.float32
    ):
        raise ValueError("sample_weight must be a row-aligned float32 MLX vector")
    if not isinstance(history_size, int) or history_size < 1:
        raise ValueError("history_size must be a positive integer")
    if not isinstance(sketch_size, int) or sketch_size < 0:
        raise ValueError("sketch_size must be a nonnegative integer")
    if not math.isfinite(float(sw_sum)) or sw_sum <= 0:
        raise ValueError("sw_sum must be finite and positive")
    if not math.isfinite(float(l2)) or l2 < 0:
        raise ValueError("l2 must be finite and nonnegative")
    if not math.isfinite(float(min_curvature)) or min_curvature < 0:
        raise ValueError("min_curvature must be finite and nonnegative")
    k = min(sketch_size, history_size, n, d)
    if k == 0:
        return (
            mx.zeros((history_size, p), dtype=mx.float32),
            mx.zeros((history_size, p), dtype=mx.float32),
            mx.zeros((history_size, 2), dtype=mx.float32),
            0,
        )

    key = mx.random.key(seed)
    uniform = mx.random.uniform(shape=(n, k), key=key, dtype=mx.float32)
    probes = mx.where(uniform < 0.5, -1.0, 1.0).astype(mx.float32)
    # Scaling by sqrt(n) before the multiplication limits accumulation range;
    # a nonfinite result is rejected below rather than stored in the history.
    probes = probes / math.sqrt(n)
    features = X.T @ probes
    # Normalize each projected probe before the Hessian products. A max-norm
    # pass avoids overflowing a squared norm for large, but finite, columns.
    maximum = mx.max(mx.abs(features), axis=0)
    finite_scale = mx.isfinite(maximum) & (maximum > 0)
    scaled = features / mx.where(finite_scale, maximum, 1.0)
    length = mx.sqrt(mx.sum(scaled * scaled, axis=0))
    valid_length = finite_scale & mx.isfinite(length) & (length > 0)
    features = scaled / mx.where(valid_length, length, 1.0)

    y_features, bias_y = _fused_action(X, features, sample_weight, sw_sum, l2, fit_intercept)
    if fit_intercept:
        s = mx.concatenate([features.T, mx.zeros((k, 1), dtype=mx.float32)], axis=1)
        y = mx.concatenate([y_features.T, bias_y[:, None]], axis=1)
    else:
        s, y = features.T, y_features.T
    sy = mx.sum(s * y, axis=1)
    yy = mx.sum(y * y * h0inv[None, :], axis=1)
    valid = (
        valid_length
        & mx.all(mx.isfinite(s), axis=1)
        & mx.all(mx.isfinite(y), axis=1)
        & mx.isfinite(sy)
        & mx.isfinite(yy)
        & (yy > 0)
        & (sy > float(min_curvature) * mx.maximum(yy, 1.0))
    )
    # A few scalar decisions cross to the host; no feature, training, or
    # optimizer vectors are read by the CPU or through NumPy.
    mx.eval(s, y, sy, yy, valid)
    selected = [i for i, ok in enumerate(valid.tolist()) if ok]
    count = len(selected)
    if count:
        indices = mx.array(selected, dtype=mx.int32)
        selected_s = mx.take(s, indices, axis=0)
        selected_y = mx.take(y, indices, axis=0)
        selected_sy = mx.take(sy, indices, axis=0)
        selected_yy = mx.take(yy, indices, axis=0)
        coefficients = mx.stack([1.0 / selected_sy, selected_sy / selected_yy], axis=1)
    else:
        selected_s = mx.zeros((0, p), dtype=mx.float32)
        selected_y = mx.zeros((0, p), dtype=mx.float32)
        coefficients = mx.zeros((0, 2), dtype=mx.float32)
    padding = history_size - count
    if padding:
        selected_s = mx.concatenate([selected_s, mx.zeros((padding, p), dtype=mx.float32)])
        selected_y = mx.concatenate([selected_y, mx.zeros((padding, p), dtype=mx.float32)])
        coefficients = mx.concatenate([coefficients, mx.zeros((padding, 2), dtype=mx.float32)])
    return selected_s, selected_y, coefficients, count
