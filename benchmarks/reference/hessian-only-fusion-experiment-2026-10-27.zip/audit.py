"""Check original probes and one-pass H action against float64."""
from __future__ import annotations
import json,sys
from pathlib import Path
import mlx.core as mx
import numpy as np
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).resolve().parent))
from fusion import build_sketch_history as fused
from mlxlearn._kernels.logistic_input import prepare_centered
from mlxlearn_device.hessian_sketch import build_sketch_history as current,initial_metric_from_parts


def main():
    results=[]
    with threadpool_limits(limits=1),mx.stream(mx.gpu):
      for n,d,shift,weighted,fit in [(257,513,0,False,True),(2048,512,1000,True,True),
                                      (2049,1025,0,True,False),(4097,2049,0,True,True),
                                      (3073,4095,0,False,True)]:
        rng=np.random.default_rng(19);X=rng.standard_normal((n,d),dtype=np.float32)+np.float32(shift)
        y=(rng.random(n)>.5).astype(np.float32);sw=rng.uniform(.1,3.,n).astype(np.float32) if weighted else np.ones(n,np.float32)
        if weighted:sw[::7]=0
        swsum=float(np.sum(sw,dtype=np.float64));l2=1.0/swsum;Xm=mx.array(X);ym=mx.array(y);wm=mx.array(sw)
        Xc,center,valid,parts=prepare_centered(Xm,ym,wm)
        reg=mx.concatenate([mx.full((d,),l2,mx.float32),mx.zeros((1,),mx.float32)]) if fit else mx.full((d,),l2,mx.float32)
        p=d+int(fit);h0=mx.ones((p,),mx.float32)
        if fit:_,h0=initial_metric_from_parts(parts,reg,mx.array(swsum,mx.float32))
        old=current(Xc,wm,swsum,l2,fit,h0,history_size=10,sketch_size=4)
        new=fused(Xc,wm,swsum,l2,fit,h0,history_size=10,sketch_size=4)
        mx.eval(Xc,center,valid,*old[:3],*new[:3]);mx.synchronize()
        os,oy=np.asarray(old[0]),np.asarray(old[1]);ns,ny=np.asarray(new[0]),np.asarray(new[1]);count=new[3]
        row={'n':n,'d':d,'shift':shift,'weighted':weighted,'intercept':fit,'old_count':old[3],'new_count':count,
             's_bitwise_equal':bool(np.array_equal(os.view(np.uint32),ns.view(np.uint32))),
             'y_max_abs_difference':float(np.max(np.abs(oy-ny)))}
        if count:
          A=np.asarray(Xc,dtype=np.float64);S=np.asarray(ns[:count,:d],dtype=np.float64).T;weight=sw.astype(np.float64)
          projection=A@S;Y=A.T@(projection*weight[:,None]*(.25/swsum))+l2*S
          expected=Y.T if not fit else np.concatenate([Y.T,np.sum(projection*weight[:,None],axis=0)[:,None]*(.25/swsum)],axis=1)
          row['y_independent_max_abs_error']=float(np.max(np.abs(ny[:count]-expected)))
        else:row['y_independent_max_abs_error']=float('inf')
        results.append(row);print(row,flush=True)
    Path('bench/hessian_only/audit.json').write_text(json.dumps(results,indent=2)+'\n')
    return int(any(not (r['s_bitwise_equal'] and r['old_count']==r['new_count'] and r['y_independent_max_abs_error']<1e-4) for r in results))
if __name__=='__main__':raise SystemExit(main())
