"""Validate sketch statistics against production and independent float64 math."""
from __future__ import annotations
import json,sys
from pathlib import Path
import mlx.core as mx
import numpy as np
from threadpoolctl import threadpool_limits
sys.path.insert(0,str(Path(__file__).resolve().parent))
from fusion import prepare,history_from_prepared
from mlxlearn._kernels.logistic_input import prepare_centered
from mlxlearn_device.hessian_sketch import build_sketch_history,initial_metric_from_parts

def main():
  results=[]
  with threadpool_limits(limits=1),mx.stream(mx.gpu):
   for n,d,shift,weighted in [(257,513,0,False),(2048,512,1000,True),(2049,1025,0,True),(4097,2049,0,True),(3073,4095,0,False)]:
    rng=np.random.default_rng(19);X=rng.standard_normal((n,d),dtype=np.float32)+np.float32(shift)
    y=(rng.random(n)>.5).astype(np.float32);sw=rng.uniform(.1,3.,n).astype(np.float32) if weighted else np.ones(n,np.float32)
    if weighted:sw[::7]=0
    swsum=float(np.sum(sw,dtype=np.float64));l2=1.0/swsum
    Xm=mx.array(X);ym=mx.array(y);wm=mx.array(sw);denom=mx.array(swsum,mx.float32)
    reg=mx.concatenate([mx.full((d,),l2,mx.float32),mx.zeros((1,),mx.float32)])
    oldX,oldcenter,oldfinite,oldparts=prepare_centered(Xm,ym,wm)
    newX,newcenter,newfinite,newparts,raw_s=prepare(Xm,ym,wm,k=4,seed=0)
    oldg,oldh=initial_metric_from_parts(oldparts,reg,denom);newg,newh=initial_metric_from_parts(newparts,reg,denom)
    old=build_sketch_history(oldX,wm,swsum,l2,True,oldh,history_size=10,sketch_size=4)
    new=history_from_prepared(newX,newparts,raw_s,wm,swsum,l2,history_size=10,h0inv=newh)
    mx.eval(oldX,oldcenter,oldfinite,oldparts,newX,newcenter,newfinite,newparts,raw_s,oldg,oldh,newg,newh,*old[:3],*new[:3]);mx.synchronize()
    oc,nc=np.asarray(oldX),np.asarray(newX)
    oldp,newp=np.asarray(oldparts),np.asarray(newparts)
    os,oy=np.asarray(old[0]),np.asarray(old[1]);ns,ny=np.asarray(new[0]),np.asarray(new[1])
    center_equal=bool(np.array_equal(np.asarray(oldcenter),np.asarray(newcenter)))
    orig_equal=bool(np.array_equal(oc,nc));parts_equal=bool(np.array_equal(oldp,newp))
    # Independent H0S in float64, using exactly the stored float32 S and Xc.
    fX=np.asarray(nc,dtype=np.float64);fs=np.asarray(ns[:new[3],:d],dtype=np.float64).T;ww=sw.astype(np.float64)
    projection=fX@fs
    hy=fX.T@((projection*ww[:,None])*(.25/swsum))+l2*fs
    bias=np.sum(projection*ww[:,None],axis=0)*(.25/swsum)
    reference=np.concatenate([hy.T,bias[:,None]],axis=1)
    error=float(np.max(np.abs(ny[:new[3]]-reference))) if new[3] else float('inf')
    deltaS=float(np.max(np.abs(os-ns)));deltaY=float(np.max(np.abs(oy-ny)))
    row={'n':n,'d':d,'shift':shift,'weighted':weighted,'old_count':old[3],'new_count':new[3],
         'center_equal':center_equal,'centered_equal':orig_equal,'initial_parts_equal':parts_equal,
         's_max_abs_difference':deltaS,'y_max_abs_difference':deltaY,'y_independent_max_abs_error':error}
    results.append(row);print(row,flush=True)
  Path('bench/multiprobe_fusion/audit.json').write_text(json.dumps(results,indent=2)+'\n')
  return int(any(not (r['center_equal'] and r['centered_equal'] and r['initial_parts_equal'] and r['old_count']==r['new_count'] and r['y_independent_max_abs_error']<1e-4) for r in results))
if __name__=='__main__':raise SystemExit(main())
