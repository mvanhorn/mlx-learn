# Fused multiprobe Hessian history experiments

Scratch research only; no production source changes. `fusion.py` fuses a four-
probe S=Xc.T@Omega with the centered input-copy/initial-statistics kernel and
then computes weighted Y=Xc.T@diag(sw/4)@Xc@S/sum(sw) in one tiled matrix
traversal. Its ordinary objective, line search and original-coordinate stopping
checks are unchanged. `--probe-mode random` retains the four original
Rademacher probes; `--probe-mode gradient` explicitly replaces one probe by the
initial weighted logistic residual.

`audit.py` validates five shapes, including row/feature tails, zero and uneven
weights and shift=1000. Centered X and existing initial statistics were bitwise
identical; independent float64 Hessian-product errors were at most 1.43e-8,
while the changed reduction order altered seed entries by up to 1.27e-7.

`benchmark.py` captures current live source+native binary hashes before and
after, uses 3 warmups and 8 alternating complete-fit repetitions, checks every
fit's independent float64 objective, original-coordinate gradient, prediction
agreement, native completion and warnings, and records rank-deficient null-space
coefficients. Timings include preparation, all sketch computation and export.
These are narrow exploratory panels on one machine, not general speed claims.

Random-probe fusion improved weighted ill 20k×1024 from 79.595 to 76.554 ms
(8/8 paired wins, 141→137 iterations) but slowed ill-conditioned 20k×4096 from
380.167 to 391.547 ms (0/8 wins, 165→170 iterations). Both satisfied the
independent gradient and 1e-5 objective-regression checks, but the slowdown
precludes an unconditional default. The residual probe did not accelerate the
weighted case, slowed ordinary 20k×1024, and produced an objective 1.03756e-5
relative worse than the baseline on ill-conditioned 4096, failing the stated
1e-5 no-regression gate despite its gradient passing. It must not be promoted.

Reproduce from the same source and runtime after unzipping into the project:

```
python3 bench/multiprobe_fusion/audit.py
python3 bench/multiprobe_fusion/benchmark.py --probe-mode random --repeats 8 --warmups 3
python3 bench/multiprobe_fusion/benchmark.py --probe-mode gradient --repeats 8 --warmups 3
```
