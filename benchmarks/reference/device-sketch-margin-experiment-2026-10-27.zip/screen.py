"""Scratch: reserve a tighter native tolerance for a seeded device attempt.

Only the native stop tolerance is changed; the independent compensated device
certificate, relative loss-progress requirement and original iteration budget
stay identical. This is a diagnostic script, not a production modification.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import statistics
import time
import warnings
from pathlib import Path
from types import SimpleNamespace

import mlx.core as mx
import numpy as np
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case, dataset, independent_score, sources
from benchmarks.sketch_weighted import benchmark_dataset
from mlxlearn_device import fit_logistic
from mlxlearn_device import _logistic as device_module

parser=argparse.ArgumentParser()
parser.add_argument('--output',default='bench/device_guard_new/screen.json')
parser.add_argument('--repeats',type=int,default=2)
parser.add_argument('--factors',type=float,nargs='+',default=[1.0,.975,.95,.90,.85])
parser.add_argument('--cases',nargs='+',default=['weighted_ill_41','weighted_ill_83','weighted_ill_2027','wide_1024','weighted_1024','shifted_1024','rank_1024','weighted_unbalanced','weighted_rare','wide_4096','ill_4096'])
args=parser.parse_args()
spec={
 'weighted_ill_41':Case('weighted_ill_41',20000,1024,seed=41,weighted=True,ill_conditioned=True),
 'weighted_ill_83':Case('weighted_ill_83',20000,1024,seed=83,weighted=True,ill_conditioned=True),
 'weighted_ill_2027':Case('weighted_ill_2027',20000,1024,seed=2027,weighted=True,ill_conditioned=True),
 'wide_1024':Case('wide_1024',20000,1024),
 'weighted_1024':Case('weighted_1024',20000,1024,weighted=True),
 'shifted_1024':Case('shifted_1024',20000,1024,shifted=True),
 'rank_1024':Case('rank_1024',20000,1024,rank_deficient=True,C=1e6),
 'weighted_unbalanced':Case('weighted_unbalanced_1024',20000,1024,seed=83,weighted=True),
 'weighted_rare':Case('weighted_rare_1024',20000,1024,seed=2027,weighted=True),
 'wide_4096':Case('wide_4096',20000,4096),
 'ill_4096':Case('ill_4096',20000,4096,ill_conditioned=True),
}
src=sources([Path(__file__).resolve()]); out={'source_before':src,'cases':[],'factors':args.factors}
original=device_module.metal_loop

class Run:
 def __init__(self,factor): self.factor=factor;self.events=[]
 def run(self,*args):
  vals=list(args); seeded=vals[15] is not None and vals[16]>0
  if seeded and self.factor != 1.0:
   vals[10]=float(np.nextafter(np.float32(vals[10]*self.factor),np.float32(0)))
  ret=original.run(*vals)
  self.events.append({'seeded':seeded,'tol':vals[10],'n_iter':ret[1],'status':ret[2],'last':ret[4],'previous':ret[5]})
  return ret

try:
 with threadpool_limits(limits=1):
  for name in args.cases:
   case=spec[name]; X,y,weights,ratio=benchmark_dataset(case)
   device=(mx.array(X),mx.array(y),None if weights is None else mx.array(weights,dtype=mx.float32))
   mx.eval(*(v for v in device if v is not None));mx.synchronize()
   samples={str(f):[] for f in args.factors};records={str(f):[] for f in args.factors};models={str(f):[] for f in args.factors}
   for rep in range(args.repeats+1):
    factors=args.factors[rep%len(args.factors):]+args.factors[:rep%len(args.factors)]
    if rep%2: factors=factors[::-1]
    for factor in factors:
     wrapper=Run(factor);device_module.metal_loop=wrapper
     with warnings.catch_warnings(record=True) as caught:
      warnings.simplefilter('always');mx.synchronize();start=time.perf_counter()
      model=fit_logistic(device[0],device[1],sample_weight=device[2],C=case.C,sketch_size=4,max_iter=200,tol=1e-4)
      mx.synchronize();elapsed=(time.perf_counter()-start)*1000
     if rep:
      samples[str(factor)].append(elapsed);models[str(factor)].append(model)
      records[str(factor)].append({'n_iter':model.n_iter,'converged':model.converged,'stop_reason':model.stop_reason,'used_fallback':model.used_unsketched_fallback_,'sketch_pairs':model.sketch_pairs_,'gradient':model.gradient_max_abs,'events':wrapper.events,'warnings':[{'category':w.category.__name__,'message':str(w.message)} for w in caught]})
   device_module.metal_loop=original
   scores={key:[independent_score(m,X,y,weights,case.C,ratio)[0] for m in group] for key,group in models.items()}
   baseline=scores.get('1.0',[None])[0]
   audits={}
   for key,group in scores.items():
    audits[key]=[{'gradient':s['gradient_max_abs_float64'],'objective':s['objective_float64'],'gap':(s['objective_float64']-baseline['objective_float64'])/abs(baseline['objective_float64']) if baseline else None,'null':s['nullspace_coefficient_relative']} for s in group]
   row={'name':name,'median_ms':{k:statistics.median(v) for k,v in samples.items()},'samples_ms':samples,'records':records,'quality':audits}
   out['cases'].append(row);print(name, {k:(round(v,2),records[k][0]['n_iter'],records[k][0]['converged'],records[k][0]['used_fallback'],audits[k][0]['gap']) for k,v in row['median_ms'].items()},flush=True)
   Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
finally:
 device_module.metal_loop=original
out['source_after']=sources([Path(__file__).resolve()]);out['source_integrity_passed']=out['source_before']==out['source_after'];Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
