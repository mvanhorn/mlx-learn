"""Verify seeded-tolerance reserve under bounded native iteration budgets."""
import json,time,warnings
import mlx.core as mx
import numpy as np
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case,dataset,independent_score
from mlxlearn_device import fit_logistic
from mlxlearn_device import _logistic as dev
case=Case('ill',20000,1024,seed=41,weighted=True,ill_conditioned=True)
with threadpool_limits(limits=1):
 X,y,weights,ratio=dataset(case);data=(mx.array(X),mx.array(y),mx.array(weights,dtype=mx.float32));mx.eval(*data)
 original=dev.metal_loop;rows=[]
 class Loop:
  def __init__(self,factor):self.factor=factor;self.events=[]
  def run(self,*args):
   v=list(args);seeded=v[15] is not None and v[16]>0
   if seeded and self.factor!=1:v[10]=float(np.nextafter(np.float32(v[10]*self.factor),np.float32(0)))
   z=original.run(*v);self.events.append({'n_iter':z[1],'status':z[2],'seeded':seeded});return z
 try:
  for budget in (1,3,151,152,153,154):
   for factor in (1,.95):
    loop=Loop(factor);dev.metal_loop=loop
    with warnings.catch_warnings(record=True) as caught:
     warnings.simplefilter('always');t=time.perf_counter();m=fit_logistic(data[0],data[1],sample_weight=data[2],C=1,sketch_size=4,tol=1e-4,max_iter=budget);mx.synchronize();elapsed=(time.perf_counter()-t)*1e3
    score,_=independent_score(m,X,y,weights,1,ratio)
    r={'budget':budget,'factor':factor,'n_iter':m.n_iter,'converged':m.converged,'fallback':m.used_unsketched_fallback_,'events':loop.events,'warnings':[str(w.message) for w in caught],'score':score,'ms':elapsed};rows.append(r);print(r,flush=True)
 finally:dev.metal_loop=original
open('bench/device_guard_new/budget.json','w').write(json.dumps(rows,indent=2)+'\n')
