"""Scratch device validation for the tightened wide progress condition."""
from __future__ import annotations
import json, statistics, time, warnings
from pathlib import Path
import mlx.core as mx
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case,dataset,independent_score,sources
from mlxlearn_device import fit_logistic
from mlxlearn_device import _logistic as dev

original=dev.metal_loop; saved=sources([Path(__file__).resolve()]);rows=[]
class Loop:
 def __init__(self,strict):self.strict=strict;self.events=[]
 def run(self,*args):
  v=list(args)
  if self.strict:
   old='WEIGHTED ? 0.025f : 1.0f'; new='(WEIGHTED || D>=2048) ? 0.025f : 1.0f'
   assert v[0].count(old)==1; v[0]=v[0].replace(old,new)
  if v[15] is not None and v[16]>0: v[10]=v[10]*.95
  result=original.run(*v);self.events.append({'tol':v[10],'n_iter':result[1],'status':result[2],'last':result[4],'previous':result[5]});return result
spec=[Case('wide_4096',20000,4096,seed=41),Case('wide_4096',20000,4096,seed=83),Case('ill_4096',20000,4096,seed=41,ill_conditioned=True),Case('ill_4096',20000,4096,seed=83,ill_conditioned=True)]
try:
 with threadpool_limits(limits=1):
  for case in spec:
   X,y,sw,ratio=dataset(case);data=(mx.array(X),mx.array(y));mx.eval(*data);mx.synchronize()
   for sketch in (0,4):
    times={str(v):[] for v in (False,True)};details={str(v):[] for v in (False,True)}
    for rep in range(3):
     for strict in ((False,True) if rep%2==0 else (True,False)):
      loop=Loop(strict);dev.metal_loop=loop
      with warnings.catch_warnings(record=True) as caught:
       warnings.simplefilter('always');mx.synchronize();start=time.perf_counter()
       m=fit_logistic(*data,C=case.C,sketch_size=sketch,max_iter=200,tol=1e-4);mx.synchronize();ms=1000*(time.perf_counter()-start)
      if rep:
       s,_=independent_score(m,X,y,sw,case.C,ratio);last=loop.events[-1];recent=abs(last['last']) if last['n_iter']<2 else .5*(abs(last['last'])+abs(last['previous']))
       strict_ok=last['n_iter']>=2 and recent<=2.5e-5*.025*max(abs(s['objective_float64']),1e-12)
       times[str(strict)].append(ms);details[str(strict)].append({'n_iter':m.n_iter,'converged':m.converged,'score':s,'warnings':[str(w.message) for w in caught],'fallback':m.used_unsketched_fallback_,'strict_ok':strict_ok,'events':loop.events})
    row={'case':case.name,'seed':case.seed,'sketch':sketch,'median':{k:statistics.median(v) for k,v in times.items()},'details':details};rows.append(row)
    print(case.name,case.seed,sketch,{k:(round(v,2),details[k][0]['n_iter'],details[k][0]['converged'],details[k][0]['strict_ok'],details[k][0]['fallback'],details[k][0]['score']['objective_float64']) for k,v in row['median'].items()},flush=True)
    Path('bench/device_guard_new/wide-progress.json').write_text(json.dumps({'cases':rows},indent=2)+'\n')
finally: dev.metal_loop=original
after=sources([Path(__file__).resolve()]);Path('bench/device_guard_new/wide-progress.json').write_text(json.dumps({'source_before':saved,'source_after':after,'integrity':saved==after,'cases':rows},indent=2)+'\n')
