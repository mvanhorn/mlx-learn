"""Interleaved full-fit and independent float64 audit for the fused sketch.

Scratch research only. Required source and binary hashes checked before/after;
all preparation, seed construction, fallback and model export are timed.
"""
from __future__ import annotations
import argparse, contextlib, gc, hashlib, json, sys, time, warnings
from pathlib import Path
import mlx.core as mx
import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression as SkLR
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).resolve().parent))
from fusion import prepare,history_from_prepared
from benchmarks.hessian_logistic import Case,dataset,independent_score
from mlxlearn._common.config import tuning_context
from mlxlearn._common.device import use_device
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression
from mlxlearn.linear_model import _logistic as est
import mlxlearn_device.hessian_sketch as sketch

@contextlib.contextmanager
def select(fused, probe_mode="random"):
    old_prep,old_sketch=est._prepare_centered_logistic_input,sketch.build_sketch_history
    old_command=native_command.run_native_loop;state={'parts':None,'raw_s':None,'Xc':None,'routes':[]}
    @contextlib.contextmanager
    def new_prep(X,y,weights,*,native):
        if not native:
            with old_prep(X,y,weights,native=native) as prepared:
                yield prepared
            return
        with use_device('gpu'):
            borrowed=mx.asarray(X); ym=mx.array(y,mx.float32)
            sw=None if weights is None else mx.array(weights,mx.float32)
            owned,center,finite,parts,raw_s=prepare(borrowed,ym,sw,k=4,seed=0,probe_mode=probe_mode)
            mx.eval(owned,center,finite,parts,raw_s)
            state.update(parts=parts,raw_s=raw_s,Xc=owned)
            try:yield owned,center,bool(finite),parts
            finally:mx.synchronize()
    def new_sketch(X,sw,sw_sum,l2,fit_intercept,h0inv,**kwargs):
        if not fit_intercept or state['Xc'] is not X:
            raise AssertionError('unexpected fallback, X or intercept in fusion prototype')
        if kwargs.get('sketch_size') != 4:
            raise AssertionError('prototype requires four probes')
        return history_from_prepared(X,state['parts'],state['raw_s'],sw,sw_sum,l2,
            history_size=kwargs.get('history_size',10),min_curvature=kwargs.get('min_curvature',1e-12),h0inv=h0inv)
    def count(*args,**kwargs):
        result=old_command(*args,**kwargs)
        if result is None:state['routes'].append('ineligible')
        else:
            stat=getattr(result,'state',result)
            state['routes'].append('converged' if stat.converged else stat.stop_reason)
        return result
    if fused:
        est._prepare_centered_logistic_input=new_prep;sketch.build_sketch_history=new_sketch
    native_command.run_native_loop=count
    try:yield state
    finally:
        est._prepare_centered_logistic_input=old_prep;sketch.build_sketch_history=old_sketch
        native_command.run_native_loop=old_command


def score_all(model,reference,X,y,weights,C,ratio):
    ref,refpred=independent_score(reference,X,y,weights,C,ratio)
    out,_=independent_score(model,X,y,weights,C,ratio,(ref['objective_float64'],refpred))
    return out


def hash_sources():
    paths=[p for d in (ROOT/'src/mlxlearn',ROOT/'src/mlxlearn_device') for p in d.rglob('*')
           if p.is_file() and '__pycache__' not in p.parts and (p.suffix in {'.py','.mm','.so'} or p.name=='py.typed')]
    paths += [Path(__file__).resolve(),Path(__file__).with_name('fusion.py').resolve(),ROOT/'benchmarks/hessian_logistic.py']
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--probe-mode',choices=('random','gradient'),default='random');parser.add_argument('--repeats',type=int,default=8);parser.add_argument('--warmups',type=int,default=3);parser.add_argument('--case',action='append');args=parser.parse_args()
    before=hash_sources();results={'method':f'GPU binary sklearn-compatible full fits: identical inputs, {args.warmups} warmups and {args.repeats} alternating repeats; scoring outside timed region on original input in float64, no sample discarded', 'probe_mode':args.probe_mode,'hashes_before':before,'cases':[]}
    cases=[Case('wide1024',20000,1024),Case('wide4096',20000,4096),Case('weightedill',20000,1024,seed=83,weighted=True,ill_conditioned=True),Case('ill4096',20000,4096,ill_conditioned=True),Case('rank',20000,1024,rank_deficient=True,C=1e6)]
    with threadpool_limits(limits=1):
      for case in cases:
       if args.case and case.name not in args.case:continue
       X,y,weights,ratio=dataset(case)
       with warnings.catch_warnings(record=True) as refwarn:
        warnings.simplefilter('always');ref=SkLR(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weights)
       models={'base':[],'fused':[]};records={'base':[],'fused':[]}
       for i in range(args.repeats+args.warmups):
        for variant in (('base','fused') if i%2==0 else ('fused','base')):
         with select(variant=='fused',args.probe_mode) as state, tuning_context(force_backend='mlx',lbfgs_sketch_size=4),warnings.catch_warnings(record=True) as caught:
          warnings.simplefilter('always');mx.synchronize();gc.disable();start=time.perf_counter()
          try:
           model=LogisticRegression(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weights)
           mx.synchronize();seconds=time.perf_counter()-start
          finally:gc.enable()
         if i>=args.warmups:
          models[variant].append(model);records[variant].append({'ms':seconds*1000,'n_iter':model.n_iter_.tolist(),'routes':state['routes'], 'warnings':[f'{x.category.__name__}: {x.message}' for x in caught]})
       for variant in models:
        for model,rec in zip(models[variant],records[variant],strict=True):
         rec['quality']=score_all(model,ref,X,y,weights,case.C,ratio)
       row={'case':case.name,'shape':[case.rows,case.features],'C':case.C,'ref_warnings':[str(w.message) for w in refwarn],'records':records}
       results['cases'].append(row)
       print(case.name,{v:round(float(np.median([rec['ms'] for rec in records[v]])),3) for v in records},flush=True)
       Path(f'bench/multiprobe_fusion/results-{args.probe_mode}.partial.json').write_text(json.dumps(results,indent=2)+'\n')
       del X,y,weights,ref,models
       mx.clear_cache()
    after=hash_sources();results['hashes_after']=after;results['source_integrity_pass']=before==after
    Path(f'bench/multiprobe_fusion/results-{args.probe_mode}.json').write_text(json.dumps(results,indent=2)+'\n')
    return 0 if results['source_integrity_pass'] else 1
if __name__=='__main__':raise SystemExit(main())
