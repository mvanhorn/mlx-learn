"""Held-out 1,024-feature four-probe fusion audit against unseeded/sklearn.

Fresh complete fits, balanced order, source/binary integrity and independent
float64 scoring of every fit. This is research code, not a production solver.
"""
from __future__ import annotations
import argparse,gc,hashlib,json,math,statistics,sys,time,warnings
from pathlib import Path
from types import SimpleNamespace
import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SkLR
from threadpoolctl import threadpool_limits

ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).resolve().parent))
from benchmark import select,hash_sources
from benchmarks.hessian_logistic import Case,dataset,independent_score
from mlxlearn._common.config import tuning_context
from mlxlearn.linear_model import LogisticRegression


def all_hashes():
    values=hash_sources();path=Path(__file__).resolve();values[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest();return values


def make_case(kind,seed):
    opts={'weighted':kind=='weighted_ill','ill_conditioned':kind=='weighted_ill',
          'shifted':kind=='shifted','rank_deficient':kind=='rank','C':1e6 if kind=='rank' else 1.0}
    return Case(kind,20000,1024,seed=seed,**opts)


def make_reference(sk,X,y,weights,case,warnings_):
    score,pred=independent_score(sk,X,y,weights,case.C,None)
    valid=math.isfinite(score['gradient_max_abs_float64']) and score['gradient_max_abs_float64']<=1e-4 and not any(w['category']=='ConvergenceWarning' for w in warnings_)
    if valid:return sk,score,pred,{'kind':'stock','n_iter':sk.n_iter_.tolist(),'warnings':warnings_}
    center=X.mean(axis=0,dtype=np.float64);centered=np.asarray(X,dtype=np.float64)-center
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always');m=SkLR(C=case.C,tol=1e-9,max_iter=3000).fit(centered,y,sample_weight=weights)
    ref=SimpleNamespace(coef_=m.coef_,intercept_=m.intercept_-m.coef_@center)
    tight,pred=independent_score(ref,X,y,weights,case.C,None)
    ws=[{'category':w.category.__name__,'message':str(w.message)} for w in caught]
    valid=math.isfinite(tight['gradient_max_abs_float64']) and tight['gradient_max_abs_float64']<=1e-4 and not any(w['category']=='ConvergenceWarning' for w in ws)
    return ref,tight,pred,{'kind':'centered_tight','n_iter':m.n_iter_.tolist(),'warnings':ws,'valid':valid,'stock_score':score}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--repeats',type=int,default=8);parser.add_argument('--warmups',type=int,default=3);parser.add_argument('--case',action='append',choices=('normal','weighted_ill','shifted','rank'));parser.add_argument('--seed',action='append',type=int);args=parser.parse_args()
    if args.repeats<1 or args.warmups<1:parser.error('positive repeats and warmups required')
    before=all_hashes();out={'method':'same-input complete fresh fits; rotated order; fit includes setup and verification, score every fit independently in original float64 outside timing','repeats':args.repeats,'warmups':args.warmups,'hashes_before':before,'cases':[]}
    variants=('unseeded','current4','fused4','sklearn')
    with threadpool_limits(limits=1):
      for kind in (args.case or ('normal','weighted_ill','shifted','rank')):
       for seed in (args.seed or (41,83,2027)):
        case=make_case(kind,seed);X,y,weights,ratio=dataset(case)
        fits={v:[] for v in variants};records={v:[] for v in variants}
        for i in range(args.warmups+args.repeats):
          order=variants[i%len(variants):]+variants[:i%len(variants)]
          if i%2:order=order[::-1]
          for variant in order:
           setting={} if variant=='sklearn' else {'force_backend':'mlx','lbfgs_sketch_size':0 if variant=='unseeded' else 4}
           with select(variant=='fused4','random') as state,tuning_context(**setting),warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always');mx.synchronize();before_gc=gc.isenabled();gc.disable();start=time.perf_counter()
            try:
             cls=SkLR if variant=='sklearn' else LogisticRegression
             model=cls(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weights);mx.synchronize();seconds=time.perf_counter()-start
            finally:
             if before_gc:gc.enable()
           if i>=args.warmups:
            fits[variant].append(model);records[variant].append({'ms':seconds*1000,'n_iter':model.n_iter_.tolist(),'routes':state['routes'],
                'warnings':[{'category':w.category.__name__,'message':str(w.message)} for w in caught]})
        reference,reference_score,reference_pred,ref_info=make_reference(fits['sklearn'][-1],X,y,weights,case,records['sklearn'][-1]['warnings'])
        for variant in variants:
         for model,record in zip(fits[variant],records[variant],strict=True):
          quality,_=independent_score(model,X,y,weights,case.C,ratio,(reference_score['objective_float64'],reference_pred))
          record['quality']=quality
        unseeded_obj=records['unseeded'][-1]['quality']['objective_float64'];baseline_obj=records['current4'][-1]['quality']['objective_float64']
        failures=[]
        refvalid=ref_info.get('valid',True)
        if not refvalid:failures.append({'variant':'reference','reason':'no trusted reference'})
        for variant in ('unseeded','current4','fused4'):
         for i,rec in enumerate(records[variant]):
          q=rec['quality'];grad=q['gradient_max_abs_float64'];obj=q['objective_float64'];gap=q['objective_relative_gap_to_sklearn'];agree=q['prediction_agreement_sklearn'];null=q['nullspace_coefficient_relative']
          reasons=[]
          if rec['warnings']:reasons.append('warning')
          if not rec['routes'] or rec['routes'][-1]!='converged':reasons.append('no native convergence')
          if not math.isfinite(grad) or grad>1e-4:reasons.append('original gradient')
          if not math.isfinite(obj) or not math.isfinite(gap) or (refvalid and gap>1e-5):reasons.append('objective vs reference')
          if not math.isfinite(agree) or agree<.995:reasons.append('prediction agreement')
          if null is not None and (not math.isfinite(null) or null>1e-3):reasons.append('nullspace coefficient')
          if variant=='fused4':
           rec['objective_relative_gap_to_current4']=(obj-baseline_obj)/max(abs(baseline_obj),np.finfo(float).tiny)
           rec['objective_relative_gap_to_unseeded']=(obj-unseeded_obj)/max(abs(unseeded_obj),np.finfo(float).tiny)
           if rec['objective_relative_gap_to_current4']>1e-5:reasons.append('objective vs current4')
           if rec['objective_relative_gap_to_unseeded']>1e-5:reasons.append('objective vs unseeded')
          if reasons:failures.append({'variant':variant,'fit':i,'reasons':reasons})
        row={'kind':kind,'seed':seed,'C':case.C,'reference':ref_info,'reference_score':reference_score,
             'median_ms':{v:statistics.median(x['ms'] for x in records[v]) for v in variants},
             'fused_paired_wins':sum(a['ms']<b['ms'] for a,b in zip(records['fused4'],records['current4'],strict=True)),
             'records':records,'failures':failures}
        out['cases'].append(row)
        print(kind,seed,{v:round(x,3) for v,x in row['median_ms'].items()},'wins',row['fused_paired_wins'],'failures',failures[:2],flush=True)
        Path('bench/multiprobe_fusion/heldout.partial.json').write_text(json.dumps(out,indent=2)+'\n')
        del X,y,weights,reference,fits;mx.clear_cache()
    out['hashes_after']=all_hashes();out['source_integrity_pass']=before==out['hashes_after']
    out['all_quality_pass']=all(not c['failures'] for c in out['cases'])
    Path('bench/multiprobe_fusion/heldout.json').write_text(json.dumps(out,indent=2)+'\n')
    return 0 if out['source_integrity_pass'] and out['all_quality_pass'] else 1
if __name__=='__main__':raise SystemExit(main())
