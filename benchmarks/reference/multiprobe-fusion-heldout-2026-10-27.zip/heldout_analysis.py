"""Separate model quality from a native-attempt route diagnostic.

The measured harness marks an unseeded native line-search failure as a failure,
even if the estimator subsequently performs its existing bounded intercept
polish and returns a converged model. Preserve raw records; this analysis
reports those cases separately and only removes that route label for the
unseeded estimator when the model has no warnings and all score tests passed.
"""
import json
from pathlib import Path

p=Path('benchmarks/results/multiprobe-fusion-heldout-2026-10-27.json')
r=json.loads(p.read_text())
rows=[]
for c in r['cases']:
 route=[];quality=[]
 for item in c['failures']:
  issues=[x for x in item['reasons'] if not (item['variant']=='unseeded' and x=='no native convergence')]
  if len(issues)<len(item['reasons']):route.append(item)
  if issues:quality.append({'variant':item['variant'],'fit':item['fit'],'reasons':issues})
 rows.append({'kind':c['kind'],'seed':c['seed'],'median_ms':c['median_ms'],
              'fused_paired_wins':c['fused_paired_wins'],'unseeded_native_route_events':route,
              'quality_failures':quality})
out={'note':'Raw harness flags unseeded initial native line-search failure as failure even when existing bounded GPU intercept polish then succeeds; this analysis separates that route observation from independent final-model quality. No fused or current4 failure is suppressed.',
     'source_integrity_pass':r['source_integrity_pass'],
     'all_final_model_quality_pass':all(not c['quality_failures'] for c in rows),'cases':rows}
Path('benchmarks/results/multiprobe-fusion-heldout-analysis-2026-10-27.json').write_text(json.dumps(out,indent=2)+'\n')
