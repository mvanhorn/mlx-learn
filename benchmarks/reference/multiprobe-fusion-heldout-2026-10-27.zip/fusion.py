"""Scratch fused four-probe GPU Hessian history. Not production code.

Fuse S=Xc.T@Omega into the centered copy/initial-statistics pass, then compute
Y=Xc.T@diag(sw/4)@Xc@S/sum(sw) in a single tiled feature traversal. Keep the
actual centered float32 design, penalty and intercept cross term. The ordinary
loss and stopping checks remain independent.
"""
from __future__ import annotations

import math
import mlx.core as mx

from mlxlearn._kernels.logistic_input import _center_and_check
from mlxlearn_device.hessian_sketch import initial_metric_from_parts

_prepare = mx.fast.metal_kernel(
    name='mlxlearn_scratch_prepare_multiprobe_2026_10_27',
    input_names=['X','center','y','sw','omega'],
    output_names=['owned','parts','s_parts'],
    source=r'''
uint tid=thread_position_in_threadgroup.x;
uint lane=tid%32,sg=tid/32;
uint col=threadgroup_position_in_grid.x*32+lane;
uint block=threadgroup_position_in_grid.y;
float grad=0,diag=0;float sketches[K];
for(uint k=0;k<K;++k)sketches[k]=0;
if(col<P){
 for(ulong row=ulong(block)*256+sg;row<min(ulong(N),(ulong(block)+1)*256);row+=4){
  float x=1.0f;
  if(col<D){
   ulong i=row*D+col;x=X[i]-center[col];owned[i]=x;
   for(uint k=0;k<K;++k)sketches[k]=fma(x,omega[row*K+k],sketches[k]);
  }
  float weight=sw[row];
  if(weight>0){grad+=x*(.5f-y[row])*weight;diag+=.25f*x*x*weight;}
 }
}
threadgroup float gp[128],hp[128],sp[128];
gp[tid]=grad;hp[tid]=diag;
threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==0 && col<P){
 parts[ulong(block)*P+col]=gp[lane]+gp[lane+32]+gp[lane+64]+gp[lane+96];
 parts[ulong(B)*P+ulong(block)*P+col]=hp[lane]+hp[lane+32]+hp[lane+64]+hp[lane+96];
}
threadgroup_barrier(mem_flags::mem_threadgroup);
for(uint k=0;k<K;++k){
 sp[tid]=sketches[k];threadgroup_barrier(mem_flags::mem_threadgroup);
 if(sg==0 && col<D)s_parts[(ulong(block)*K+k)*D+col]=sp[lane]+sp[lane+32]+sp[lane+64]+sp[lane+96];
 threadgroup_barrier(mem_flags::mem_threadgroup);
}
''',
)

_hessian = mx.fast.metal_kernel(
    name='mlxlearn_scratch_hessian_multiprobe_2026_10_27',
    input_names=['X','S','sw','denom'],
    output_names=['parts'],
    source=r'''
uint tid=thread_position_in_threadgroup.x,lane=tid%32,sg=tid/32;
uint group=threadgroup_position_in_grid.x;
constexpr uint V=(D+32*FEATURE_GROUPS-1)/(32*FEATURE_GROUPS);
constexpr uint CHUNK=V*32,DPAD=CHUNK*FEATURE_GROUPS;
constexpr uint ROW_GROUPS=GROUPS/FEATURE_GROUPS;
constexpr uint WG=ROW_GROUPS*DPAD, WB=GROUPS*K;
constexpr uint SCRATCH=WG>WB?WG:WB;
uint fs=sg%FEATURE_GROUPS,rs=sg/FEATURE_GROUPS;
threadgroup float scratch[SCRATCH];
float acc[K*V],bias[K];
for(uint k=0;k<K;++k){bias[k]=0;for(uint v=0;v<V;++v)acc[k*V+v]=0;}
for(uint rr=0;rr<ROWS;++rr){
 uint row=group*(ROW_GROUPS*ROWS)+rr*ROW_GROUPS+rs;
 float values[V],z[K];for(uint k=0;k<K;++k)z[k]=0;
 if(row<N && sw[row]>0){
  for(uint v=0;v<V;++v){
   uint col=fs*CHUNK+lane+v*32;float x=col<D?X[ulong(row)*D+col]:0.0f;values[v]=x;
   if(col<D)for(uint k=0;k<K;++k)z[k]=fma(x,S[ulong(col)*K+k],z[k]);
  }
 }else{for(uint v=0;v<V;++v)values[v]=0;}
 for(uint k=0;k<K;++k)z[k]=simd_sum(z[k]);
 if(FEATURE_GROUPS>1){
  if(lane==0)for(uint k=0;k<K;++k)scratch[sg*K+k]=z[k];
  threadgroup_barrier(mem_flags::mem_threadgroup);
  for(uint k=0;k<K;++k){z[k]=0;for(uint f=0;f<FEATURE_GROUPS;++f)z[k]+=scratch[(rs*FEATURE_GROUPS+f)*K+k];}
  threadgroup_barrier(mem_flags::mem_threadgroup);
 }
 for(uint k=0;k<K;++k){
  float a=row<N && sw[row]>0 ? z[k]*(.25f/denom)*sw[row] : 0.0f;
  if(fs==0 && lane==0)bias[k]+=a;
  for(uint v=0;v<V;++v)acc[k*V+v]=fma(values[v],a,acc[k*V+v]);
 }
}
for(uint k=0;k<K;++k){
 if(lane==0)scratch[sg]=bias[k];
 threadgroup_barrier(mem_flags::mem_threadgroup);
 if(sg==0 && lane==0 && P>D){float out=0;for(uint g=0;g<GROUPS;++g)out+=scratch[g];parts[(ulong(k)*B+group)*P+D]=out;}
 threadgroup_barrier(mem_flags::mem_threadgroup);
 for(uint v=0;v<V;++v){uint col=fs*CHUNK+lane+v*32;scratch[rs*DPAD+col]=acc[k*V+v];}
 threadgroup_barrier(mem_flags::mem_threadgroup);
 if(rs==0){for(uint v=0;v<V;++v){uint col=fs*CHUNK+lane+v*32;if(col<D){
  float out=0;for(uint r=0;r<ROW_GROUPS;++r)out+=scratch[r*DPAD+col];
  parts[(ulong(k)*B+group)*P+col]=out;
 }}}
 threadgroup_barrier(mem_flags::mem_threadgroup);
}
''',
)


def prepare(X, y, sw, *, k=4, seed=0, probe_mode="random"):
    """GPU centering + original initial statistics + projected probe partials."""
    n,d=X.shape;p=d+1;nb=(n+255)//256
    if sw is None:sw=mx.ones((n,),mx.float32)
    omega=mx.where(mx.random.uniform(shape=(n,k),key=mx.random.key(seed),dtype=mx.float32)<.5,-1.,1.).astype(mx.float32)/math.sqrt(n)
    if probe_mode == "gradient":
        first=((.5-y)*sw).reshape(n,1)/math.sqrt(n)
        omega=mx.concatenate([first,omega[:,1:]],axis=1)
    elif probe_mode != "random":
        raise ValueError("probe_mode must be random or gradient")
    center,finite=_center_and_check(X)
    Xc,parts,s_parts=_prepare(inputs=[X,center,y,sw,omega],
        template=[('N',n),('D',d),('P',p),('B',nb),('K',k)],
        grid=(((p+31)//32)*128,nb,1),threadgroup=(128,1,1),
        output_shapes=[X.shape,(2,nb,p),(nb,k,d)],output_dtypes=[mx.float32]*3)
    raw_s=mx.sum(s_parts,axis=0).T
    return Xc,center,finite,parts,raw_s


def history_from_prepared(Xc,parts,raw_s,sw,sw_sum,l2,*,history_size=10,min_curvature=1e-12,h0inv=None):
    """Seed ring from prepared S and one streaming weighted Hessian pass."""
    n,d=Xc.shape;p=d+1;k=raw_s.shape[1]
    if sw is None:sw=mx.ones((n,),mx.float32)
    if h0inv is None:
        reg=mx.concatenate([mx.full((d,),l2,mx.float32),mx.zeros((1,),mx.float32)])
        _,h0inv=initial_metric_from_parts(parts,reg,mx.array(sw_sum,mx.float32))
    maximum=mx.max(mx.abs(raw_s),axis=0)
    finite_scale=mx.isfinite(maximum)&(maximum>0)
    scaled=raw_s/mx.where(finite_scale,maximum,1.0)
    length=mx.sqrt(mx.sum(scaled*scaled,axis=0))
    valid_length=finite_scale&mx.isfinite(length)&(length>0)
    S=scaled/mx.where(valid_length,length,1.0)
    if d<=1024:groups,fg,rows=(4,1,32) if n>=16384 else (2,1,16)
    else:groups,fg,rows=(8,4,32 if d<=2048 else 64) if n>=16384 else (8,4,8)
    B=(n+(groups//fg)*rows-1)//((groups//fg)*rows)
    P=_hessian(inputs=[Xc,S,sw,mx.array(sw_sum,mx.float32)],
        template=[('N',n),('D',d),('P',p),('B',B),('K',k),('GROUPS',groups),('ROWS',rows),('FEATURE_GROUPS',fg)],
        grid=(B*groups*32,1,1),threadgroup=(groups*32,1,1),
        output_shapes=[(k,B,p)],output_dtypes=[mx.float32])[0]
    yp=mx.sum(P,axis=1)
    y=mx.concatenate([yp[:,:d]+l2*S.T,yp[:,d:]],axis=1)
    s=mx.concatenate([S.T,mx.zeros((k,1),mx.float32)],axis=1)
    sy=mx.sum(s*y,axis=1); yy=mx.sum(y*y*h0inv[None,:],axis=1)
    valid=valid_length&mx.all(mx.isfinite(s),axis=1)&mx.all(mx.isfinite(y),axis=1)&mx.isfinite(sy)&mx.isfinite(yy)&(yy>0)&(sy>min_curvature*mx.maximum(yy,1.0))
    mx.eval(s,y,sy,yy,valid)
    selected=[i for i,v in enumerate(valid.tolist()) if v];count=len(selected)
    if count:
        idx=mx.array(selected,mx.int32);ss=mx.take(s,idx,axis=0);ys=mx.take(y,idx,axis=0)
        rho=mx.stack([1.0/mx.take(sy,idx),mx.take(sy,idx)/mx.take(yy,idx)],axis=1)
    else:
        ss=mx.zeros((0,p),mx.float32);ys=mx.zeros((0,p),mx.float32);rho=mx.zeros((0,2),mx.float32)
    pad=history_size-count
    if pad:
        ss=mx.concatenate([ss,mx.zeros((pad,p),mx.float32)]);ys=mx.concatenate([ys,mx.zeros((pad,p),mx.float32)]);rho=mx.concatenate([rho,mx.zeros((pad,2),mx.float32)])
    return ss,ys,rho,count
