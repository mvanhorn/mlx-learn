"""Run one isolated prior-bias fit; parent process enforces a hard timeout."""
import faulthandler, importlib.util, sys
from pathlib import Path
base=Path(__file__).resolve().parent
variant=sys.argv[1]
faulthandler.dump_traceback_later(8, repeat=False)
sys.path.insert(0,str(base.parents[1]));sys.path.insert(0,str(base/'baseline'))
import mlx.core as mx
import numpy as np
from scipy.special import expit
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression
path=base/variant/'mlxlearn/_solvers/native_command.py'
spec=importlib.util.spec_from_file_location('mlxlearn._solvers.prior_command',path)
mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
spec=importlib.util.spec_from_file_location('_prior_bias._metal_loop',base/variant/'mlxlearn/_solvers/_metal_loop.abi3.so')
ext=importlib.util.module_from_spec(spec);spec.loader.exec_module(ext)
mod.NativeAttempt=native_command.NativeAttempt;mod._metal_loop=ext;native_command.run_native_loop=mod.run_native_loop
rng=np.random.default_rng(41);n,d=8192,512
X=rng.standard_normal((n,d),dtype=np.float32);y=(X[:,0]>np.quantile(X[:,0],.9)).astype(np.int32);w=rng.uniform(.25,3.,n)
print('fit start',variant,flush=True)
with tuning_context(force_backend='mlx'):
 model=LogisticRegression(C=1.0,tol=1e-4,max_iter=200).fit(X,y,sample_weight=w)
print('fit finished',model.n_iter_.tolist(),flush=True)
mx.synchronize()
print('sync finished',flush=True)
coef=model.coef_[0];raw=X.astype(np.float64)@coef+model.intercept_[0]
loss=np.sum(w*(np.logaddexp(0,raw)-y*raw))/w.sum()+coef@coef/(2*w.sum())
grad=(X.astype(np.float64).T@(w*(expit(raw)-y))+coef)/w.sum()
print('loss',loss,'grad max',float(np.max(np.abs(grad))),flush=True)
faulthandler.cancel_dump_traceback_later()
