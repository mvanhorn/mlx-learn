"""Run isolated GIL hang probes with a hard deadline and preserved output."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
results=[]
for variant in ('candidate','pinned'):
 with (root/(variant+'-repro.log')).open('w') as log:
  start=time.perf_counter()
  try:
   cp=subprocess.run([sys.executable,str(root/'test_single.py'),variant],stdout=log,stderr=subprocess.STDOUT,timeout=15,check=False)
   status=cp.returncode
  except subprocess.TimeoutExpired:
   status='timeout-killed'
  elapsed=time.perf_counter()-start
 results.append({'variant':variant,'status':status,'seconds':elapsed,'log':(root/(variant+'-repro.log')).read_text()})
 print(variant,status,round(elapsed,3),flush=True)
files=[root/'run_repro.py',root/'test_single.py']+[root/v/'mlxlearn/_solvers/native_command.py' for v in ('candidate','pinned')]+[root/v/'mlxlearn/_solvers/_metal_loop.abi3.so' for v in ('candidate','pinned')]
payload={'results':results,'files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'timeout_seconds':15}
(root/'repro-results.json').write_text(json.dumps(payload,indent=2)+'\n')
