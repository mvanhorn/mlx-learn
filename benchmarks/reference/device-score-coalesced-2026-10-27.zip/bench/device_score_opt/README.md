# Coalesced compensated gradient prototype

This source-only archive preserves a scratch two-pass compensated gradient
kernel that coalesces row-major feature loads. It is not production code and
has no general proof of numerical equivalence. Component timing excludes
forward scoring, upload and compilation; the full-fit panel includes sketch,
optimizer, original-input scoring and fallback with resident device inputs.
Both use independent float64 checks. See results and per-fit details separately.

The included `src/mlxlearn_device/_compensated.py` is the **exact** version
used during these measurements, reconstructed after a subsequent zero-weight
safety fix and verified byte-for-byte against both in-run SHA-256 records. That
older source is provided solely for inspection; it lacks the later fix and
must not be substituted into production. The full-fit `_logistic.py` source
changed after measurement and the exact older version was unavailable when
this archive was created. Its measured SHA-256 remains in the result; a newer
version is included separately under `post-measurement/`. The in-run audit
recorded the native extension binary SHA-256; this archive does not distribute
the binary. Thus exact reproduction of the full-fit run is not available from
this archive alone.

To repeat the experiments on a later checkout, place the scratch scripts in
that checkout and run `PYTHONPATH=src python3 bench/device_score_opt/evaluate.py`
and `PYTHONPATH=src python3 bench/device_score_opt/full_fit.py`. This uses its
current scorer and solver, so results need not reproduce the older run. Runtime
and compiled binary also vary with OS, compiler, Python, MLX, and Apple GPU.
Timed fit data are generated with NumPy; the device fit itself does not use it.
