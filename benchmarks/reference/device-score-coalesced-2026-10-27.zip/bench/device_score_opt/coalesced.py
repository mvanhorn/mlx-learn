"""Scratch coalesced compensated gradient evaluator; not production code.

The initial kernel maps SIMD lanes to contiguous features and partitions rows
into 256-sample blocks. A second kernel combines high/low block partials with
compensated arithmetic and applies the same regularizer as the reference.
"""

from __future__ import annotations

import mlx.core as mx

from mlxlearn_device._compensated import _HEADER

_partial = mx.fast.metal_kernel(
    name="mlxlearn_scratch_compensated_gradient_partial_v1",
    header=_HEADER,
    input_names=["X", "resid_hi", "resid_lo"],
    output_names=["part_hi", "part_lo"],
    source=r"""
uint t=thread_position_in_threadgroup.x;
uint lane=t%32, sg=t/32;
uint col=threadgroup_position_in_grid.x*32+lane;
uint block=threadgroup_position_in_grid.y;
float2 value=float2(0.0f);
if(col<P){
 for(uint row=block*256+sg;row<min(uint(N),(block+1)*256);row+=4){
  float x=col<D?X[ulong(row)*D+col]:1.0f;
  value=add2(value,mul2(float2(x,0),float2(resid_hi[row],resid_lo[row])));
 }
}
threadgroup float2 scratch[128];
scratch[t]=value;
threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==0 && col<P){
 float2 out=add2(add2(scratch[lane],scratch[lane+32]),add2(scratch[lane+64],scratch[lane+96]));
 part_hi[ulong(block)*P+col]=out.x;
 part_lo[ulong(block)*P+col]=out.y;
}
""",
)

_finish = mx.fast.metal_kernel(
    name="mlxlearn_scratch_compensated_gradient_finish_v1",
    header=_HEADER,
    input_names=["part_hi", "part_lo", "theta", "l2"],
    output_names=["grad_hi", "grad_lo"],
    source=r"""
uint t=thread_position_in_threadgroup.x;
uint lane=t%32, sg=t/32;
uint col=threadgroup_position_in_grid.x*32+lane;
float2 value=float2(0.0f);
if(col<P){
 for(uint block=sg;block<B;block+=4){
  ulong i=ulong(block)*P+col;
  value=add2(value,float2(part_hi[i],part_lo[i]));
 }
}
threadgroup float2 scratch[128];
scratch[t]=value;
threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==0 && col<P){
 float2 g=add2(add2(scratch[lane],scratch[lane+32]),add2(scratch[lane+64],scratch[lane+96]));
 if(col<D)g=add2(g,mul2(float2(l2[0],l2[1]),float2(theta[col],0)));
 grad_hi[col]=g.x;
 grad_lo[col]=g.y;
}
""",
)


def coalesced_backward(X, theta, resid_hi, resid_lo, denom, l2):
    """Return compensated original-coordinate gradient high/low parts.

    The signature matches the reference Metal kernel's inputs. ``denom`` is
    unused because residuals are already normalized, matching the reference.
    """
    del denom
    n, d = X.shape
    p = d + 1
    blocks = (n + 255) // 256
    groups = (p + 31) // 32
    hi, lo = _partial(
        inputs=[X, resid_hi, resid_lo],
        template=[("N", n), ("D", d), ("P", p)],
        grid=(groups * 128, blocks, 1),
        threadgroup=(128, 1, 1),
        output_shapes=[(blocks, p), (blocks, p)],
        output_dtypes=[mx.float32, mx.float32],
    )
    return _finish(
        inputs=[hi, lo, theta, l2],
        template=[("D", d), ("P", p), ("B", blocks)],
        grid=(groups * 128, 1, 1),
        threadgroup=(128, 1, 1),
        output_shapes=[(p,), (p,)],
        output_dtypes=[mx.float32, mx.float32],
    )


def kernel_adapter(*, inputs, **_kwargs):
    """Temporary replacement for _compensated._backward in tests only."""
    return coalesced_backward(*inputs)
