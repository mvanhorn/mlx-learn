"""Balanced scratch comparison of coalesced compensated gradient reductions.

All samples and failures are preserved. The GPU timer excludes data generation,
forward residual calculation, MLX compilation/warmup, transfers, and the
independent float64 score. The benchmark does NOT time a full estimator fit.
"""

from __future__ import annotations

import functools
import hashlib
import json
import statistics
import time
from pathlib import Path

import mlx.core as mx
import numpy as np
from coalesced import coalesced_backward
from scipy.special import expit
from threadpoolctl import threadpool_limits

from mlxlearn_device import _compensated as core

ROOT = Path(__file__).resolve().parents[2]


def case_data(n, d, *, seed, shift=0.0, weighted=False, rank_deficient=False):
    rng = np.random.default_rng(seed)
    X = rng.standard_normal((n, d), dtype=np.float32)
    y = rng.integers(0, 2, n).astype(np.float32)
    if rank_deficient:
        half = d // 2
        ratio = np.tile(np.array([2.0, 0.5], dtype=np.float32), half // 2)
        X[:, half:] = X[:, :half] * ratio
    if shift:
        X += np.float32(shift)
    center = np.mean(X, axis=0, dtype=np.float64).astype(np.float32)
    theta = np.concatenate(
        [rng.normal(scale=0.02, size=d).astype(np.float32), np.array([0.1], dtype=np.float32)]
    )
    sw = (
        rng.uniform(0.25, 3.0, size=n).astype(np.float32)
        if weighted
        else np.ones(n, dtype=np.float32)
    )
    return X, y, center, theta, sw


def independent(X, y, center, theta, weights, sw_sum, l2):
    n, d = X.shape
    c = center.astype(np.float64)
    w = theta[:-1].astype(np.float64)
    b = float(theta[-1])
    grad = np.zeros(d, dtype=np.float64)
    bias = loss = 0.0
    for start in range(0, n, 256):
        stop = min(start + 256, n)
        block = X[start:stop].astype(np.float64)
        logits = (block - c) @ w + b
        residual = (expit(logits) - y[start:stop]) * weights[start:stop] / sw_sum
        grad += block.T @ residual
        bias += residual.sum()
        loss += (
            np.sum((np.logaddexp(0.0, logits) - y[start:stop] * logits) * weights[start:stop])
            / sw_sum
        )
    grad += l2 * w
    return float(loss + 0.5 * l2 * (w @ w)), np.concatenate([grad, [bias]])


def paths():
    return [
        Path(__file__),
        Path(__file__).with_name("coalesced.py"),
        ROOT / "src/mlxlearn_device/_compensated.py",
    ]


def hashes():
    return {str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths()}


def main():
    cases = [
        ("normal", 20_000, 1024, 0.0, False, False),
        ("weighted_shifted", 20_000, 1024, 1_000.0, True, False),
        ("large_shift", 20_000, 1024, 10_000.0, True, False),
        ("wide", 20_000, 4096, 0.0, False, False),
        ("rank_deficient", 20_000, 1024, 0.0, False, True),
    ]
    output = {
        "method": "20 balanced kernel-only repeats after three warmups; float64 independent reference and source hashes, not an end-to-end fit",
        "source_before": hashes(),
        "cases": [],
    }
    with threadpool_limits(limits=1), mx.stream(mx.gpu):
        for name, n, d, shift, weighted, rank in cases:
            X, y, center, theta, sw = case_data(
                n, d, seed=41, shift=shift, weighted=weighted, rank_deficient=rank
            )
            sw_sum = float(np.sum(sw.astype(np.float64)))
            l2 = 1 / sw_sum
            ref_loss, ref_grad = independent(X, y, center, theta, sw, sw_sum, l2)
            Xd, yd, cd, td, wd = (
                mx.array(X),
                mx.array(y),
                mx.array(center),
                mx.array(theta),
                mx.array(sw),
            )
            denom = mx.array(core._split(sw_sum), dtype=mx.float32)
            penalty = mx.array(core._split(l2), dtype=mx.float32)
            hi, lo, _, _ = core._forward(
                inputs=[Xd, cd, td, yd, wd, denom],
                template=[("N", n), ("D", d)],
                grid=(((n + 3) // 4) * 128, 1, 1),
                threadgroup=(128, 1, 1),
                output_shapes=[(n,)] * 4,
                output_dtypes=[mx.float32] * 4,
            )
            mx.eval(Xd, yd, cd, td, wd, hi, lo, penalty)

            functions = {
                "old": functools.partial(
                    core._backward,
                    inputs=[Xd, td, hi, lo, denom, penalty],
                    template=[("N", n), ("D", d)],
                    grid=((d + 1) * 32, 1, 1),
                    threadgroup=(32, 1, 1),
                    output_shapes=[(d + 1,), (d + 1,)],
                    output_dtypes=[mx.float32, mx.float32],
                ),
                "new": functools.partial(coalesced_backward, Xd, td, hi, lo, denom, penalty),
            }
            samples = {v: [] for v in functions}
            outputs = {}
            for i in range(23):
                order = ("old", "new") if i % 2 == 0 else ("new", "old")
                for v in order:
                    mx.synchronize()
                    start = time.perf_counter()
                    out = functions[v]()
                    mx.eval(*out)
                    mx.synchronize()
                    seconds = time.perf_counter() - start
                    if i >= 3:
                        samples[v].append(seconds * 1000)
                        outputs[v] = out
            values = {
                v: np.asarray(a[0], dtype=np.float64) + np.asarray(a[1], dtype=np.float64)
                for v, a in outputs.items()
            }
            errors = {v: float(np.max(np.abs(g - ref_grad))) for v, g in values.items()}
            diff = float(np.max(np.abs(values["old"] - values["new"])))
            rec = {
                "name": name,
                "shape": [n, d],
                "shift": shift,
                "weighted": weighted,
                "rank_deficient": rank,
                "reference_objective": ref_loss,
                "reference_gradient_max_abs": float(np.max(np.abs(ref_grad))),
                "median_ms": {v: statistics.median(t) for v, t in samples.items()},
                "samples_ms": samples,
                "max_abs_error_vs_float64": errors,
                "max_abs_difference_between_gpu_methods": diff,
                "gradient_norms": {v: float(np.max(np.abs(g))) for v, g in values.items()},
            }
            output["cases"].append(rec)
            print(name, rec["median_ms"], errors, "diff", diff, flush=True)
            Path("bench/device_score_opt/results.json").write_text(
                json.dumps(output, indent=2) + "\n"
            )
            del functions, X, y, center, theta, sw, Xd, yd, cd, td, wd, hi, lo, outputs, values
            mx.clear_cache()
    output["source_after"] = hashes()
    output["source_integrity_pass"] = output["source_before"] == output["source_after"]
    Path("bench/device_score_opt/results.json").write_text(json.dumps(output, indent=2) + "\n")


if __name__ == "__main__":
    main()
