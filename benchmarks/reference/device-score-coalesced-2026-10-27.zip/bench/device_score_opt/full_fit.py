"""Interleaved complete-device-fit comparison for the coalesced scorer.

Includes sketch, preprocessing, optimizer, compensated score, and fallback.
Input arrays are already resident; upload is excluded and documented.
Every measured model is independently scored on the original input in float64.
The result does not claim performance outside the tested cases.
"""

from __future__ import annotations

import hashlib
import json
import statistics
import time
import warnings
from pathlib import Path

import mlx.core as mx
import numpy as np
from coalesced import kernel_adapter
from scipy.special import expit
from threadpoolctl import threadpool_limits

from mlxlearn_device import _compensated as core
from mlxlearn_device import fit_logistic

ROOT = Path(__file__).resolve().parents[2]


def dataset(n, d, seed, *, weighted=False, shifted=False, rank=False, ill=False):
    rng = np.random.default_rng(seed)
    X = rng.standard_normal((n, d), dtype=np.float32)
    y = (X[:, 0] + rng.normal(scale=0.5, size=n) > 0).astype(np.int32)
    ratio = None
    if ill:
        half = d // 2
        X[:, half:] = X[:, :half] + 0.01 * X[:, half:]
        X *= np.logspace(-1, 1, d, dtype=np.float32)
    if rank:
        half = d // 2
        ratio = np.tile(np.array([2.0, 0.5], dtype=np.float32), half // 2)
        X[:, half:] = X[:, :half] * ratio
    if shifted:
        X += np.float32(1000)
    weights = rng.uniform(0.25, 3.0, size=n).astype(np.float32) if weighted else None
    return X, y, weights, ratio


def score(model, X, y, weights, C, ratio):
    n, d = X.shape
    w = np.asarray(model.coef_[0], dtype=np.float64)
    center = np.asarray(model.center_, dtype=np.float64)
    b = float(model.centered_intercept_)
    sw_sum = float(n if weights is None else weights.astype(np.float64).sum())
    gradient = np.zeros(d, dtype=np.float64)
    bias = loss = 0.0
    for start in range(0, n, 256):
        stop = min(start + 256, n)
        block = X[start:stop].astype(np.float64)
        logits = (block - center) @ w + b
        weight = 1.0 if weights is None else weights[start:stop].astype(np.float64)
        residual = (expit(logits) - y[start:stop]) * weight
        gradient += block.T @ residual
        bias += residual.sum()
        loss += np.sum((np.logaddexp(0, logits) - y[start:stop] * logits) * weight)
    gradient = gradient / sw_sum + w / (C * sw_sum)
    objective = loss / sw_sum + 0.5 * float(w @ w) / (C * sw_sum)
    null = None
    if ratio is not None:
        half = d // 2
        null = float(np.linalg.norm(w[half:] - ratio * w[:half]) / max(np.linalg.norm(w), 1e-30))
    return {
        "objective": objective,
        "gradient_max_abs": max(float(np.max(np.abs(gradient))), abs(bias / sw_sum)),
        "nullspace": null,
    }


def hashes():
    paths = [Path(__file__), Path(__file__).with_name("coalesced.py")]
    paths += [
        p
        for d in (ROOT / "src/mlxlearn", ROOT / "src/mlxlearn_device")
        for p in d.rglob("*")
        if p.is_file()
        and "__pycache__" not in p.parts
        and (p.suffix in {".py", ".mm", ".so"} or p.name == "py.typed")
    ]
    return {str(p.resolve()): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


def fit(X, y, sw, C, variant):
    core._backward = ORIGINAL if variant == "old" else kernel_adapter
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        mx.synchronize()
        start = time.perf_counter()
        model = fit_logistic(X, y, sample_weight=sw, C=C, tol=1e-4, max_iter=200, sketch_size=4)
        mx.synchronize()
        elapsed = time.perf_counter() - start
    details = {
        "n_iter": model.n_iter,
        "converged": model.converged,
        "reason": model.stop_reason,
        "sketch_pairs": model.sketch_pairs_,
        "fallback": model.used_unsketched_fallback_,
        "warnings": [f"{w.category.__name__}: {w.message}" for w in caught],
    }
    return model, elapsed * 1000, details


ORIGINAL = core._backward


def main():
    cases = [
        ("normal", 20_000, 1_024, 41, {}),
        ("weighted_ill", 20_000, 1_024, 83, {"weighted": True, "ill": True}),
        ("shifted_weighted", 20_000, 1_024, 41, {"weighted": True, "shifted": True}),
        ("rank_deficient", 20_000, 1_024, 41, {"rank": True}),
        ("wide", 20_000, 4_096, 41, {}),
    ]
    result = {
        "method": "full device fit, balanced 12-pair samples after 3 warmups; X resident before timing; every fit independently float64 scored",
        "source_before": hashes(),
        "cases": [],
    }
    try:
        with threadpool_limits(limits=1), mx.stream(mx.gpu):
            for name, n, d, seed, kwargs in cases:
                X, y, sw, ratio = dataset(n, d, seed, **kwargs)
                C = 1e6 if kwargs.get("rank") else 1.0
                Xd, yd = mx.array(X), mx.array(y)
                wd = None if sw is None else mx.array(sw)
                mx.eval(*(x for x in (Xd, yd, wd) if x is not None))
                models = {"old": [], "new": []}
                records = {"old": [], "new": []}
                for i in range(15):
                    order = ("old", "new") if i % 2 == 0 else ("new", "old")
                    for variant in order:
                        model, elapsed, details = fit(Xd, yd, wd, C, variant)
                        if i >= 3:
                            models[variant].append(model)
                            records[variant].append({"ms": elapsed, **details})
                for variant in records:
                    for model, record in zip(models[variant], records[variant], strict=True):
                        record["quality"] = score(model, X, y, sw, C, ratio)
                baseline_obj = min(r["quality"]["objective"] for r in records["old"])
                for variant in records:
                    for record in records[variant]:
                        record["quality"]["objective_delta_vs_old"] = (
                            record["quality"]["objective"] - baseline_obj
                        ) / abs(baseline_obj)
                med = {k: statistics.median(r["ms"] for r in v) for k, v in records.items()}
                entry = {
                    "case": name,
                    "shape": [n, d],
                    "C": C,
                    "median_ms": med,
                    "samples": records,
                }
                result["cases"].append(entry)
                print(
                    name,
                    med,
                    "converged",
                    {k: sum(r["converged"] for r in v) for k, v in records.items()},
                    flush=True,
                )
                Path("bench/device_score_opt/full_fit_results.json").write_text(
                    json.dumps(result, indent=2) + "\n"
                )
                del X, y, sw, ratio, Xd, yd, wd, models, records
                mx.clear_cache()
    finally:
        core._backward = ORIGINAL
    result["source_after"] = hashes()
    result["source_integrity_pass"] = result["source_before"] == result["source_after"]
    Path("bench/device_score_opt/full_fit_results.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
