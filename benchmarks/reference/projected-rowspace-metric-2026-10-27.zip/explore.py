"""Scratch low-rank row-space projected metric for native GPU L-BFGS.

A positive rank-one correction along each accepted step lets the diagonal
curvature estimate inform the initial metric while keeping all directions in
the data row space in exact arithmetic. This monkeypatches only in-process,
never on disk. Quality is independently evaluated after every timed fit.
"""
import gc
import hashlib
import json
import statistics
import time
import warnings
from pathlib import Path

import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits

from benchmarks.hessian_logistic import Case, dataset, independent_score
from benchmarks.logistic_wide import package_source_paths
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command, native_logistic
from mlxlearn.linear_model import LogisticRegression

orig_initial = native_logistic.initial_from_parts
orig_source = native_command._source
orig_run = native_command.run_native_loop
SCALE_LIMIT = float(__import__('os').environ.get('PROJECTED_SCALE','8'))


def new_initial(parts, reg, denom):
    # Keep production gradient and scalar metric bit-for-bit unchanged.
    gradient, scalar_vector = orig_initial(parts, reg, denom)
    scalar = scalar_vector[-1]
    diagonal = mx.sum(parts[1], axis=0) / denom + reg
    average = 1.0 / scalar
    diag = mx.where(mx.isfinite(diagonal) & (diagonal > 1e-12), diagonal, average)
    precond = 1.0 / mx.clip(diag, average / SCALE_LIMIT, average * SCALE_LIMIT)
    # Last column is the unpenalized intercept; it stores the scalar metric.
    precond = mx.concatenate([precond[:-1], scalar.reshape((1,))])
    return gradient, precond


def new_source(*args):
    s = orig_source(*args)
    replacements = {
      'gg+=j<P?v*v*h0inv[j]:0.0f;':'gg+=j<P?v*v*h0inv[P-1]:0.0f;',
      'sy+=s*y;yy+=y*y*h0inv[j];':'sy+=s*y;yy+=y*y*h0inv[P-1];',
      'float d=active?(reset?-g[j]*h0inv[j]:-q[k]):0.0f;':'float d=active?(reset?-g[j]*h0inv[P-1]:-q[k]):0.0f;',
      '''float gamma=count?newhc[2*((head+M-1)%M)+1]:1.0f;
    for(uint k=0;k<(P+31)/32;++k){uint j=t+32*k;if(j<P)q[k]*=gamma*h0inv[j];}''':'''float gamma=count?newhc[2*((head+M-1)%M)+1]:1.0f;
    float corrections[M];
    for(uint a=0;a<count;++a){
      uint h=(head+M-count+a)%M;float norm=0,scaled=0,dot=0;
      for(uint k=0;k<(P+31)/32;++k){uint j=t+32*k;if(j<P){float s=newhs[h*P+j]; norm+=s*s;scaled+=s*s*h0inv[j];dot+=s*q[k];}}
      norm=simd_sum(norm);scaled=simd_sum(scaled);dot=simd_sum(dot);
      float gain=norm>1e-30f?max(0.0f,scaled/norm-h0inv[P-1]):0.0f;
      corrections[a]=norm>1e-30f?gain*dot/(norm*float(count)):0.0f;
    }
    for(uint k=0;k<(P+31)/32;++k){uint j=t+32*k;if(j<P){
      float value=h0inv[P-1]*q[k];
      for(uint a=0;a<count;++a){uint h=(head+M-count+a)%M;value+=corrections[a]*newhs[h*P+j];}
      q[k]=gamma*value;
    }}'''
    }
    for old,new in replacements.items():
        count=s.count(old)
        if count!=1:raise RuntimeError(f'expected one source match, found {count}: {old[:50]}')
        s=s.replace(old,new)
    return s


def native_run(*args,**kwargs):
    if CURRENT=='projected':
        native_command._source = new_source
        native_logistic.initial_from_parts = new_initial
    else:
        native_command._source = orig_source
        native_logistic.initial_from_parts = orig_initial
    result=orig_run(*args,**kwargs)
    EVENTS.append(('completed' if result.state.converged else 'failed:'+result.state.stop_reason) if isinstance(result,native_command.NativeAttempt) else ('completed' if result is not None else 'fallback'))
    return result


CURRENT='scalar'
EVENTS=[]
CASES=[Case('weighted_ill_1024',20000,1024,seed=83,weighted=True,ill_conditioned=True),
       Case('weighted_ill_1024_41',20000,1024,seed=41,weighted=True,ill_conditioned=True),
       Case('ill_1024',20000,1024,seed=41,ill_conditioned=True),
       Case('rank_1024',20000,1024,seed=41,rank_deficient=True,C=1e6),
       Case('rank_1024_83',20000,1024,seed=83,rank_deficient=True,C=1e6),
       Case('normal_1024',20000,1024,seed=41),
       Case('weighted_shifted_1024',20000,1024,seed=41,weighted=True,shifted=True),
       Case('unbalanced_weighted_ill',20000,1024,seed=2027,weighted=True,ill_conditioned=True),
       Case('wide_4096',20000,4096,seed=41)]


def fit(X,y,weights,case,variant):
    global CURRENT
    CURRENT=variant;EVENTS.clear()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always');mx.synchronize();enabled=gc.isenabled();gc.disable()
        try:
            t=time.perf_counter()
            if variant=='sklearn':
                model=SK(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weights)
            else:
                with tuning_context(force_backend='mlx'):
                    model=LogisticRegression(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weights)
            mx.synchronize();dt=time.perf_counter()-t
        finally:
            if enabled:gc.enable()
    return model,dt,{'n_iter':model.n_iter_.tolist(),'native_calls':EVENTS.copy(),'warnings':[str(w.message) for w in caught]}


def main():
    native_command.run_native_loop=native_run
    variants=('scalar','projected','sklearn')
    output={'method':'scratch; rotated full fits, 2 warmup + 4 repeat, 1 CPU thread; every model independently scored against final sklearn fit; initial source and extension hashes', 'scale_limit':SCALE_LIMIT, 'source_hashes':{},'cases':[]}
    paths=package_source_paths()+[Path(native_command._metal_loop.__file__).resolve(),Path(__file__).resolve()]
    output['source_hashes']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    try:
      with threadpool_limits(limits=1):
       for case in CASES:
        X,y,weights,ratio=dataset(case)
        if case.name=="unbalanced_weighted_ill":y=(X[:,0] > 0.12).astype(np.int32)
        samples={v:[] for v in variants};details={v:[] for v in variants};models={v:[] for v in variants}
        for rep in range(6):
         order=variants[rep%3:]+variants[:rep%3]
         if rep%2:order=order[::-1]
         for v in order:
          m,t,metadata=fit(X,y,weights,case,v)
          if rep>=2:samples[v].append(t*1000);details[v].append(metadata);models[v].append(m)
        ref,ref_pred=independent_score(models['sklearn'][-1],X,y,weights,case.C,ratio)
        scores={v:[independent_score(m,X,y,weights,case.C,ratio,(ref['objective_float64'],ref_pred))[0] for m in vals] for v,vals in models.items()}
        row={'case':case.name,'seed':case.seed,'C':case.C,'medians_ms':{v:statistics.median(a) for v,a in samples.items()},'samples_ms':samples,'metadata':details,'quality':scores}
        output['cases'].append(row)
        print(case.name,{v:round(x,3) for v,x in row['medians_ms'].items()},'niter',{v:details[v][-1]['n_iter'] for v in variants},'grad',{v:round(scores[v][-1]['gradient_max_abs_float64'],8) for v in variants},'gap',{v:round(scores[v][-1]['objective_relative_gap_to_sklearn'],8) for v in variants}, 'null',scores['projected'][-1]['nullspace_coefficient_relative'],flush=True)
        Path(f'bench/projected_metric/results-{int(SCALE_LIMIT)}.json').write_text(json.dumps(output,indent=2)+'\n')
    finally:
      native_command.run_native_loop=orig_run;native_command._source=orig_source;native_logistic.initial_from_parts=orig_initial
    output['source_integrity_passed']=output['source_hashes']=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    Path(f'bench/projected_metric/results-{int(SCALE_LIMIT)}.json').write_text(json.dumps(output,indent=2)+'\n')

if __name__=='__main__':main()
