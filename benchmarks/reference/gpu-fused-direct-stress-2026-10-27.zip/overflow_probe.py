"""Check partial-loss overflow with finite per-row logistic loss."""
import json
import math
import mlx.core as mx
import numpy as np
from fused import direct_fused
from mlxlearn._solvers.logistic import _blocked_sum, _total
from mlxlearn._solvers.native_logistic import direct_arrays

n,d=20000,4096
X=mx.zeros((n,d),dtype=mx.float32)
y=mx.zeros((n,),dtype=mx.float32)
sw=mx.ones((n,),dtype=mx.float32)
theta=mx.concatenate([mx.zeros((1,d),dtype=mx.float32),mx.array([[1e37]],dtype=mx.float32)],axis=1)
denom=mx.array(n,dtype=mx.float32)
mx.eval(X,y,sw,theta,denom)
old_loss,old_penalty,old_grad=direct_arrays(theta,X,y,sw,denom,1/n,True)
old_loss=_blocked_sum(mx,old_loss)
new_loss,new_penalty,new_grad=direct_fused(theta,X,y,sw,denom,1/n,True)
mx.eval(old_loss,old_penalty,old_grad,new_loss,new_penalty,new_grad)
a=_total(old_loss,old_penalty,n);b=_total(new_loss,new_penalty,n)
result={'shape':[n,d],'theta_intercept_float32':float(theta[0,d]),'baseline_objective':a,
        'baseline_finite':math.isfinite(a),'fused_finite':math.isfinite(b),
        'fused_objective': str(b) if not math.isfinite(b) else b,
        'baseline_grad_finite':bool(np.all(np.isfinite(np.asarray(old_grad)))),
        'fused_grad_finite':bool(np.all(np.isfinite(np.asarray(new_grad)))),
        'baseline_grad_bias':float(old_grad[0,d]),'fused_grad_bias':float(new_grad[0,d]),
        'baseline_parts_max':float(mx.max(old_loss)),
        'fused_part_infinite_count':int(mx.sum(mx.logical_not(mx.isfinite(new_loss))))}
print(json.dumps(result,indent=2))
open('bench/fused_direct/overflow_probe_results.json','w').write(json.dumps(result,indent=2)+'\n')
