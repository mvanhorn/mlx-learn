"""Stress paired full fits for the scratch fused direct scorer."""
import hashlib
import json
from pathlib import Path

import mlx.core as mx
import numpy as np
from threadpoolctl import threadpool_limits

import full_fit
from benchmarks.logistic_gpu import Case, make_data
from mlxlearn._solvers import logistic


def run(spec, pairs=2):
    name, tol, weighted, shift, ill, scaled, zeros = spec
    X, y, weights = make_data(Case(name, 20000, 4096, weighted=weighted,
                                   ill_conditioned=ill), 41, dtype='float32')
    if scaled:
        X *= np.logspace(-2, 2, X.shape[1], dtype=np.float32)
    if shift:
        X += np.float32(shift)
    if zeros:
        weights = np.ones(len(X), dtype=np.float64) if weights is None else weights
        weights[::2] = 0.0
    logistic._native_binary_objective = full_fit.ORIGINAL
    _, reference, rd = full_fit.fit_once('sklearn', X, y, weights, reference=None, max_iter=200, tol=tol)
    rq, reference_predictions = full_fit.independent(reference, X, y, weights)
    funcs = {'baseline': full_fit.ORIGINAL, 'fused': full_fit.candidate_objective}
    samples = {'baseline': [], 'fused': []}
    for j in range(pairs):
        for name_ in (('baseline', 'fused') if j % 2 == 0 else ('fused', 'baseline')):
            logistic._native_binary_objective = funcs[name_]
            duration, model, details = full_fit.fit_once('optimized_gpu', X, y, weights, reference=None, max_iter=200, tol=tol)
            quality, _ = full_fit.independent(model, X, y, weights, reference_predictions)
            quality['relative_gap_to_sklearn'] = (quality['objective'] - rq['objective'])/abs(rq['objective'])
            samples[name_].append({'seconds': duration, 'details': details, 'quality': quality})
    out={'name':name, 'tol':tol, 'weighted':weighted, 'shift':shift, 'ill_conditioned':ill,
         'scaled':scaled, 'zeros':zeros, 'sklearn_details':rd, 'sklearn_quality':rq, 'samples':samples}
    print(name, {k:[(round(s['seconds']*1000,2),s['details']['implementation'],s['details']['n_iter'],
                    [w['category'] for w in s['details']['warnings']],s['quality']['gradient_max'],
                    s['quality']['relative_gap_to_sklearn']) for s in v] for k,v in samples.items()},flush=True)
    del X, y, weights, reference, reference_predictions
    mx.clear_cache()
    return out


def main():
    cases=[('strict1e-6',1e-6,False,0.,False,False,False),
           ('strict1e-7',1e-7,False,0.,False,False,False),
           ('weighted',1e-4,True,0.,False,False,False),
           ('shifted',1e-4,False,1000.,False,False,False),
           ('ill_conditioned',1e-4,False,0.,True,False,False),
           ('scaled_zero_weights',1e-4,True,0.,False,True,True)]
    hashes=full_fit.hashes()
    hashes[str(Path(__file__).resolve())]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    results=[]
    try:
        with threadpool_limits(limits=1):
            for case in cases:
                results.append(run(case))
                Path('bench/fused_direct/wide_stress_partial.json').write_text(json.dumps(results,indent=2,default=str)+'\n')
    finally:
        logistic._native_binary_objective=full_fit.ORIGINAL
    after=full_fit.hashes()
    after[str(Path(__file__).resolve())]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    payload={'source_hashes':hashes, 'source_integrity_passed':hashes==after,
             'native_extension':full_fit.loaded_native_extension(), 'cases':results}
    Path('bench/fused_direct/wide_stress_results.json').write_text(json.dumps(payload,indent=2,default=str)+'\n')

if __name__=='__main__':main()
