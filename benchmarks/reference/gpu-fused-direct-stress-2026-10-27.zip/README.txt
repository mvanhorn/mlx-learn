Fused direct-score stress and overflow experiment

`wide_stress.py` runs two alternating paired full fits for each 20k x 4096 case: tolerances 1e-6 and 1e-7, weighted, shifted by 1,000, correlated ill-conditioned, and scaled with half the sample weights zero. It preserves warnings, native route/fallback, sklearn score, and independent float64 objective/gradient/prediction accuracy for every fit. This is a numerical stress sample, not a timing panel. On the ill-conditioned case both production and scratch report convergence but have relative objective 1.9808e-5 above independently converged sklearn, which exceeds the benchmark's one-sided 1e-5 gate. Scaled/zero-weight case reports nonconvergence in both variants and sklearn.

`overflow_probe.py` directly scores zero X, y=0, intercept 1e37: existing scorer stays finite but scratch fused scorer overflows unnormalized float32 loss partials. The scratch candidate is unsafe to integrate unchanged. It is a float32 centered-data evaluator, not an original-input float64 certificate.

The wide stress run recorded package and scratch source hashes and the active native binary hash. Benchmark helper files and overflow-probe source were captured after execution, not included in an in-run hash check. These are source-only artifacts; no native binary is shipped.
