import pathlib,subprocess,sysconfig
base=pathlib.Path(__file__).resolve().parent
args=['clang++','-O3','-shared','-fobjc-arc','-std=c++17','-undefined','dynamic_lookup','-framework','Foundation','-framework','Metal','-framework','MetalPerformanceShaders',f'-I{sysconfig.get_path("include")}',str(base/'mps_chol.mm'),'-o',str(base/'_mps_chol.so')]
subprocess.run(args,check=True)
