import json,time
import numpy as np
import mlx.core as mx
from threadpoolctl import threadpool_limits
n,d=20000,1024
rng=np.random.default_rng(83);x=rng.standard_normal((n,d),dtype=np.float32)
x[:,512:]=x[:,:512]+0.01*x[:,512:];x*=np.logspace(-1,1,d,dtype=np.float32)
sw=rng.uniform(.25,3.,n).astype(np.float32)
with mx.stream(mx.gpu),threadpool_limits(limits=1):
 X=mx.array(x);w=mx.array(sw);mx.eval(X,w);mx.synchronize()
 samples=[]
 for i in range(5):
  t=time.perf_counter(); xc=X-mx.mean(X,axis=0); wx=xc*mx.sqrt(w[:,None]/float(sw.sum())*.25); gram=wx.T@wx;mx.eval(gram);mx.synchronize();dt=time.perf_counter()-t
  samples.append(dt*1000); print('Gram ms',round(dt*1000,3),flush=True)
  if i==4:
   g=np.asarray(gram); print('Gram asymmetry',float(np.max(np.abs(g-g.T))),'diag min/max',float(g.diagonal().min()),float(g.diagonal().max()),flush=True)
 result={'n':n,'d':d,'gram_ms_samples':samples,'weights':'positive uniform .25..3','includes':'centering, weighting, matrix construction and evaluation','limitation':'GPU gram only; factorization and application omitted'}
 open('bench/weighted_hessian_probe/setup.json','w').write(json.dumps(result,indent=2))
