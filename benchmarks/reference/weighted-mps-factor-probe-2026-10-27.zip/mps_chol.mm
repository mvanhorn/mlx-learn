#define PY_SSIZE_T_CLEAN
#include <Python.h>
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>
#import <MetalPerformanceShaders/MetalPerformanceShaders.h>
#include <cstdint>
#include <algorithm>

struct DLDevice { int device_type, device_id; };
struct DLDataType { uint8_t code,bits; uint16_t lanes; };
struct DLTensor { void* data;DLDevice device;int ndim;DLDataType dtype;int64_t* shape;int64_t* strides;uint64_t byte_offset;};
struct DLManagedTensor { DLTensor dl_tensor;void* manager_ctx;void (*deleter)(DLManagedTensor*);};
struct Buf {id<MTLBuffer> data;NSUInteger offset;};
static Buf tensor(PyObject* tuple,int i,int d) {
    PyObject* p=PyTuple_GetItem(tuple,i);
    auto *t=static_cast<DLManagedTensor*>(PyCapsule_GetPointer(p,"dltensor"));
    if(!t) return {nil,0};
    const auto& a=t->dl_tensor;
    if(a.device.device_type!=8 || a.dtype.code!=2 || a.dtype.bits!=32 || a.ndim!=2 || a.shape[0]!=d || a.shape[1]!=d || !a.data || (a.strides && (a.strides[1]!=1 || a.strides[0]!=d)) ) {
        PyErr_SetString(PyExc_ValueError,"expected contiguous 2D float32 Metal buffers"); return {nil,0};
    }
    id<MTLBuffer> b=(__bridge id<MTLBuffer>)a.data;
    if(![b conformsToProtocol:@protocol(MTLBuffer)] || a.byte_offset> b.length || uint64_t(d)*d*4 > b.length-a.byte_offset){
        PyErr_SetString(PyExc_ValueError,"invalid Metal buffer");return {nil,0};
    }
    return {b,NSUInteger(a.byte_offset)};
}
static PyObject* run(PyObject*,PyObject* args){
    PyObject* tensors;int d, rhs_count=-1;
    if(!PyArg_ParseTuple(args,"Oi|i",&tensors,&d,&rhs_count))return nullptr;
    if(rhs_count<0)rhs_count=d;
    if(rhs_count>d){PyErr_SetString(PyExc_ValueError,"too many RHS");return nullptr;}
    if(!PyTuple_Check(tensors) || PyTuple_Size(tensors)!=4 || d<=0){PyErr_SetString(PyExc_ValueError,"expected gram/factor/identity/output capsules");return nullptr;}
    @autoreleasepool { @try {
       auto a=tensor(tensors,0,d),L=tensor(tensors,1,d),I=tensor(tensors,2,d),P=tensor(tensors,3,d);
       if(!a.data || !L.data || !I.data || !P.data)return nullptr;
       auto device=MTLCreateSystemDefaultDevice();
       if(a.data.device!=device || L.data.device!=device || I.data.device!=device || P.data.device!=device){PyErr_SetString(PyExc_ValueError,"wrong device");return nullptr;}
       auto descriptor=[MPSMatrixDescriptor matrixDescriptorWithRows:d columns:d rowBytes:d*4 dataType:MPSDataTypeFloat32];
       MPSMatrix* A=[[MPSMatrix alloc] initWithBuffer:a.data offset:a.offset descriptor:descriptor];
       MPSMatrix* factor=[[MPSMatrix alloc] initWithBuffer:L.data offset:L.offset descriptor:descriptor];
       auto rhsdesc=[MPSMatrixDescriptor matrixDescriptorWithRows:d columns:NSUInteger(std::max(rhs_count,1)) rowBytes:std::max(rhs_count,1)*4 dataType:MPSDataTypeFloat32];
       MPSMatrix* rhs=[[MPSMatrix alloc] initWithBuffer:I.data offset:I.offset descriptor:rhsdesc];
       MPSMatrix* result=[[MPSMatrix alloc] initWithBuffer:P.data offset:P.offset descriptor:rhsdesc];
       auto queue=[device newCommandQueue]; auto status=[device newBufferWithLength:4 options:MTLResourceStorageModeShared];
       auto chol=[[MPSMatrixDecompositionCholesky alloc] initWithDevice:device lower:YES order:d];
       auto solve=[[MPSMatrixSolveCholesky alloc] initWithDevice:device upper:NO order:d numberOfRightHandSides:std::max(rhs_count,1)];
       auto cb=[queue commandBuffer]; [chol encodeToCommandBuffer:cb sourceMatrix:A resultMatrix:factor status:status]; [cb commit];[cb waitUntilCompleted];
       if(cb.status!=MTLCommandBufferStatusCompleted){PyErr_SetString(PyExc_RuntimeError,"Cholesky command failed");return nullptr;}
       int s=*static_cast<int*>(status.contents);if(s!=0 || rhs_count==0)return PyLong_FromLong(s);
       cb=[queue commandBuffer]; [solve encodeToCommandBuffer:cb sourceMatrix:factor rightHandSideMatrix:rhs solutionMatrix:result]; [cb commit];[cb waitUntilCompleted];
       if(cb.status!=MTLCommandBufferStatusCompleted){PyErr_SetString(PyExc_RuntimeError,"MPS solve command failed");return nullptr;}
       return PyLong_FromLong(0);
    } @catch(NSException* e){PyErr_SetString(PyExc_RuntimeError,e.reason.UTF8String);return nullptr;} }
}
static PyMethodDef methods[]={{"factor_inverse",run,METH_VARARGS,"GPU factor and inverse"},{nullptr,nullptr,0,nullptr}};
static PyModuleDef module={PyModuleDef_HEAD_INIT,"_mps_chol",nullptr,-1,methods};
PyMODINIT_FUNC PyInit__mps_chol(void){return PyModule_Create(&module);}
