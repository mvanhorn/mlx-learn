"""Scratch MPS weighted Gauss-Newton preconditioner setup timing."""
import importlib.util,json,statistics,time
from pathlib import Path
import mlx.core as mx
import numpy as np
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import CASES,dataset

base=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('_mps_chol',base/'_mps_chol.so')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
case=next(c for c in CASES if c.name=='weighted_ill_1024')
X,y,weights,ratio=dataset(case)
with mx.stream(mx.gpu),threadpool_limits(limits=1):
 x=mx.array(X);w=mx.array(weights,dtype=mx.float32);sw=float(weights.sum());mx.eval(x,w)
 results=[]
 for fraction in [0.001,0.01]:
  times=[]; validation={}
  for i in range(6):
   mx.synchronize();t=time.perf_counter();center=mx.mean(x,axis=0);xc=x-center;z=mx.concatenate([xc,mx.ones((case.rows,1),mx.float32)],axis=1);zw=z*mx.sqrt(w[:,None]*(0.25/sw));gram=zw.T@zw;diag=mx.mean(mx.diag(gram));H=mx.contiguous(gram+diag*fraction*mx.eye(case.features+1));mx.eval(H);mx.synchronize();t_gram=time.perf_counter()
   d=case.features+1;factor=mx.zeros((d,d),mx.float32);I=mx.eye(d);P=mx.zeros((d,d),mx.float32);mx.eval(factor,I,P);mx.synchronize();capsules=tuple(a.__dlpack__() for a in (H,factor,I,P));status=m.factor_inverse(capsules,d,0 if i < 3 else 1);mx.synchronize();t_end=time.perf_counter()
   times.append({'rhs':0 if i < 3 else 1,'gram_ms':(t_gram-t)*1000,'factor_inverse_ms':(t_end-t_gram)*1000,'total_ms':(t_end-t)*1000,'status':status})
   if i==4 and status==0 and False:
    h=np.asarray(H,dtype=np.float64);p=np.asarray(P,dtype=np.float64); residual=h@p-np.eye(d); validation={'max_inverse_residual':float(np.max(np.abs(residual))),'frobenius_relative':float(np.linalg.norm(residual)/np.sqrt(d)),'symmetry':float(np.max(np.abs(p-p.T))),'jitter':float(diag)*fraction}
  row={'jitter_fraction':fraction,'samples':times,'validation':validation};results.append(row)
  print(fraction,'median setup',round(statistics.median(z['total_ms'] for z in times[2:]),2),'valid',validation,flush=True)
  (base/'factor_single_results.json').write_text(json.dumps({'method':'Gram+GPU MPS Cholesky+GPU inverse, no solver or quality included','results':results},indent=2)+'\n')
