# Half-precision shadow experiment, 2026-10-27

This is an exploratory scratch prototype, not the shipped library. It casts the
centered design to FP16 on the GPU, iterates against that copy, directly
checks the candidate gradient and objective on the original centered FP32
matrix, and reruns the production native solver when certification fails.
The wide variant records the previous two accepted parameter vectors and
checks two successive FP32 objective differences. The fused version obtains
both differences in one matrix pass, using stable log1p/expm1 expressions.
There is no warm-start correction; retries start the existing solver again.
CPU NumPy handles small checkpoint vectors and reference checks. The initial
FP16 finiteness test costs a synchronization and the whole array conversion
and any fallback are included in timed fits.

Build on Apple Silicon with `cd bench/fp16_shadow && python3 setup.py build_ext --inplace --force`.
Run each script from the repository root with `PYTHONPATH=. python3
bench/fp16_shadow/experiment.py` and `PYTHONPATH=. python3
bench/fp16_shadow/fused_experiment.py`. The two extensions define private
Objective-C class names to avoid collision with the production extension.

Each of four seed-41 float32 cases uses eight interleaved fresh fits per
variant; first fits include kernel compilation, so this is exploratory, not a
publishable performance comparison. Timings, warnings, iteration counts,
shadow fallback counts and independent float64 sklearn quality checks are
recorded for every fit. The fused script cross-checks its wide checkpoint
differences against the existing direct evaluator outside timed sections. The
small panel does not establish safety for arbitrary values, class counts,
regularization or distribution shifts. The checkpoint/difference test is a
heuristic and does not prove global objective parity.
