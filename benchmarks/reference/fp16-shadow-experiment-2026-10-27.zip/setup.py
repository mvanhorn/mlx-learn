from setuptools import Extension, setup
from setuptools.command.build_ext import build_ext
class MetalBuildExt(build_ext):
    def build_extensions(self):
        self.compiler.src_extensions.append('.mm')
        super().build_extensions()
setup(name='fp16_shadow_experiment', ext_modules=[Extension('_metal_loop', ['_metal_loop.mm'], language='c++', define_macros=[('Py_LIMITED_API', '0x030A0000')], py_limited_api=True, extra_compile_args=['-std=c++17', '-fobjc-arc'], extra_link_args=['-framework', 'Foundation', '-framework', 'Metal'])], cmdclass={'build_ext': MetalBuildExt})
