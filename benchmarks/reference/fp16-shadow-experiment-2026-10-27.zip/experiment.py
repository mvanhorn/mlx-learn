"""Experimental float16 design read with float32 final check. Not production code.

The shadow pass is followed by direct full-float32 objective/gradient checking;
when that fails the complete existing float32 native/fused solver is rerun.
The latter is a conservative fallback, not yet a warm correction. The complete
fit timings include conversion and the fallback. Results are independently
scored against sklearn and the current solver on the original float64 input.
"""
import gc
import importlib.util
import inspect
import json
from pathlib import Path
import sys
import time
import warnings

import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits

from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression
from benchmarks.logistic_gpu import Case, make_data, quality

path = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('fp16_shadow._metal_loop',path/'_metal_loop.abi3.so')
ext = importlib.util.module_from_spec(spec);spec.loader.exec_module(ext)

orig = native_command.run_native_loop
orig_source = native_command._source
stats = {'attempt': 0, 'returned': 0, 'fallback': 0}

def source(*args):
    s=orig_source(*args)
    old='device const float* X [[buffer(0)]]'
    assert s.count(old)==2, s.count(old)
    s = s.replace(old,'device const half* X [[buffer(0)]]')
    return s + r"""
kernel void save_checkpoint(device const float* w [[buffer(0)]],
                            device const float* oldmeta [[buffer(1)]],
                            device const float* newmeta [[buffer(2)]],
                            device float* snapshots [[buffer(3)]],
                            uint t [[thread_position_in_grid]]) {
 if(t<P && newmeta[0]>oldmeta[0])snapshots[(uint(newmeta[0])%3)*P+t]=w[t];
}
"""

source_text=inspect.getsource(orig)
old='    arrays = (X, y, sw, g, h0, reg)'
assert source_text.count(old)==1
source_text=source_text.replace('raw, n_iter, status, n_fev, last_difference, previous_difference = result', 'raw, n_iter, status, n_fev, last_difference, previous_difference, snapshots = result')
source_text=source_text.replace(old,'''    half = X.astype(mx.float16)
    mx.eval(half)
    if not bool(mx.all(mx.isfinite(half))):
        return None
    arrays = (half, y, sw, g, h0, reg)''')
source_text=source_text.replace(
    '    recent = abs(last_difference)\n',
    """    recent = abs(last_difference)
    if d >= 2048 and n_iter >= 2:
        saved = np.frombuffer(snapshots, dtype=np.float32).reshape(3, p)
        prev = mx.array(saved[(n_iter - 1) % 3].copy()).reshape(1, p)
        older = mx.array(saved[(n_iter - 2) % 3].copy()).reshape(1, p)
        prev_objective, _ = fun(prev)
        older_objective, _ = fun(older)
        if not math.isfinite(prev_objective) or not math.isfinite(older_objective):
            return None
        last_difference = objective - prev_objective
        previous_difference = prev_objective - older_objective
        recent = abs(last_difference)
""",
)
ns=dict(native_command.__dict__)
ns['_metal_loop']=ext
ns['_source']=source
exec(compile(source_text,'<fp16-shadow-adapter>','exec'),ns)
shadow=ns['run_native_loop']

def shadow_run(*args, **kwargs):
    stats['attempt']+=1
    state=shadow(*args,**kwargs)
    stats['returned' if state is not None else 'fallback']+=1
    return state if state is not None else orig(*args, **kwargs)

# Tiny timing panel and dedicated shape/quality diagnostics. Each pair is
# interleaved and scoring happens after timing. Honest fallback counts included.
def main():
    cases=[Case('wide_20k_1024',20000,1024),Case('wide_20k_4096',20000,4096),Case('wide_weighted',20000,1024,weighted=True),Case('ill_conditioned',20000,1024,ill_conditioned=True)]
    output={'method':'paired warm fresh public fits, float16 shadow, full float32 direct check, full float32 fallback; independent float64 quality','cases':[]}
    with threadpool_limits(limits=1),tuning_context(force_backend='mlx'):
        for case in cases:
            X,y,sw=make_data(case,41,dtype='float32')
            ref=SkLogisticRegression(max_iter=200,tol=1e-4).fit(X,y,sample_weight=sw)
            row={'case':case.name,'records':[]}
            for i in range(8):
                for variant in (('baseline','shadow') if i%2==0 else ('shadow','baseline')):
                    native_command.run_native_loop=orig if variant=='baseline' else shadow_run
                    before=dict(stats)
                    with warnings.catch_warnings(record=True) as caught:
                        warnings.simplefilter('always')
                        mx.synchronize();gc.disable();start=time.perf_counter()
                        try:
                            model=LogisticRegression(max_iter=200,tol=1e-4).fit(X,y,sample_weight=sw)
                            mx.synchronize();dt=time.perf_counter()-start
                        finally: gc.enable()
                    q=quality(model,ref,X,y,sw)
                    row['records'].append({'i':i,'variant':variant,'ms':dt*1000,'n_iter':model.n_iter_.tolist(),'warnings':[str(w.message) for w in caught], 'quality':q,'shadow_attempt':stats['attempt']-before['attempt'],'shadow_returned':stats['returned']-before['returned'],'shadow_fallback':stats['fallback']-before['fallback']})
            print(case.name, {v:round(np.median([r['ms'] for r in row['records'] if r['variant']==v]),3) for v in ['baseline','shadow']},flush=True)
            output['cases'].append(row)
            (path/'results.json').write_text(json.dumps(output,indent=2,default=str)+'\n')
    native_command.run_native_loop=orig

if __name__=='__main__': main()
