"""Mixed-storage HVP/iterative refinement pilot; not for production."""
from __future__ import annotations
import math
import mlx.core as mx
from fused_hvp import fused_hvp as full_hvp
from fused_hvp_mixed import fused_hvp as half_hvp

_half = mx.compile(half_hvp)
_full = mx.compile(full_hvp)


def _cg(Xhalf, diagonal, reg, rhs, steps, trace, phase):
    x = mx.zeros_like(rhs)
    r = rhs
    direction = r
    rr = mx.sum(r * r)
    mx.eval(rr)
    for i in range(steps):
        hd = _half(Xhalf, diagonal, direction, reg)
        denom = mx.sum(direction * hd)
        mx.eval(denom, rr)
        dd, old = float(denom), float(rr)
        if not (math.isfinite(dd) and dd > 0 and math.isfinite(old) and old >= 0):
            trace.append({'phase': phase, 'iteration': i, 'error': 'nonpositive or nonfinite curvature'})
            break
        alpha = rr / denom
        next_x = x + alpha * direction
        next_r = r - alpha * hd
        next_rr = mx.sum(next_r * next_r)
        mx.eval(next_x, next_r, next_rr)
        rr_value = float(next_rr)
        if not math.isfinite(rr_value):
            trace.append({'phase': phase, 'iteration': i, 'error': 'nonfinite residual'})
            break
        trace.append({'phase': phase, 'iteration': i + 1, 'residual_norm': math.sqrt(rr_value)})
        x, r = next_x, next_r
        if rr_value <= 1e-20:
            break
        direction = r + (next_rr / rr) * direction
        rr = next_rr
    return x


def cg_step(X, y, sw, wsum, coef, bias, C, steps, history=None):
    """First solve using fp16 X, then refine once against exact-fp32 HVP.

    Each phase uses at most ``steps`` half-storage HVPs; trace includes the
    full-storage residual check explicitly. No row-space guarantee is assumed.
    """
    if history is not None:
        raise ValueError('mixed scratch does not implement history preconditioning')
    d = X.shape[1]
    theta = mx.concatenate([coef.reshape(-1), mx.array([bias], mx.float32)])
    z = X @ theta[:d] + theta[d]
    probability = mx.sigmoid(z)
    sign = 1.0 - 2.0 * y
    residual = sign * mx.sigmoid(sign * z) * sw
    gradient = mx.concatenate([X.T @ residual / wsum + theta[:d] / (C * wsum),
                               mx.sum(residual, keepdims=True) / wsum])
    diagonal = probability * mx.sigmoid(-z) * sw / wsum
    reg = mx.concatenate([mx.full((d,), 1.0 / (C * wsum)), mx.zeros((1,))])
    Xhalf = X.astype(mx.float16)
    mx.eval(theta, gradient, diagonal, Xhalf)
    mx.synchronize()
    if not bool(mx.all(mx.isfinite(Xhalf))) or not bool(mx.all(mx.isfinite(gradient))):
        raise RuntimeError('nonfinite mixed storage or gradient')
    trace = []
    first = _cg(Xhalf, diagonal, reg, -gradient, steps, trace, 'initial')
    exact_residual = -gradient - _full(X, diagonal, first, reg)
    mx.eval(exact_residual)
    trace.append({'phase': 'full_residual', 'residual_norm': float(mx.sqrt(mx.sum(exact_residual * exact_residual)))})
    second = _cg(Xhalf, diagonal, reg, exact_residual, steps, trace, 'refinement')
    result = first + second
    mx.eval(theta, result, gradient)
    return theta, result, gradient, trace
