"""Probe a budgeted CG correction followed by native managed convergence.

This scratch is intentionally not a library solver. It counts every accepted
outer step, records the extra Hessian-vector products, and checks the usual
original-gradient and two-step loss-progress conditions after reanchoring.
"""
from __future__ import annotations

import argparse
import json
import math
import time
import warnings
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

import mlx.core as mx
import numpy as np
from threadpoolctl import threadpool_limits

from benchmarks.hessian_logistic import Case, dataset, independent_score, sources
from fused_experiment_stable import cg_step
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import logistic, native_logistic
from mlxlearn.linear_model import LogisticRegression


def original_max(gradient, center):
    g = gradient.reshape(-1)
    return mx.maximum(mx.max(mx.abs(g[:-1] + center * g[-1])), mx.abs(g[-1]))


def run():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=41)
    parser.add_argument('--initial-budget', type=int, default=200)
    parser.add_argument('--steps', type=int, default=64)
    parser.add_argument('--case', choices=('ill4096', 'rank1024', 'weightedill1024', 'shifted1024',
                                            'weightedill4096', 'shifted4096', 'rank4096', 'rankgeneral4096'), default='ill4096')
    parser.add_argument('--force-managed', action='store_true')
    parser.add_argument('--C', type=float, default=None)
    parser.add_argument('--max-iter', type=int, default=200)
    parser.add_argument('--output', type=Path, default=Path('bench/cg_polish/continuation.json'))
    args = parser.parse_args()
    cases = {
        'ill4096': Case('ill_conditioned_4096', 20_000, 4_096, seed=args.seed, ill_conditioned=True),
        'rank1024': Case('rank_deficient_1024', 20_000, 1_024, seed=args.seed, rank_deficient=True, C=1e6),
        'weightedill1024': Case('weighted_ill_1024', 20_000, 1_024, seed=args.seed, weighted=True, ill_conditioned=True),
        'shifted1024': Case('shifted_1024', 20_000, 1_024, seed=args.seed, shifted=True),
        'weightedill4096': Case('weighted_ill_4096', 20_000, 4_096, seed=args.seed, weighted=True, ill_conditioned=True),
        'shifted4096': Case('shifted_4096', 20_000, 4_096, seed=args.seed, shifted=True),
        'rank4096': Case('rank_4096', 20_000, 4_096, seed=args.seed, rank_deficient=True, C=1e6),
        'rankgeneral4096': Case('rank_general_4096', 20_000, 4_096, seed=args.seed, rank_deficient=False, C=1e6),
    }
    case = cases[args.case]
    if args.C is not None:
        case = replace(case, C=args.C)
    extra = [Path(__file__).resolve(), Path(__file__).with_name('fused_experiment_stable.py').resolve(),
             Path(__file__).with_name('fused_hvp.py').resolve(), Path(__file__).with_name('fused_hvp_mixed.py').resolve()]
    before = sources(extra)
    captured = {}
    orig_step = native_logistic.step
    orig_minimize = native_logistic.minimize_binary
    def observed_step(*values, **kwargs):
        result = orig_step(*values, **kwargs)
        captured.update({'h0': values[6], 'center': values[11], 'w': result[0]})
        return result
    with threadpool_limits(limits=1):
        X, y, weights, ratio = dataset(case)
        if args.case == 'rank4096':
            half = X.shape[1] // 2
            ratio = np.tile(np.array([2.0, 0.5], dtype=np.float32), half // 2)
            X[:, half:] = X[:, :half] * ratio
        null_columns = None
        if args.case == 'rankgeneral4096':
            # Cross-block three-column relation, exactly represented in
            # float32, but not generally preserved after independent fp16
            # rounding. Use multiples of 1/2048 so fp32 addition is exact.
            rng = np.random.default_rng(args.seed + 231)
            a = rng.integers(-4096, 4097, len(y), dtype=np.int32).astype(np.float32) / np.float32(2048)
            b = rng.integers(-4096, 4097, len(y), dtype=np.int32).astype(np.float32) / np.float32(2048)
            X[:, 1], X[:, 2047], X[:, 4095] = a, b, a + b
            y = (a + 0.3 * b + rng.normal(scale=2.0, size=len(y)) > 0).astype(np.int32)
            null_columns = (1, 2047, 4095)
            assert np.all(X[:, 4095].astype(np.float64) == X[:, 1].astype(np.float64) + X[:, 2047].astype(np.float64))
        try:
            native_logistic.step = observed_step
            if args.force_managed:
                def forced_minimize(*values, **kwargs):
                    kwargs['use_native_loop'] = False
                    return orig_minimize(*values, **kwargs)
                native_logistic.minimize_binary = forced_minimize
            with warnings.catch_warnings(record=True) as caught, tuning_context(force_backend='mlx', lbfgs_sketch_size=0):
                warnings.simplefilter('always')
                mx.synchronize(); start = time.perf_counter()
                model = LogisticRegression(C=case.C, tol=1e-4, max_iter=args.initial_budget).fit(X, y, sample_weight=weights)
                mx.synchronize(); fit_ms = 1000 * (time.perf_counter() - start)
        finally:
            native_logistic.step = orig_step
            native_logistic.minimize_binary = orig_minimize
        if not captured:
            raise RuntimeError('managed fit did not expose initial metric and center')
        report_start = time.perf_counter()
        base_score, _ = independent_score(model, X, y, weights, case.C, ratio)
        if null_columns:
            c = np.asarray(model.coef_[0], dtype=np.float64)
            base_score['three_column_null_ratio'] = float(abs(-c[1] - c[2047] + c[4095]) / (math.sqrt(3) * max(np.linalg.norm(c), np.finfo(float).tiny)))
        reporting_seconds = time.perf_counter() - report_start
        prep_start = time.perf_counter()
        mx.eval(*captured.values())
        center = captured['center']
        center_host = np.asarray(center, dtype=np.float64)
        coefficients = mx.array(model.coef_[0], dtype=mx.float32)
        centered_bias = float(model.intercept_[0] + model.coef_[0] @ center_host)
        captured_w = np.asarray(captured['w'], dtype=np.float64)
        if (np.max(np.abs(captured_w[:-1] - model.coef_[0])) > 1e-6
                or abs(captured_w[-1] - centered_bias) > 1e-6):
            raise RuntimeError('captured final optimizer state differs from exported model')
        Xdev = mx.array(X, mx.float32) - center
        ydev = mx.array(y, mx.float32)
        sw = mx.ones(len(y), mx.float32) if weights is None else mx.array(weights, mx.float32)
        denom = float(len(y) if weights is None else np.sum(weights, dtype=np.float64))
        l2 = 1.0 / (case.C * denom)
        reg = mx.concatenate([mx.full((X.shape[1],), l2, mx.float32), mx.zeros((1,), mx.float32)])
        fun = logistic._native_binary_objective(Xdev, ydev, None if weights is None else sw, denom, l2, True)
        mx.eval(Xdev, ydev, sw, reg, coefficients)
        mx.synchronize(); prep_ms = 1000 * (time.perf_counter() - prep_start)
        cg_start = time.perf_counter()
        theta, delta, gradient, cg_trace = cg_step(Xdev, ydev, sw, denom, coefficients, centered_bias,
                                                   case.C, args.steps)
        slope = float(mx.sum(gradient * delta))
        mx.synchronize(); cg_ms = 1000 * (time.perf_counter() - cg_start)
        effective_tol = 5e-5
        select_start = time.perf_counter()
        base_loss, _ = fun(theta.reshape(1, -1))
        candidate = None
        attempts = []
        if not math.isfinite(slope) or slope >= 0:
            raise RuntimeError('CG direction is not finite descent')
        for alpha in (1.0, 0.5, 0.25, 0.125):
            proposed = theta + alpha * delta
            value, grad = fun(proposed.reshape(1, -1))
            gradmax = float(original_max(grad, center))
            ok = (math.isfinite(value) and math.isfinite(gradmax)
                  and value <= base_loss + 1e-4 * alpha * slope and gradmax <= effective_tol)
            attempts.append({'alpha': alpha, 'loss': value, 'gradient_max': gradmax, 'accepted': ok})
            if ok:
                candidate = (proposed, grad.reshape(-1), value)
                break
        mx.synchronize(); selection_ms = 1000 * (time.perf_counter() - select_start)
        result = {'case': args.case, 'seed': args.seed, 'C': case.C, 'initial_budget': args.initial_budget,
                  'max_iter': args.max_iter,
                  'force_managed': args.force_managed, 'fit_ms': fit_ms, 'prep_ms': prep_ms, 'cg_ms': cg_ms,
                  'selection_ms': selection_ms, 'cg_hvp_count': len(cg_trace), 'cg_trace': cg_trace,
                  'baseline_n_iter': int(model.n_iter_[0]), 'baseline_warnings': [str(w.message) for w in caught],
                  'baseline_score': base_score, 'descent_slope': slope, 'alpha_attempts': attempts,
                  'converged': False}
        did_correct = candidate is not None
        if candidate is None:
            candidate = (theta, gradient, base_loss)
        if int(model.n_iter_[0]) + int(did_correct) < args.max_iter:
            w, g, objective = candidate
            n, d = X.shape
            metadata = np.zeros(12, dtype=np.float32)
            metadata[0] = int(model.n_iter_[0]) + int(did_correct)
            metadata[4] = metadata[10] = np.inf
            metadata[11] = objective
            history_s = mx.zeros((10, d + 1), mx.float32)
            history_y = mx.zeros_like(history_s)
            history_c = mx.zeros((10, 2), mx.float32)
            logits = Xdev @ w[:d] + w[d]
            state = (w, g, w, g, history_s, history_y, history_c, mx.array(metadata), logits)
            config_tol = mx.array(effective_tol, mx.float32)
            denom_mx = mx.array(denom, mx.float32)
            c1 = mx.array(1e-4, mx.float32)
            min_curvature = mx.array(1e-12, mx.float32)
            alpha_start = mx.array(1.0, mx.float32)
            final = None
            continue_start = time.perf_counter()
            trajectory = []
            for _ in range(args.max_iter - int(metadata[0])):
                state = orig_step(Xdev, ydev, sw, reg, denom_mx, config_tol, captured['h0'],
                                  c1, min_curvature, 8, alpha_start, center, *state,
                                  weighted=weights is not None)
                mx.eval(state)
                m = np.asarray(state[7], dtype=np.float64)
                objective, direct_grad = fun(state[0].reshape(1, -1))
                direct_max = float(original_max(direct_grad, center))
                recent = .5 * (abs(float(m[10])) + abs(float(m[4]))) if m[0] >= 2 else abs(float(m[10]))
                progress = ((weights is None and (d < 2048 or int(m[0]) == 0)) or direct_max == 0
                            or ((weights is None or int(m[0]) >= 2) and math.isfinite(recent)
                                and recent <= effective_tol * (0.025 if weights is not None or d >= 2048 else 1.0)
                                * max(abs(objective), 1e-12)))
                ok = int(m[1]) in (0, 1) and math.isfinite(objective) and direct_max <= effective_tol and progress
                trajectory.append({'n_iter': int(m[0]), 'status': int(m[1]), 'loss': objective,
                                   'gradient_max': direct_max, 'recent': recent, 'progress': progress})
                if ok or int(m[1]) != 0:
                    final = (state[0], objective, direct_max, ok)
                    break
            if final is None and trajectory:
                final = (state[0], objective, direct_max, False)
            mx.synchronize(); continue_ms = 1000 * (time.perf_counter() - continue_start)
            result.update({'continuation_ms': continue_ms, 'trajectory': trajectory, 'converged': bool(final and final[3])})
            result['accepted_cg_correction'] = did_correct
            result['accepted_outer_steps'] = int(trajectory[-1]['n_iter']) if trajectory else int(metadata[0])
            if final is not None:
                final_w = np.asarray(final[0], dtype=np.float64)
                exported = SimpleNamespace(coef_=final_w[:-1].reshape(1, -1),
                                           intercept_=np.array([final_w[-1] - final_w[:-1] @ center_host]))
                report_start = time.perf_counter()
                final_score, _ = independent_score(exported, X, y, weights, case.C, ratio)
                if null_columns:
                    c = np.asarray(exported.coef_[0], dtype=np.float64)
                    final_score['three_column_null_ratio'] = float(abs(-c[1] - c[2047] + c[4095]) / (math.sqrt(3) * max(np.linalg.norm(c), np.finfo(float).tiny)))
                reporting_seconds += time.perf_counter() - report_start
                result['final_score'] = final_score
        result['timed_total_ms'] = sum(result.get(k, 0.0) for k in ('fit_ms', 'prep_ms', 'cg_ms', 'selection_ms', 'continuation_ms'))
        result['wall_total_excluding_independent_scoring_ms'] = 1000 * (time.perf_counter() - start - reporting_seconds)
        result['independent_scoring_ms'] = 1000 * reporting_seconds
        result['source_before'] = before
        if null_columns:
            half = X[:, list(null_columns)].astype(np.float16).astype(np.float64)
            result['fp16_null_violation_rows'] = int(np.count_nonzero(half[:, 2] != half[:, 0] + half[:, 1]))
        result['source_after'] = sources(extra)
        result['integrity'] = result['source_before'] == result['source_after']
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + '\n')
        print('seed', args.seed, 'baseline iter', model.n_iter_, 'CG', args.steps,
              'times', {k: round(result[k], 2) for k in ('fit_ms', 'prep_ms', 'cg_ms', 'selection_ms')},
              'alpha', attempts, 'continued', result.get('converged'),
              'score', result.get('final_score'), flush=True)


if __name__ == '__main__':
    run()
