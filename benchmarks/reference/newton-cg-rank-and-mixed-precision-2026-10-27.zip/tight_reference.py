"""Tightly centered float64 references for scratch CG stress cases."""
from __future__ import annotations
import json
import time
import warnings
from pathlib import Path
from types import SimpleNamespace
import numpy as np
from sklearn.linear_model import LogisticRegression
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case, dataset, independent_score, sources

specs = [
    Case('ill_conditioned_4096', 20_000, 4_096, seed=2027, ill_conditioned=True),
    Case('ill_conditioned_4096', 20_000, 4_096, seed=41, ill_conditioned=True, C=.1),
    Case('ill_conditioned_4096', 20_000, 4_096, seed=41, ill_conditioned=True, C=10),
    Case('weighted_ill_4096', 20_000, 4_096, seed=41, weighted=True, ill_conditioned=True),
]
before = sources([Path(__file__).resolve()]); rows=[]
with threadpool_limits(limits=1):
    for case in specs:
        X, y, sw, ratio = dataset(case)
        center=X.mean(axis=0,dtype=np.float64); centered=X.astype(np.float64)-center
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always'); start=time.perf_counter()
            model=LogisticRegression(C=case.C,tol=1e-10,max_iter=3000).fit(centered,y,sample_weight=sw)
            elapsed=time.perf_counter()-start
        transformed=SimpleNamespace(coef_=model.coef_, intercept_=model.intercept_-model.coef_@center)
        score,_=independent_score(transformed,X,y,sw,case.C,ratio)
        row={'case':case.name,'seed':case.seed,'C':case.C,'elapsed_seconds':elapsed,
             'n_iter':model.n_iter_.tolist(),'score':score,
             'warnings':[{'category':w.category.__name__,'message':str(w.message)} for w in caught]}
        rows.append(row);print(row,flush=True)
        Path('bench/cg_polish/tight-reference.json').write_text(json.dumps({'rows':rows,'source_before':before},indent=2)+'\n')
after=sources([Path(__file__).resolve()])
Path('bench/cg_polish/tight-reference.json').write_text(json.dumps({'rows':rows,'source_before':before,'source_after':after,'integrity':before==after},indent=2)+'\n')
