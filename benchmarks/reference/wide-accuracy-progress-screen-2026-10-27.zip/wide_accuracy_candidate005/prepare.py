"""Isolate and build a strict wide-progress prototype; no production edits."""
import hashlib
import json
import shutil
import stat
import subprocess
import sysconfig
import zipfile
from pathlib import Path

root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parent
source=out/'candidate'
if source.exists(): shutil.rmtree(source)
shutil.copytree(root/'src',source,ignore=shutil.ignore_patterns('__pycache__'))

def replace(path,old,new):
    text=path.read_text(); count=text.count(old)
    assert count==1,(path,old,count)
    path.write_text(text.replace(old,new))

core=source/'mlxlearn/_solvers/native_logistic.py'
replace(core,'(WEIGHTED ? 0.025f : 1.0f)','(WEIGHTED ? 0.025f : (D>=2048 ? 0.05f : 1.0f))')
text=core.read_text();assert text.count('(0.025 if weighted else 1.0)')==2
text=text.replace('(0.025 if weighted else 1.0)','(0.025 if weighted else (0.05 if d >= 2048 else 1.0))');core.write_text(text)
command=source/'mlxlearn/_solvers/native_command.py'
replace(command,'(0.025 if weighted else 1.0)','(0.025 if weighted else (0.05 if d >= 2048 else 1.0))')
device=source/'mlxlearn_device/_logistic.py'
replace(device,'(0.025 if weighted else 1.0)','(0.025 if weighted else (0.05 if d >= 2048 else 1.0))')
metal=source/'mlxlearn/_solvers/_metal_loop.mm'
replace(metal,'(weighted ? 0.025f : 1.0f)','(weighted ? 0.025f : (d>=2048 ? 0.05f : 1.0f))')
text=metal.read_text().replace('MLXLearnRetainTestBufferV5','MLXLearnRetainTestBufferWideCandidate005');metal.write_text(text)
binary=source/'mlxlearn/_solvers/_metal_loop.abi3.so'
subprocess.run(['clang++','-O3','-shared','-fobjc-arc','-std=c++17','-undefined','dynamic_lookup',
                '-framework','Foundation','-framework','Metal',f'-I{sysconfig.get_path("include")}',str(metal),'-o',str(binary)],check=True)
files={p.relative_to(source).as_posix():p.read_bytes() for p in (source/'mlxlearn').rglob('*') if p.is_file() and (p.suffix=='.py' or p.name=='py.typed') and '__pycache__' not in p.parts}
path=out/'candidate.zip'
with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,data in sorted(files.items()):
        info=zipfile.ZipInfo(name);info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest={'description':'Scratch 0.05 wide progress prototype.','archive':{'filename':path.name,'sha256':sha(path.read_bytes())},'files':{k:sha(v) for k,v in files.items()},'native_binary_sha256':sha(binary.read_bytes())}
path.with_suffix('.manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(path,sha(binary.read_bytes()))
