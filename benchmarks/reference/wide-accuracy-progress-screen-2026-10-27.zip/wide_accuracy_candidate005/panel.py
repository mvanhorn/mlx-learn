"""Scratch comparison for a stricter wide progress rule; retains all results."""
import hashlib
import json
import math
import os
import statistics
import warnings
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace
import zipfile

import numpy as np
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits

from benchmarks.hessian_logistic import Case, dataset, fit_once, independent_score
from benchmarks.logistic_wide import frozen_reference
from benchmarks.sketch_weighted import fit_previous_sketch, reference_sketch_module

root=Path(__file__).resolve().parents[2]
here=Path(__file__).resolve().parent
archive=here/'candidate.zip'
extension=here/'candidate/mlxlearn/_solvers/_metal_loop.abi3.so'
reference_sources=root/'benchmarks/reference/wide-repair-start-sources-2026-10-27.zip'
baseline=root/'benchmarks/reference/wide-repair-start-2026-10-27.zip'
baseline_extension=root/'bench/wide-repair-start/_metal_loop.abi3.so'
extra=[archive,archive.with_suffix('.manifest.json'),extension,here/'candidate/mlxlearn/_solvers/_metal_loop.mm',here/'prepare.py',reference_sources,reference_sources.with_suffix('.manifest.json'),baseline,baseline.with_suffix('.manifest.json'),baseline_extension,Path(__file__).resolve(),root/'benchmarks/hessian_logistic.py',root/'benchmarks/logistic_wide.py',root/'benchmarks/logistic_gpu.py',root/'benchmarks/sketch_weighted.py',root/'src/mlxlearn_device/hessian_sketch.py']
extra += [p for p in (root/'src/mlxlearn').rglob('*') if p.is_file() and '__pycache__' not in p.parts and (p.suffix in {'.py','.mm','.so'} or p.name=='py.typed')]
def source_hashes():
 return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in extra}
with zipfile.ZipFile(baseline) as a, zipfile.ZipFile(archive) as b:
 assert set(a.namelist())==set(b.namelist())
 differences=[name for name in a.namelist() if a.read(name)!=b.read(name)]
 assert set(differences)=={'mlxlearn/_solvers/native_command.py','mlxlearn/_solvers/native_logistic.py'},differences
 assert all(a.read(name)==(root/'src'/name).read_bytes() for name in a.namelist()),'live baseline differs from frozen baseline source'
 core=a.read('mlxlearn/_solvers/native_logistic.py').decode().replace('(WEIGHTED ? 0.025f : 1.0f)','(WEIGHTED ? 0.025f : (D>=2048 ? 0.05f : 1.0f))').replace('(0.025 if weighted else 1.0)','(0.025 if weighted else (0.05 if d >= 2048 else 1.0))')
 command=a.read('mlxlearn/_solvers/native_command.py').decode().replace('(0.025 if weighted else 1.0)','(0.025 if weighted else (0.05 if d >= 2048 else 1.0))')
 assert core.encode()==b.read('mlxlearn/_solvers/native_logistic.py')
 assert command.encode()==b.read('mlxlearn/_solvers/native_command.py')
with zipfile.ZipFile(reference_sources) as z:
 metal=z.read('src/mlxlearn/_solvers/_metal_loop.mm').decode().replace('(weighted ? 0.025f : 1.0f)','(weighted ? 0.025f : (d>=2048 ? 0.05f : 1.0f))').replace('MLXLearnRetainTestBufferV5','MLXLearnRetainTestBufferWideCandidate005')
 assert metal==(here/'candidate/mlxlearn/_solvers/_metal_loop.mm').read_text()
assert hashlib.sha256((root/'src/mlxlearn/_solvers/_metal_loop.abi3.so').read_bytes()).hexdigest()==hashlib.sha256(baseline_extension.read_bytes()).hexdigest(),'live native binary differs from frozen baseline'
out={'method':'rotating full fits, original float64 objective/gradient outside timing, independently centered tight float64 sklearn reference',
     'source_before':source_hashes(),'case_source_differences':differences,'cases':[]}
output=here/'panel.json'
frozen_sketch=reference_sketch_module(reference_sources)
cases=[
 Case('wide_4096',20000,4096,seed=41,C=1),
 Case('wide_4096',20000,4096,seed=83,C=1),
 Case('wide_4096',20000,4096,seed=2027,C=1),
 Case('wide_4096',20000,4096,seed=41,C=.1),
 Case('wide_4096',20000,4096,seed=41,C=10),
 Case('wide_4096',20000,4096,seed=41,C=1e6),
 Case('weighted_4096',20000,4096,seed=41,C=1,weighted=True),
 Case('ill_conditioned_4096',20000,4096,seed=41,C=1,ill_conditioned=True),
 Case('ill_conditioned_4096',20000,4096,seed=83,C=1,ill_conditioned=True),
 Case('odd_2049',20000,2049,seed=41,C=1),
 Case('odd_4095',20000,4095,seed=41,C=1),
 Case('rank_deficient_1024',20000,1024,seed=41,C=1e6,rank_deficient=True),
 Case('shifted_1024',20000,1024,seed=41,C=1,shifted=True),
]
variants=('current','candidate','sketch','candidate_sketch')
if os.environ.get('WIDE_PROGRESS_CASE_LIMIT'):
 cases=cases[:int(os.environ['WIDE_PROGRESS_CASE_LIMIT'])]
with (frozen_reference(archive=archive,extension=extension) as candidate_ref,
      threadpool_limits(limits=1)):
 for case in cases:
  X,y,weights,ratio=dataset(case)
  center=X.mean(axis=0,dtype=np.float64)
  centered=X.astype(np.float64)-center
  with warnings.catch_warnings(record=True) as caught:
   warnings.simplefilter('always')
   oracle=SkLogisticRegression(C=case.C,tol=1e-10,max_iter=3000).fit(centered,y,sample_weight=weights)
  oracle=SimpleNamespace(coef_=oracle.coef_,intercept_=oracle.intercept_-oracle.coef_@center)
  score,pred=independent_score(oracle,X,y,weights,case.C,ratio)
  oracle_warnings=[str(w.message) for w in caught]
  oracle_ok=not oracle_warnings and math.isfinite(score['gradient_max_abs_float64']) and score['gradient_max_abs_float64']<=1e-7
  del centered
  samples={v:[] for v in variants}; qualities={v:[] for v in variants}; details={v:[] for v in variants}
  for rep in range(6):
   order=variants[rep%4:]+variants[:rep%4]
   if rep%2: order=order[::-1]
   for v in order:
    if v=='candidate_sketch':
     model,sec,info=fit_previous_sketch(X,y,weights,case,candidate_ref,frozen_sketch,1e-4,200,4)
    else:
     variant={'candidate':'baseline'}.get(v,v)
     model,sec,info=fit_once(variant,X,y,weights,case,candidate_ref,1e-4,200,None,4,4)
    if rep>=2:
     samples[v].append(sec*1000);details[v].append(info)
     qualities[v].append(independent_score(model,X,y,weights,case.C,ratio,(score['objective_float64'],pred))[0])
  failures=[]
  for v in variants:
   for q,info in zip(qualities[v],details[v],strict=True):
    if info.get('backend')!='mlx': failures.append((v,'unexpected backend'))
    if any(not solution['converged'] for solution in info.get('solutions',[])): failures.append((v,'nonconverged solution'))
    if 'sketch' in v and (not any(call['seeded'] and call['pairs']>0 for call in info['sketch_calls']) or 'completed' not in info['native_loop_calls']): failures.append((v,'seeded native loop was not exercised'))
    if not math.isfinite(q['gradient_max_abs_float64']) or q['gradient_max_abs_float64']>1e-4: failures.append((v,'gradient'))
    if any(w['category']=='ConvergenceWarning' for w in info['warnings']): failures.append((v,'warning'))
    if oracle_ok and (not math.isfinite(q['objective_relative_gap_to_sklearn']) or q['objective_relative_gap_to_sklearn']>1e-5): failures.append((v,'tight objective'))
    if case.rank_deficient and q['nullspace_coefficient_relative']>1e-3: failures.append((v,'nullspace'))
  for variant,old in [('candidate','current'),('candidate_sketch','sketch')]:
   for q,p in zip(qualities[variant],qualities[old],strict=True):
    if (q['objective_float64']-p['objective_float64'])/abs(p['objective_float64'])>1e-5: failures.append((variant,'regression to prior'))
  row={'case':asdict(case),'reference':score,'reference_warnings':oracle_warnings,'reference_valid':oracle_ok,
       'median_ms':{k:statistics.median(v) for k,v in samples.items()},'samples_ms':samples,'quality':qualities,'details':details,'failures':failures}
  out['cases'].append(row);print(case.name,case.seed,case.C,case.weighted,'ms',row['median_ms'],'ref_ok',oracle_ok,'failures',failures,flush=True)
  output.write_text(json.dumps(out,indent=2)+'\n')
out['source_after']=source_hashes();out['source_integrity_pass']=out['source_before']==out['source_after'];output.write_text(json.dumps(out,indent=2)+'\n')
