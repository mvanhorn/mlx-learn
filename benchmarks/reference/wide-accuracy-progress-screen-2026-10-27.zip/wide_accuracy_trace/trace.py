import json
import time
import warnings
from pathlib import Path

import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits

from benchmarks.hessian_logistic import Case, dataset, independent_score, sources
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression

out = {"method": "accepted-iteration budget trace at tol 1e-8; centered float64 reference", "rows": [], "sources_before": sources()}
path = Path(__file__).with_name('trace.json')
original = native_command._metal_loop

for seed, C in [(41, 1.0), (83, 1.0), (41, 10.0)]:
    case = Case('wide_4096', 20_000, 4_096, seed=seed, C=C)
    X, y, sw, ratio = dataset(case)
    with threadpool_limits(limits=1):
        center = X.mean(axis=0, dtype=np.float64)
        centered = X.astype(np.float64) - center
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            ref = SkLogisticRegression(C=C, tol=1e-10, max_iter=3000).fit(centered, y)
        ref.intercept_ = ref.intercept_ - ref.coef_ @ center
        ref_score, pred = independent_score(ref, X, y, sw, C, ratio)
        print('REFERENCE',seed,C,ref_score,[str(w.message) for w in caught],flush=True)
        del centered
        for sketch in [0, 4]:
            for budget in [16, 18, 20, 22, 24, 28]:
                class Capture:
                    def __init__(self): self.events=[]
                    def run(self, *args):
                        result = original.run(*args); self.events.append(result[1:]); return result
                capture=Capture(); native_command._metal_loop=capture
                try:
                    with warnings.catch_warnings(record=True) as caught, tuning_context(force_backend='mlx', lbfgs_sketch_size=sketch):
                        warnings.simplefilter('always')
                        mx.synchronize(); begin=time.perf_counter()
                        model=LogisticRegression(C=C,tol=1e-8,max_iter=budget).fit(X,y)
                        mx.synchronize(); duration=(time.perf_counter()-begin)*1000
                finally: native_command._metal_loop=original
                score,_=independent_score(model,X,y,sw,C,ratio,(ref_score['objective_float64'],pred))
                ev=capture.events[-1] if capture.events else None
                recent=None if ev is None else (abs(ev[3])+abs(ev[4]))*0.5/max(abs(score['objective_float64']),1e-12)
                row={'seed':seed,'C':C,'sketch':sketch,'budget':budget,'n_iter':model.n_iter_.tolist(),'duration_ms':duration,'score':score,'recent_relative':recent,'events':capture.events,'warnings':[str(w.message) for w in caught]}
                out['rows'].append(row); print('FIT',seed,C,sketch,budget,score['objective_relative_gap_to_sklearn'],recent, model.n_iter_,flush=True)
                path.write_text(json.dumps(out,indent=2)+'\n')
out['sources_after']=sources();out['source_integrity_pass']=out['sources_before']==out['sources_after'];path.write_text(json.dumps(out,indent=2)+'\n')
