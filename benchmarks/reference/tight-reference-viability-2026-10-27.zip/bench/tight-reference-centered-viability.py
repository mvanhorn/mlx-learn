import time, warnings
from types import SimpleNamespace
import numpy as np
from sklearn.linear_model import LogisticRegression
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case, independent_score
from benchmarks.sketch_weighted import benchmark_dataset, tight_reference_usable

with threadpool_limits(limits=1):
    for name in ('weighted_unbalanced_1024', 'weighted_rare_1024', 'weighted_effective_unbalanced_1024'):
        for seed in (41, 83, 2027):
            case = Case(name, 20000, 1024, seed=seed, weighted=True)
            X, y, w, ratio = benchmark_dataset(case)
            center = X.mean(axis=0, dtype=np.float64)
            centered = np.asarray(X, dtype=np.float64) - center
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always')
                t = time.perf_counter()
                model = LogisticRegression(C=1, tol=1e-9, max_iter=3000).fit(centered, y, sample_weight=w)
            original = SimpleNamespace(coef_=model.coef_, intercept_=model.intercept_ - model.coef_ @ center)
            score, _ = independent_score(original, X, y, w, 1, ratio)
            messages = [{'category': x.category.__name__, 'message': str(x.message)} for x in caught]
            print(name, seed, 'sec', round(time.perf_counter() - t, 2), 'iterations', model.n_iter_.tolist(),
                  'gradient', score['gradient_max_abs_float64'], 'valid',
                  tight_reference_usable(score, messages, 1e-4), 'warnings', messages, flush=True)
