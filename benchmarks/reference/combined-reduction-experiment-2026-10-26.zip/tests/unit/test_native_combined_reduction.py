"""Fused candidate-loss and gradient reductions for wide logistic steps."""

from __future__ import annotations

import mlx.core as mx
import numpy as np
import pytest

from mlxlearn._common.device import gpu_available, use_device
from mlxlearn._solvers.native_logistic_fused import _combined_reduction

pytestmark = pytest.mark.gpu


@pytest.mark.parametrize(
    "blocks,features,candidates",
    [(1, 513, 1), (9, 512, 8), (157, 1025, 24), (625, 2049, 32), (1024, 4097, 8)],
)
def test_combined_reduction_tracks_float64_reference(blocks, features, candidates):
    if not gpu_available():
        pytest.skip("requires an MLX GPU")
    rng = np.random.default_rng(801 + blocks)
    # Independent signs exercise cancellation and nonaligned last feature groups.
    losses = rng.normal(scale=1e-4, size=(candidates, blocks)).astype(np.float32)
    parts = rng.normal(size=(blocks, features)).astype(np.float32)
    denominator = 131.25
    with use_device("gpu"):
        diffs, gradient = _combined_reduction(
            inputs=[mx.array(losses), mx.array(parts), mx.array(denominator)],
            template=[("B", blocks), ("P", features), ("CAND", candidates)],
            grid=(((features + 31) // 32) * 128, 1, 1),
            threadgroup=(128, 1, 1),
            output_shapes=[(candidates,), (features,)],
            output_dtypes=[mx.float32, mx.float32],
        )
        mx.eval(diffs, gradient)
    expected_diffs = losses.astype(np.float64).sum(axis=1)
    expected_gradient = parts.astype(np.float64).sum(axis=0) / denominator
    np.testing.assert_allclose(np.asarray(diffs), expected_diffs, rtol=4e-5, atol=2e-9)
    np.testing.assert_allclose(np.asarray(gradient), expected_gradient, rtol=4e-5, atol=8e-7)
