# Rejected fused reduction experiment

This source-only overlay is the secondary MLX scheduling experiment, separate
from the native C++/Metal command-loop prototype. Its `native_logistic_fused.py`
adds one four-SIMD Metal reduction for candidate losses and the first-candidate
gradient, with the original MLX reductions retained above 1,024 row blocks. It
was tested against the complete unmodified package in
`overhead-logistic-2026-10-26.zip`; it did not produce a reliable complete-fit
speedup and was not retained in the library.

The raw 18-repeat results are in
`benchmarks/results/combined-reduction-experiment-2026-10-26.json`. The
source-integrity audit passed at measurement time. The candidate and the three
benchmark modules (`logistic_wide.py`, `logistic_gpu.py`, and
`logistic_native.py`) here match the hashes recorded in that JSON. The dedicated
test, benchmark `_harness.py`, and benchmark package initializer were not part
of the measurement-time hash list; these are the copies present immediately
after that run, so their exact measurement-time identity cannot be independently
certified from the JSON. The archived environment specification is the
measurement-time `pyproject.toml`. The reference package archive and its
manifest have separately recorded SHA-256 hashes in this overlay's manifest and
the raw JSON.

From the repository root, recreate the baseline and overlay in an ignored
scratch directory inside the repository (the benchmark records the Git revision):

```bash
repo_root="$(pwd)"
scratch_dir="$(mktemp -d "$repo_root/bench/combined-reduction-repro.XXXXXX")"
unzip -q "$repo_root/benchmarks/reference/overhead-logistic-2026-10-26.zip" -d "$scratch_dir"
unzip -qo "$repo_root/benchmarks/reference/combined-reduction-experiment-2026-10-26.zip" -d "$scratch_dir"
cd "$scratch_dir"
python3 -m pytest -q tests/unit/test_native_combined_reduction.py
python3 -m benchmarks.logistic_wide \
  --reference-archive "$repo_root/benchmarks/reference/overhead-logistic-2026-10-26.zip" \
  --profile full --case wide_20k_1024 --case wide_weighted \
  --case wide_60k_1024 --case wide_40k_2048 --dtype both \
  --repeats 18 --warmup 3 --threads 1 \
  --output combined-reduction-replay.json --report combined-reduction-replay.md \
  > combined-reduction-replay.log 2>&1
```

Run with the measured environment described in the JSON. Measurements include
complete fresh fits and alternate all six variant orders three times; quality
checks are independent float64 objective, gradient and prediction comparisons.
The benchmark runs on a shared machine and timings vary. At 20k × 1,024 the
float32 median changed from 6.727 ms to 6.492 ms but won only 4/18 paired
repetitions and regressed on means; float64 changed from 9.270 ms to 9.903 ms.
The weighted float64 median changed from 10.774 ms to 14.338 ms. All eight
quality audits passed, and no measurements were discarded.
