"""Scratch float64 recurrence and general-null relation checks for wider direction."""
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import numpy as np
import mlx.core as mx
from bench.native_math.cooperative import kernel
from mlxlearn._solvers.native_logistic import _direction
rng=np.random.default_rng(8001)
rows=[]
for d in (513,1024,2049,4096):
 for count in (0,1,5,10):
  for head in (0,4,9):
   p=d+1;m=10
   sh=rng.normal(size=(m,p)).astype(np.float32)*.01
   yh=sh*(rng.uniform(.1,2,p).astype(np.float32))
   wh=rng.normal(size=p).astype(np.float32)*.01;gh=rng.normal(size=p).astype(np.float32)*.01
   h0=np.full(p,4,dtype=np.float32)
   hc=np.stack([1/np.sum(sh*yh,axis=1),np.sum(sh*yh,axis=1)/np.sum(yh*yh*h0,axis=1)],axis=1).astype(np.float32)
   q=gh.astype(float);alphas=[]
   for a in range(count):
    h=(head+m-1-a)%m;alpha=float(sh[h].astype(float)@q)*hc[h,0];alphas.append(alpha);q-=alpha*yh[h].astype(float)
   gamma=hc[(head+m-1)%m,1] if count else 1.;q*=gamma*h0
   for a in range(count):
    h=(head+m-count+a)%m;beta=float(yh[h].astype(float)@q)*hc[h,0];q+=sh[h].astype(float)*(alphas[count-1-a]-beta)
   ref=-q
   inputs=[mx.array(x) for x in (wh,gh,wh,gh,sh,yh,hc,np.array([10,0,count,head,-.001,0,0,0,1,80,-.001,.3],np.float32),np.full(p,.0001,np.float32),np.array(1e-9,np.float32),h0,np.array(1e-10,np.float32),np.array(1,np.float32),np.zeros(d,np.float32))]
   outputs=[]
   for width in (32,256,512):
    chosen=_direction if width==32 else kernel
    template=[('P',p),('D',d),('M',m),('WEIGHTED',0)]+([] if width==32 else [('THREADS',width)])
    out=chosen(inputs=inputs,template=template,grid=(width,1,1),threadgroup=(width,1,1),output_shapes=[(p,),(m,p),(m,p),(m,2),(12,)],output_dtypes=[mx.float32]*5)
    mx.eval(out)
    actual=np.asarray(out[0]);err=float(np.linalg.norm(actual-ref)/max(np.linalg.norm(ref),1e-30))
    outputs.append({'threads':width,'relative_l2_error':err,'status':float(out[4][1]),'slope':float(out[4][5]),'descent':float(actual.astype(float)@gh.astype(float))<0})
   rows.append({'features':d,'count':count,'head':head,'checks':outputs})
result={'cases':rows,'max_relative_error':max(c['relative_l2_error'] for row in rows for c in row['checks']),'all_descent':all(c['descent'] for row in rows for c in row['checks'])}
print(result['max_relative_error'],result['all_descent']);Path('bench/native_math/cooperative-check.json').write_text(json.dumps(result,indent=2)+'\n')
