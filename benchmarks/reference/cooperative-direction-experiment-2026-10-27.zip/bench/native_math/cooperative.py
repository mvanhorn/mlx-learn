"""Scratch wider L-BFGS vector recurrence, exact same scalar metric."""
from pathlib import Path
import mlx.core as mx
from mlxlearn._solvers.native_logistic import _REDUCE
from mlxlearn._solvers.native_command import _kernel_source
from mlxlearn._solvers import native_logistic

HELPER=r'''
inline float direction_sum(float value, uint t, threadgroup float* shared, uint width) {
 value=simd_sum(value);
 if(t%32==0)shared[t/32]=value;
 threadgroup_barrier(mem_flags::mem_threadgroup);
 value=0.0f;for(uint i=0;i<width/32;++i)value+=shared[i];
 threadgroup_barrier(mem_flags::mem_threadgroup);
 return value;
}
inline float direction_max(float value, uint t, threadgroup float* shared, uint width) {
 value=simd_max(value);
 if(t%32==0)shared[t/32]=value;
 threadgroup_barrier(mem_flags::mem_threadgroup);
 value=shared[0];for(uint i=1;i<width/32;++i)value=max(value,shared[i]);
 threadgroup_barrier(mem_flags::mem_threadgroup);
 return value;
}
'''
source=_kernel_source(Path(native_logistic.__file__),'_direction')
source=source.replace('uint t=thread_position_in_threadgroup.x;', 'uint t=thread_position_in_threadgroup.x;threadgroup float shared[THREADS/32];')
source=source.replace('(P+31)/32','(P+THREADS-1)/THREADS').replace('j+=32','j+=THREADS').replace('t+k*32','t+k*THREADS').replace('t+32*k','t+THREADS*k')
for expr in ('bad','gg','sy','yy','dot','slope','penlin','penquad'):
 source=source.replace(f'simd_sum({expr})',f'direction_sum({expr},t,shared,THREADS)')
source=source.replace('simd_max(localmax)','direction_max(localmax,t,shared,THREADS)')

kernel=mx.fast.metal_kernel(name='mlxlearn_cooperative_direction_prototype',header=_REDUCE+HELPER,input_names=['w','g','oldw','oldg','hs','hy','hc','meta','reg','tol','h0inv','min_curvature','alpha_start','center'],output_names=['direction','newhs','newhy','newhc','stats'],source=source)
