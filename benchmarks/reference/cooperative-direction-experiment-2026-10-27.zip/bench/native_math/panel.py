"""Scratch full-fit screen of candidate count and stable loss math only."""
from __future__ import annotations
import argparse, gc, hashlib, json, math, statistics, sys, time, warnings
from pathlib import Path
from dataclasses import asdict
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import mlx.core as mx
import numpy as np
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case, dataset, independent_score
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression

ROOT=Path(__file__).resolve().parent
ORIGINAL=native_command._source
BASE='inline float log1p(float x){float y=1.0f+x;return y==1.0f?x:x*(log(y)/(y-1.0f));}'
POLY='''inline float log1p(float x){
 if(abs(x)<=0.125f){
  float t=x/(2.0f+x),v=t*t;
  return (2.0f*t)*fma(v,fma(v,fma(v,1.0f/7.0f,1.0f/5.0f),1.0f/3.0f),1.0f);
 }
 float y=1.0f+x;return y==1.0f?x:x*(log(y)/(y-1.0f));
}'''
VARIANT='baseline'
def generated(*args,**kw):
 args=list(args)
 if 'cand1' in VARIANT:args[4]=1
 elif 'cand2' in VARIANT:args[4]=2
 source=ORIGINAL(*args,**kw)
 if 'dot4' in VARIANT:
  before='float values[V],z=0;\n if(row<N && active){for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;values[k]=j<D?X[ulong(row)*D+j]:0.0f;if(j<D)z=fma(values[k],direction[j],z);}}'
  after='float values[V],z=0,z0=0,z1=0,z2=0,z3=0;\n if(row<N && active){for(uint k=0;k<V;k+=4){'
  for i in range(4):
   after+=f'if(k+{i}<V){{uint j=fs*CHUNK+lane+(k+{i})*32;values[k+{i}]=j<D?X[ulong(row)*D+j]:0.0f;if(j<D)z{i}=fma(values[k+{i}],direction[j],z{i});}}'
  after+='}z=(z0+z1)+(z2+z3);}'
  assert source.count(before)==1
  source=source.replace(before,after)
 if VARIANT.startswith('coop'):
  from bench.native_math.cooperative import HELPER,source as COOP_SOURCE
  from mlxlearn._solvers import native_logistic
  width=int(VARIANT[4:])
  original_body=native_command._kernel_source(Path(native_logistic.__file__),'_direction')
  assert source.count(original_body)==1
  source=source.replace(original_body,COOP_SOURCE)
  source=source.replace('kernel void direction_kernel(',HELPER+'\nkernel void direction_kernel(')
  source=f'#define DIRECTION_THREADS {width}\n#define THREADS {width}\n'+source
 if 'poly' in VARIANT:
  assert source.count(BASE)==1
  source=source.replace(BASE,POLY)
 return source
native_command._source=generated

class Observed:
 def __init__(self, module):self.module=module;self.calls=[]
 def run(self,*args):
  start=time.perf_counter();out=self.module.run(*args);self.calls.append({'n_iter':out[1],'status':out[2],'n_fev':out[3],'native_ms':(time.perf_counter()-start)*1000});return out
proxy=Observed(native_command._metal_loop)
native_command._metal_loop=proxy

def fit(X,y,w,case,variant):
 global VARIANT
 VARIANT=variant;proxy.calls.clear()
 with warnings.catch_warnings(record=True) as caught:
  warnings.simplefilter('always');mx.synchronize();enabled=gc.isenabled();gc.disable()
  try:
   start=time.perf_counter()
   with tuning_context(force_backend='mlx',lbfgs_sketch_size=0):
    model=LogisticRegression(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=w)
   mx.synchronize();elapsed=(time.perf_counter()-start)*1000
  finally:
   if enabled:gc.enable()
 return model,elapsed,{'n_iter':model.n_iter_.tolist(),'warnings':[{'category':x.category.__name__,'message':str(x.message)} for x in caught],'native':proxy.calls.copy()}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--variants',nargs='+',default=['baseline','poly','cand1','cand2']);parser.add_argument('--repeats',type=int,default=5);parser.add_argument('--seeds',type=int,nargs='+',default=[41,83]);parser.add_argument('--weighted',action='store_true');parser.add_argument('--ill',action='store_true');parser.add_argument('--features',type=int,default=4096);parser.add_argument('--output',default=str(ROOT/'results.json'));args=parser.parse_args()
 names=args.variants
 paths=[Path(__file__),Path(native_command.__file__),Path(native_command.__file__).with_name('native_logistic.py'),Path(native_command.__file__).with_name('native_logistic_fused.py'),Path(native_command.__file__).with_name('_metal_loop.abi3.so')]
 def hashes():return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 out={'method':'Interleaved complete warm fresh fits, one BLAS thread, scratch native source string override; same directly scored optimizer and float32 inputs','source_before':hashes(),'parameters':vars(args),'cases':[]}
 with threadpool_limits(limits=1):
  for seed in args.seeds:
   case=Case('ordinary_4096',20000,args.features,seed=seed,weighted=args.weighted,ill_conditioned=args.ill)
   X,y,w,ratio=dataset(case);samples={v:[] for v in names};models={v:[] for v in names};details={v:[] for v in names}
   for rep in range(args.repeats+2):
    order=names[rep%len(names):]+names[:rep%len(names)]
    for variant in order:
     m,ms,detail=fit(X,y,w,case,variant)
     if rep>=2:samples[variant].append(ms);models[variant].append(m);details[variant].append(detail)
   refscore,pred=independent_score(models['baseline'][0],X,y,w,case.C,ratio)
   scores={v:[independent_score(m,X,y,w,case.C,ratio,(refscore['objective_float64'],pred))[0] for m in group] for v,group in models.items()}
   row={'case':asdict(case),'median_ms':{v:statistics.median(a) for v,a in samples.items()},'samples_ms':samples,'scores':scores,'details':details};out['cases'].append(row)
   print(seed,row['median_ms'],{v:(details[v][0],scores[v][0]) for v in names},flush=True)
   Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
 out['source_after']=hashes();out['source_integrity_pass']=out['source_before']==out['source_after'];Path(args.output).write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
