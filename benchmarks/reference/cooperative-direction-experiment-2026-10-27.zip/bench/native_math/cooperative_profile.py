import sys,time,json,statistics
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
import mlx.core as mx
from mlxlearn._solvers.native_logistic import _direction
from mlxlearn._solvers.native_logistic_fused import forward_gradient
from bench.native_math.cooperative import kernel
n,d,m=20000,4096,10;p=d+1
mx.random.seed(41)
X=mx.random.normal((n,d));y=(mx.arange(n)%2).astype(mx.float32);sw=mx.ones(n);denom=mx.array(float(n))
w=mx.random.normal((p,))*.01;g=mx.random.normal((p,))*.0005;oldw=w-.0001;oldg=g-.000001;hs=mx.random.normal((m,p))*.01;hy=hs*.1;hc=mx.stack([1/mx.sum(hs*hy,axis=1),mx.ones(m)*10],axis=1)
reg=mx.concatenate([mx.full(d,1/n),mx.zeros(1)]);tol=mx.array(1e-9);h0=mx.full(p,4.);minc=mx.array(1e-10);alpha=mx.array(1.);center=mx.zeros(d);raw=X@w[:d]+w[d]
meta=mx.array([10,0,10,0,-.001,0,0,0,1,80,-.001,.3],dtype=mx.float32)
mx.eval(X,y,sw,denom,w,g,oldw,oldg,hs,hy,hc,reg,tol,h0,minc,alpha,center,raw,meta)
def direction():return _direction(inputs=[w,g,oldw,oldg,hs,hy,hc,meta,reg,tol,h0,minc,alpha,center],template=[('P',p),('D',d),('M',m),('WEIGHTED',0)],grid=(32,1,1),threadgroup=(32,1,1),output_shapes=[(p,),(m,p),(m,p),(m,2),(12,)],output_dtypes=[mx.float32]*5)
direc,_,_,_,stats=direction();mx.eval(direc,stats)
def coop(width):return kernel(inputs=[w,g,oldw,oldg,hs,hy,hc,meta,reg,tol,h0,minc,alpha,center],template=[('P',p),('D',d),('M',m),('WEIGHTED',0),('THREADS',width)],grid=(width,1,1),threadgroup=(width,1,1),output_shapes=[(p,),(m,p),(m,p),(m,2),(12,)],output_dtypes=[mx.float32]*5)
out={}
for name,fn in [('direction',direction),('cooperative64',lambda:coop(64)),('cooperative128',lambda:coop(128)),('cooperative256',lambda:coop(256)),('cooperative512',lambda:coop(512)),('cooperative1024',lambda:coop(1024)),('forward1',lambda:forward_gradient(X,direc,raw,y,sw,stats,denom,1)),('forward2',lambda:forward_gradient(X,direc,raw,y,sw,stats,denom,2)),('forward8',lambda:forward_gradient(X,direc,raw,y,sw,stats,denom,8))]:
 times=[]
 for i in range(25):
  mx.synchronize();t=time.perf_counter();z=fn();mx.eval(z);mx.synchronize();elapsed=(time.perf_counter()-t)*1000
  if i>=5:times.append(elapsed)
 out[name]={'median_ms':statistics.median(times),'samples_ms':times}
print(out);Path('bench/native_math/cooperative-profile.json').write_text(json.dumps(out,indent=2))
