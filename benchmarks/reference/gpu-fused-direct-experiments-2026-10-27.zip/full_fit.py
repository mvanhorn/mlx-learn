"""Full-fit paired comparison for the scratch single-pass direct verifier.

GPU and CPU work in fit is timed; independent float64 scoring and predictions
are outside each timed interval. Production files are never changed.
"""
import argparse
import hashlib
import json
import math
import time
from pathlib import Path

import mlx.core as mx
import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits

from fused import direct_fused
from benchmarks.logistic_gpu import Case, make_data
from benchmarks.logistic_wide import fit_once, package_source_paths, loaded_native_extension
from mlxlearn._solvers import logistic


ORIGINAL = logistic._native_binary_objective


def candidate_objective(X, y, sw, sw_sum, l2, fit_intercept):
    denominator = mx.array(sw_sum, dtype=X.dtype)
    def fun(theta):
        parts, penalty, gradient = direct_fused(theta, X, y, sw, denominator, l2, fit_intercept)
        mx.eval(parts, penalty, gradient)
        return logistic._total(parts, penalty, sw_sum), gradient
    return fun


def hashes():
    files = package_source_paths() + [Path(__file__).resolve(), Path(__file__).with_name('fused.py').resolve()]
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}


def independent(model, X, y, weights, reference_prediction=None, chunk=256):
    n, d = X.shape
    w = np.asarray(model.coef_[0], dtype=np.float64)
    bias = float(model.intercept_[0])
    grad = np.zeros(d, dtype=np.float64)
    g_bias = loss = 0.
    predictions = np.empty(n, dtype=bool)
    sw_sum = float(n) if weights is None else float(np.sum(weights, dtype=np.float64))
    for start in range(0, n, chunk):
        end = min(start + chunk, n)
        block = np.asarray(X[start:end], dtype=np.float64)
        z = block @ w + bias
        signs = 1.0 - 2.0 * y[start:end]
        residual = signs * expit(signs * z)
        row_loss = np.logaddexp(0., signs * z)
        if weights is not None:
            residual *= weights[start:end]
            row_loss *= weights[start:end]
        grad += block.T @ residual
        g_bias += float(np.sum(residual, dtype=np.float64))
        loss += float(np.sum(row_loss, dtype=np.float64))
        predictions[start:end] = z >= 0.
    grad = grad / sw_sum + w / sw_sum
    g_bias /= sw_sum
    result = {'objective': (loss + .5 * float(w @ w)) / sw_sum,
              'gradient_max': float(max(np.max(np.abs(grad)), abs(g_bias)))}
    if reference_prediction is not None:
        result['prediction_agreement'] = float(np.mean(predictions == reference_prediction))
    return result, predictions


def run_case(name, n, d, weighted, shift, tol, repeats, seed):
    case = Case(name, n, d, weighted=weighted)
    X, y, weights = make_data(case, seed, dtype='float32')
    if shift:
        X += np.float32(shift)
    # The same sklearn reference and input are used for both native variants.
    logistic._native_binary_objective = ORIGINAL
    _, ref, ref_details = fit_once('sklearn', X, y, weights, reference=None, max_iter=200, tol=tol)
    ref_score, ref_predictions = independent(ref, X, y, weights)
    funcs = {'baseline': ORIGINAL, 'fused': candidate_objective}
    def fit(name):
        logistic._native_binary_objective = funcs[name]
        return fit_once('optimized_gpu', X, y, weights, reference=None, max_iter=200, tol=tol)
    for _ in range(2):
        for name_ in funcs:
            fit(name_)
    observations = {'baseline': [], 'fused': []}
    for i in range(repeats):
        for name_ in (('baseline', 'fused') if i % 2 == 0 else ('fused', 'baseline')):
            seconds, model, details = fit(name_)
            result, _ = independent(model, X, y, weights, ref_predictions)
            result['relative_objective_gap_sklearn'] = (result['objective'] - ref_score['objective']) / max(abs(ref_score['objective']), 1e-300)
            observations[name_].append({'seconds': seconds, 'details': details, 'quality': result})
    out = {'name': name, 'shape': [n, d], 'weighted': weighted, 'shift': shift, 'tol': tol,
           'seed': seed, 'sklearn': {'details': ref_details, 'quality': ref_score}, 'observations': observations}
    out['median_ms'] = {k: float(np.median([s['seconds'] for s in v]) * 1000) for k, v in observations.items()}
    out['summary'] = {name_: {'gradient_max_range': [min(r['quality']['gradient_max'] for r in records), max(r['quality']['gradient_max'] for r in records)],
                      'objective_gap_range': [min(r['quality']['relative_objective_gap_sklearn'] for r in records), max(r['quality']['relative_objective_gap_sklearn'] for r in records)],
                      'prediction_agreement_min': min(r['quality']['prediction_agreement'] for r in records),
                      'warning_fits': sum(bool(r['details']['warnings']) for r in records),
                      'implementations': sorted(set(r['details']['implementation'] for r in records))}
                      for name_, records in observations.items()}
    print(name, out['median_ms'], out['summary'], flush=True)
    logistic._native_binary_objective = ORIGINAL
    del X, y, weights, ref, ref_predictions
    mx.clear_cache()
    return out


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--repeats', type=int, default=12)
    p.add_argument('--output', default='bench/fused_direct/full_fit_results.json')
    args = p.parse_args()
    start_hashes = hashes()
    try:
        with threadpool_limits(limits=1):
            cases = [run_case('unweighted', 20_000, 1_024, False, 0., 1e-4, args.repeats, 41),
                     run_case('weighted', 20_000, 1_024, True, 0., 1e-4, args.repeats, 41),
                     run_case('wide4096', 20_000, 4_096, False, 0., 1e-4, args.repeats, 41),
                     run_case('shifted', 20_000, 1_024, False, 1000., 1e-4, args.repeats, 41),
                     run_case('strict', 20_000, 1_024, False, 0., 1e-6, args.repeats, 41)]
    finally:
        logistic._native_binary_objective = ORIGINAL
    end_hashes = hashes()
    output = {'repeats': args.repeats, 'order': 'balanced alternating, 2 warmups each',
              'native_extension': loaded_native_extension(), 'source_hashes': start_hashes,
              'source_integrity_passed': start_hashes == end_hashes, 'cases': cases}
    Path(args.output).write_text(json.dumps(output, indent=2, default=str) + '\n')

if __name__ == '__main__': main()
