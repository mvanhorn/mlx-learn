Scratch single-pass direct verifier experiment

`fused.py` recomputes float32 centered logits, loss, and gradient using one design-matrix pass. It is not a float64 original-input certificate. `evaluate.py` tests component accuracy and latency. `full_fit.py` injects it only into the native direct verifier, alternating complete fits against unchanged production, then independently evaluates each model in float64. `wide_followup.py` adds the four 30-pair seed/C variants.

Run with `PYTHONPATH=. python3 bench/fused_direct/wide_followup.py --repeats 30` after restoring scratch files to bench/fused_direct. All samples and per-fit audits are copied into benchmarks/results. Full-fit in-run provenance hashes the package sources, active native extension, and scratch source; imported benchmark helpers are captured here after the run, not included in the in-run hash check.

The 20k x 1024 full-fit panel did not show a reliable speed gain. The 30-pair 4096-feature panel showed a modest gain, not a general speedup claim; timings are warm, on one machine. The shifted sklearn model did not converge to a comparable solution, so its prediction agreement is not an accuracy gate. Per-fit float64 scoring is independent from this float32 scorer but does not establish universal numerical equivalence.
