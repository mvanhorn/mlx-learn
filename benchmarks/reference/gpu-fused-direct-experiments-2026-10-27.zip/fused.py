"""Scratch single-matrix-pass direct binary logistic scoring kernel.

This is a diagnostic prototype, not an independent float64 certificate or a
production replacement. It reads centered float32 features exactly once,
recomputes logits from coefficients, and obtains gradient and loss from those
logits rather than reusing optimizer caches.
"""
import mlx.core as mx

from mlxlearn._solvers.native_logistic import _REDUCE

_direct_fused = mx.fast.metal_kernel(
    name="mlxlearn_scratch_direct_fused_v1",
    header=_REDUCE,
    input_names=["X", "w", "y", "sw"],
    output_names=["loss_parts", "gradient_parts"],
    source=r"""
uint tid=thread_position_in_threadgroup.x,lane=tid%32,sg=tid/32;
uint group=threadgroup_position_in_grid.x;
constexpr uint V=(D+32*FEATURE_GROUPS-1)/(32*FEATURE_GROUPS);
constexpr uint CHUNK=V*32,DPAD=CHUNK*FEATURE_GROUPS;
constexpr uint ROW_GROUPS=GROUPS/FEATURE_GROUPS;
constexpr uint WS_GRAD=ROW_GROUPS*DPAD;
constexpr uint SCRATCH=WS_GRAD>2*GROUPS?WS_GRAD:2*GROUPS;
uint fs=sg%FEATURE_GROUPS,rs=sg/FEATURE_GROUPS;
threadgroup float scratch[SCRATCH];
float accumulator[V];for(uint k=0;k<V;++k)accumulator[k]=0;
float local_loss=0,local_bias=0;
for(uint rr=0;rr<ROWS;++rr){
 uint row=group*(ROW_GROUPS*ROWS)+rr*ROW_GROUPS+rs;
 float values[V],z=0;
 if(row<N){for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;
  values[k]=j<D?X[ulong(row)*D+j]:0.0f;if(j<D)z=fma(values[k],w[j],z);}}
 else{for(uint k=0;k<V;++k)values[k]=0;}
 z=simd_sum(z);
 if(FEATURE_GROUPS>1){
  if(lane==0)scratch[sg]=z;
  threadgroup_barrier(mem_flags::mem_threadgroup);
  z=0;for(uint f=0;f<FEATURE_GROUPS;++f)z+=scratch[rs*FEATURE_GROUPS+f];
  threadgroup_barrier(mem_flags::mem_threadgroup);
 }
 if(P>D)z+=w[D];
 float residual=0;
 if(lane==0 && row<N && sw[row]>0){
  float sign=1.0f-2.0f*y[row],u=sign*z;
  residual=sw[row]*sign*sigmoid_stable(u);
  if(fs==0){local_loss+=sw[row]*softplus_stable(u);local_bias+=residual;}
 }
 residual=simd_shuffle(residual,ushort(0));
 for(uint k=0;k<V;++k)accumulator[k]=fma(values[k],residual,accumulator[k]);
}
if(lane==0){scratch[sg]=local_loss;scratch[GROUPS+sg]=local_bias;}
threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==0 && lane==0){float loss=0,bias=0;
 for(uint s=0;s<GROUPS;++s){loss+=scratch[s];bias+=scratch[GROUPS+s];}
 loss_parts[group]=loss;if(P>D)gradient_parts[ulong(group)*P+D]=bias;
}
threadgroup_barrier(mem_flags::mem_threadgroup);
for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;scratch[rs*DPAD+j]=accumulator[k];}
threadgroup_barrier(mem_flags::mem_threadgroup);
if(rs==0){for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;if(j<D){
 float total=0;for(uint r=0;r<ROW_GROUPS;++r)total+=scratch[r*DPAD+j];
 gradient_parts[ulong(group)*P+j]=total;
}}}
""",
)


def direct_fused(theta, X, y, sw, denom, l2, fit_intercept=True):
    """Return block loss sums, penalty, and normalized centered gradient."""
    n, d = X.shape
    p = d + int(fit_intercept)
    if theta.shape != (1, p):
        raise ValueError("theta must have shape (1, d + fit_intercept)")
    if sw is None:
        sw = mx.ones(n, dtype=X.dtype)
    if d <= 1024:
        groups, feature_groups, rows = (4, 1, 32) if n >= 16384 else (2, 1, 16)
    else:
        groups, feature_groups = 8, 4
        rows = (32 if d <= 2048 else 64) if n >= 16384 else 8
    batch = groups // feature_groups * rows
    blocks = (n + batch - 1) // batch
    loss_parts, gradient_parts = _direct_fused(
        inputs=[X, theta.reshape(p), y, sw],
        template=[("N", n), ("D", d), ("P", p), ("GROUPS", groups),
                  ("ROWS", rows), ("FEATURE_GROUPS", feature_groups)],
        grid=(blocks * groups * 32, 1, 1), threadgroup=(groups * 32, 1, 1),
        output_shapes=[(blocks,), (blocks, p)], output_dtypes=[mx.float32, mx.float32],
    )
    grad = mx.sum(gradient_parts, axis=0) / denom
    if l2 > 0:
        weights = theta[0, :d]
        grad_penalty = l2 * weights
        if fit_intercept:
            grad_penalty = mx.concatenate([grad_penalty, mx.zeros(1, dtype=X.dtype)])
        grad = grad + grad_penalty
        penalty = (0.5 * l2) * mx.sum(weights * weights)
    else:
        penalty = denom - denom
    return loss_parts, penalty, grad.reshape(theta.shape)
