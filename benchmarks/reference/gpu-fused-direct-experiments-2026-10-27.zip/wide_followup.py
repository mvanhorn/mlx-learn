"""30-pair wide panel with independently scored configurable C."""
import argparse
import gc
import json
import time
import warnings
from pathlib import Path

import mlx.core as mx
import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits

import full_fit
from benchmarks.logistic_wide import observed_implementation
from mlxlearn import config_context
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import logistic, native_logistic
from mlxlearn.linear_model import LogisticRegression
from mlxlearn.linear_model import _logistic as estimator_module

C = 1.0


def fit_once(variant, X, y, weights, *, reference, max_iter, tol):
    cls = SkLogisticRegression if variant == 'sklearn' else LogisticRegression
    with (config_context(device='auto'),
          tuning_context(force_backend='' if variant == 'sklearn' else 'mlx'),
          observed_implementation(estimator_module, logistic, native_logistic) as records,
          warnings.catch_warnings(record=True) as caught):
        warnings.simplefilter('always')
        mx.synchronize()
        enabled = gc.isenabled(); gc.disable()
        try:
            start = time.perf_counter()
            model = cls(C=C, tol=tol, max_iter=max_iter).fit(X, y, sample_weight=weights)
            mx.synchronize()
            seconds = time.perf_counter() - start
        finally:
            if enabled: gc.enable()
    implementation = records['solver_calls'][-1]['implementation'] if records['solver_calls'] else 'sklearn'
    details = {'backend': getattr(model, '_execution_backend_', 'sklearn'),
               'n_iter': model.n_iter_.tolist(), 'implementation': implementation,
               'warnings': [{'category': w.category.__name__, 'message': str(w.message)} for w in caught], **records}
    return seconds, model, details


def independent(model, X, y, weights, reference_prediction=None, chunk=256):
    n, d = X.shape
    w = np.asarray(model.coef_[0], dtype=np.float64)
    bias = float(model.intercept_[0])
    grad = np.zeros(d, dtype=np.float64)
    g_bias = loss = 0.
    predictions = np.empty(n, dtype=bool)
    sw_sum = float(n) if weights is None else float(np.sum(weights, dtype=np.float64))
    for start in range(0, n, chunk):
        end = min(start + chunk, n)
        block = np.asarray(X[start:end], dtype=np.float64)
        z = block @ w + bias
        signs = 1.0 - 2.0 * y[start:end]
        residual = signs * expit(signs * z)
        row_loss = np.logaddexp(0., signs * z)
        if weights is not None:
            residual *= weights[start:end]
            row_loss *= weights[start:end]
        grad += block.T @ residual
        g_bias += float(np.sum(residual, dtype=np.float64))
        loss += float(np.sum(row_loss, dtype=np.float64))
        predictions[start:end] = z >= 0.
    grad = grad / sw_sum + w / (C * sw_sum)
    g_bias /= sw_sum
    result = {'objective': (loss + .5 * float(w @ w) / C) / sw_sum,
              'gradient_max': float(max(np.max(np.abs(grad)), abs(g_bias)))}
    if reference_prediction is not None:
        result['prediction_agreement'] = float(np.mean(predictions == reference_prediction))
    return result, predictions


def main():
    global C
    p = argparse.ArgumentParser()
    p.add_argument('--repeats', type=int, default=30)
    p.add_argument('--output', default='bench/fused_direct/wide_followup_results.json')
    args = p.parse_args()
    full_fit.fit_once = fit_once
    full_fit.independent = independent
    files = full_fit.hashes()
    files[str(Path(__file__).resolve())] = __import__('hashlib').sha256(Path(__file__).read_bytes()).hexdigest()
    results = []
    try:
        with threadpool_limits(limits=1):
            for C in (1.0,10.0):
                for seed in (41,83):
                    result = full_fit.run_case(f'wide_C{C:g}_seed{seed}', 20_000, 4_096, False, 0., 1e-4, args.repeats, seed)
                    result['C'] = C
                    results.append(result)
    finally:
        logistic._native_binary_objective = full_fit.ORIGINAL
    current = full_fit.hashes()
    current[str(Path(__file__).resolve())] = __import__('hashlib').sha256(Path(__file__).read_bytes()).hexdigest()
    output = {'repeats': args.repeats, 'order': 'balanced alternating, two warmups each',
              'native_extension': full_fit.loaded_native_extension(), 'source_hashes': files,
              'source_integrity_passed': files == current, 'cases': results}
    Path(args.output).write_text(json.dumps(output, indent=2, default=str)+'\n')

if __name__ == '__main__': main()
