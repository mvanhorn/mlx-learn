"""Accuracy and balanced-order timings of scratch direct scorer.

All reference calculations are NumPy float64 and outside timed sections. This
scratch harness is not part of the supported sklearn-compatible estimator API.
"""
import argparse
import gc
import json
import os
import time
from pathlib import Path

import mlx.core as mx
import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits

from fused import direct_fused
from mlxlearn._solvers.logistic import _blocked_sum, _total
from mlxlearn._solvers.native_logistic import direct_arrays


def independent(X, y, sw, theta, center, l2, chunk=256):
    n, d = X.shape
    w = np.asarray(theta[0, :d], dtype=np.float64)
    b = float(theta[0, d])
    swsum = np.sum(sw, dtype=np.float64)
    grad = np.zeros(d, dtype=np.float64)
    bias = loss = 0.0
    for a in range(0, n, chunk):
        x = np.asarray(X[a:a + chunk], dtype=np.float64)
        target = y[a:a + chunk]
        weights = sw[a:a + chunk].astype(np.float64)
        raw = x @ w + b
        sign = 1.0 - 2.0 * target
        residual = weights * sign * expit(sign * raw)
        grad += x.T @ residual
        bias += float(residual.sum(dtype=np.float64))
        loss += float(np.sum(weights * np.logaddexp(0.0, sign * raw), dtype=np.float64))
    grad = grad / swsum + l2 * w
    bias /= swsum
    return (loss / swsum + .5 * l2 * np.dot(w, w),
            grad, bias, grad + np.asarray(center, dtype=np.float64) * bias)


def case(n, d, offset, weighted, seed, repeats):
    rng = np.random.default_rng(seed)
    X = rng.normal(size=(n, d)).astype(np.float32)
    # We score a represented float32 centered design. The shift supplied here
    # is for original-coordinate gradient transformation, not float64-input QA.
    center = np.full(d, offset, dtype=np.float32)
    y = rng.integers(0, 2, size=n).astype(np.float32)
    sw = (rng.uniform(.25, 3, n).astype(np.float32) if weighted else np.ones(n, np.float32))
    theta = (rng.normal(scale=.015, size=(1, d + 1))).astype(np.float32)
    swsum = float(np.sum(sw, dtype=np.float64))
    l2 = 1 / swsum
    Xd, yd, swd, wd, denom = (mx.array(X), mx.array(y), mx.array(sw), mx.array(theta),
                              mx.array(swsum, dtype=mx.float32))
    mx.eval(Xd, yd, swd, wd, denom)
    def old():
        loss, penalty, grad = direct_arrays(wd, Xd, yd, swd, denom, l2, True)
        parts = _blocked_sum(mx, loss)
        mx.eval(parts, penalty, grad)
        return parts, penalty, grad
    def new():
        result = direct_fused(wd, Xd, yd, swd, denom, l2, True)
        mx.eval(*result)
        return result
    for _ in range(3): old(); new()
    results = {"baseline": [], "fused": []}
    for i in range(repeats):
        for name, fun in ([('baseline', old), ('fused', new)] if i % 2 == 0 else
                          [('fused', new), ('baseline', old)]):
            start = time.perf_counter()
            result = fun()
            results[name].append((time.perf_counter() - start) * 1000)
    # Re-evaluate after the timing, so host copies aren't included above.
    oldparts, oldpenalty, oldgrad = old()
    newparts, newpenalty, newgrad = new()
    oldobj = _total(oldparts, oldpenalty, swsum)
    newobj = _total(newparts, newpenalty, swsum)
    oldg = np.asarray(oldgrad, dtype=np.float64)[0]
    newg = np.asarray(newgrad, dtype=np.float64)[0]
    with threadpool_limits(limits=1):
        exact_obj, exact_weight_grad, exact_bias, exact_original = independent(X, y, sw, theta, center, l2)
    def quality(obj, g):
        original = g[:d] + center.astype(np.float64) * g[d]
        return {"objective": obj, "objective_error": obj - exact_obj,
                "centered_gradient_max_error": float(np.max(np.abs(g[:d] - exact_weight_grad))),
                "bias_gradient_error": float(g[d] - exact_bias),
                "original_gradient_max_error": float(np.max(np.abs(original - exact_original))),
                "original_gradient_max": float(max(np.max(np.abs(original)),abs(g[d])))}
    return {"shape": [n, d], "offset": offset, "weighted": weighted, "seed": seed,
            "median_ms": {k: float(np.median(v)) for k, v in results.items()},
            "samples_ms": results, "independent_objective": exact_obj,
            "independent_original_gradient_max": float(max(np.max(np.abs(exact_original)),abs(exact_bias))),
            "quality": {"baseline": quality(oldobj, oldg), "fused": quality(newobj, newg)}}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--repeats', type=int, default=20)
    p.add_argument('--output', default='bench/fused_direct/results.json')
    args = p.parse_args()
    cases = [(20_000, 1_024, 0., False, 41), (20_000, 1_024, 1000., False, 41),
             (20_000, 1_024, 1000., True, 41), (20_000, 4_096, 0., False, 41)]
    output = []
    for n, d, offset, weighted, seed in cases:
        result = case(n, d, offset, weighted, seed, args.repeats)
        output.append(result)
        print(n, d, offset, weighted, result['median_ms'], result['quality'], flush=True)
        gc.collect(); mx.clear_cache()
    Path(args.output).write_text(json.dumps({'cases': output, 'repeats': args.repeats}, indent=2)+'\n')

if __name__ == '__main__': main()
