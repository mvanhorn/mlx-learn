"""Binary shifted float32-input experiment: double-float Metal certificate.

Scratch only. CPU float64 reference is used solely for fixture creation and
verification, not by the candidate's kernels. It accepts float32 X only.
"""
import json, time
from pathlib import Path
import mlx.core as mx
import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits
from benchmarks.offset_logistic_probe import production_fixture

header=r'''
inline float2 renorm(float x,float y){float h=x+y;return float2(h,y-(h-x));}
inline float2 add2(float2 a,float2 b){float s=a.x+b.x;float v=s-a.x;float e=(a.x-(s-v))+(b.x-v)+a.y+b.y;return renorm(s,e);}
inline float2 neg2(float2 a){return -a;}
inline float2 mul2(float2 a,float2 b){float p=a.x*b.x;float e=fma(a.x,b.x,-p)+a.x*b.y+a.y*b.x;return renorm(p,e);}
inline float2 div2(float2 a,float2 b){float q=a.x/b.x;float2 r=add2(a,neg2(mul2(b,float2(q,0))));return add2(float2(q,0),float2((r.x+r.y)/b.x,0));}
inline float2 sum2(float2 a){for(uint k=16;k>0;k>>=1){float2 b=float2(simd_shuffle_down(a.x,k),simd_shuffle_down(a.y,k));a=add2(a,b);}return a;}
inline float2 exp2x(float2 z){
  float kf=rint(z.x*1.4426950408889634f); int k=int(kf);
  float2 r=add2(z,neg2(mul2(float2(kf,0),float2(0.6931471824645996f,-1.904654323148236e-9f))));
  float2 p=float2(2.08767569878681e-9f,0); // 1/12!
  p=add2(float2(2.505210838544172e-8f,0),mul2(r,p));
  p=add2(float2(2.755731998149713e-7f,0),mul2(r,p));
  p=add2(float2(2.7557319223985893e-6f,0),mul2(r,p));
  p=add2(float2(2.4801587642286904e-5f,0),mul2(r,p));
  p=add2(float2(1.9841270113829523e-4f,0),mul2(r,p));
  p=add2(float2(1.3888889225199819e-3f,0),mul2(r,p));
  p=add2(float2(8.333333767950535e-3f,0),mul2(r,p));
  p=add2(float2(4.16666679084301e-2f,0),mul2(r,p));
  p=add2(float2(1.666666716337204e-1f,0),mul2(r,p));
  p=add2(float2(0.5f,0),mul2(r,p));
  p=add2(float2(1.0f,0),mul2(r,p));
  p=add2(float2(1.0f,0),mul2(r,p));
  return float2(ldexp(p.x,k),ldexp(p.y,k));
}
'''
forward=mx.fast.metal_kernel(name='gpu_cert_forward_2f',header=header,
 input_names=['X','coef','bias','y','sw'],output_names=['resid_hi','resid_lo','loss'],source=r'''
uint t=thread_position_in_threadgroup.x,lane=t%32,sg=t/32;
uint row=threadgroup_position_in_grid.x*4+sg;
float2 dot=float2(0);
if(row<N){for(uint j=lane;j<D;j+=32)dot=add2(dot,mul2(float2(X[ulong(row)*D+j],0),float2(coef[j],0)));}
dot=sum2(dot);
if(lane==0 && row<N){
 dot=add2(dot,float2(bias[0],bias[1]));float sign=1.0f-2.0f*y[row];float2 u=sign*dot;
 float2 z=(u.x>=0 ? neg2(u):u); float2 e=exp2x(z);
 float2 prob=div2(u.x>=0 ? float2(1,0):e,add2(float2(1,0),e));
 float2 r=mul2(sign*prob,float2(sw[row],0));resid_hi[row]=r.x;resid_lo[row]=r.y;
 loss[row]=sw[row]*(max(u.x,0.0f)+log1p(exp(-abs(u.x))));
}
''')
back=mx.fast.metal_kernel(name='gpu_cert_back_2f',header=header,
 input_names=['X','coef','resid_hi','resid_lo','l2'],output_names=['grad_hi','grad_lo'],source=r'''
uint lane=thread_position_in_threadgroup.x;uint col=threadgroup_position_in_grid.x;
float2 g=float2(0);
for(uint row=lane;row<N;row+=32){float x=col<D?X[ulong(row)*D+col]:1.0f;g=add2(g,mul2(float2(x,0),float2(resid_hi[row],resid_lo[row])));}
g=sum2(g);
if(lane==0){g=div2(g,float2(float(N),0));if(col<D)g=add2(g,mul2(float2(l2,0),float2(coef[col],0)));grad_hi[col]=g.x;grad_lo[col]=g.y;}
''')

def gpu_score(X,y,coef,bias,weights):
 n,d=X.shape
 hi=float(np.float32(bias));lo=float(np.float32(bias-hi))
 xm=mx.array(X);ym=mx.array(y,dtype=mx.float32);cm=mx.array(coef,dtype=mx.float32);bm=mx.array([hi,lo]);sm=mx.array(weights,dtype=mx.float32);l2=mx.array(1.0/n)
 mx.eval(xm,ym,cm,bm,sm,l2)
 def run():
  a,b,loss=forward(inputs=[xm,cm,bm,ym,sm],template=[('N',n),('D',d)],grid=((n+3)//4*128,1,1),threadgroup=(128,1,1),output_shapes=[(n,)]*3,output_dtypes=[mx.float32]*3)
  gh,gl=back(inputs=[xm,cm,a,b,l2],template=[('N',n),('D',d)],grid=((d+1)*32,1,1),threadgroup=(32,1,1),output_shapes=[(d+1,)]*2,output_dtypes=[mx.float32]*2)
  mx.eval(gh,gl,loss)
  return gh,gl,loss
 times=[]
 for i in range(9):
  t=time.perf_counter();gh,gl,loss=run();dt=time.perf_counter()-t
  if i>=3:times.append(dt)
 gpu_grad=np.asarray(gh).astype(np.float64)+np.asarray(gl).astype(np.float64)
 objective=float(np.mean(np.asarray(loss),dtype=np.float64)+0.5/n*np.dot(coef.astype(np.float64),coef.astype(np.float64)))
 return gpu_grad,objective,times


def main():
 data=json.load(open('benchmarks/results/certified-offset-final-2026-10-27.json'))
 record=next(x for x in data['cases'] if x['name']=='production')['quality']['current_default']
 coef=np.asarray(record['coef'],dtype=np.float32);bias=record['intercept']; X,y=production_fixture(); n=len(y)
 out=[]
 for weighted in [False,True]:
  weights=np.random.default_rng(11).uniform(.25,2,n).astype(np.float32) if weighted else np.ones(n,dtype=np.float32)
  # back kernel normalizes by N; scale weights to mean 1, maintaining weighted objective.
  weights=weights*(n/np.sum(weights,dtype=np.float64))
  with threadpool_limits(1):
   start=time.perf_counter();Xd=X.astype(np.float64);raw=Xd@coef.astype(np.float64)+bias; sign=1-2*y; u=sign*raw
   prob=expit(u);res=sign*prob*weights.astype(np.float64)
   ref=np.r_[Xd.T@res/n+coef.astype(np.float64)/n,np.sum(res)/n];ref_obj=float(np.mean(np.logaddexp(0,u)*weights,dtype=np.float64)+.5/n*np.dot(coef.astype(np.float64),coef.astype(np.float64)));cpu_time=time.perf_counter()-start
  gpu,obj,times=gpu_score(X,y,coef,bias,weights)
  out.append(dict(weighted=weighted, gpu_median_s=float(np.median(times)),gpu_samples_s=times,cpu_score_s=cpu_time,ref_grad_max=float(np.max(np.abs(ref))),gpu_grad_max=float(np.max(np.abs(gpu))),grad_error_max=float(np.max(np.abs(ref-gpu))),objective_ref=ref_obj,objective_gpu=obj,objective_error=obj-ref_obj))
  print(out[-1],flush=True)
 Path('bench/gpu_cert/results.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
