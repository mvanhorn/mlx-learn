"""IEEE-754 float64 input decoded in Metal as compensated float32 pairs."""
import time,json
from pathlib import Path
import mlx.core as mx
import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits
from prototype import header, forward, back

# This normal-finite decoder is a research prototype. Out-of-range float32
# exponents and subnormal/nonfinite IEEE values need explicit rejection before
# a production implementation could claim to handle all NumPy float64 inputs.
decode=r'''
inline float2 decode64(device const uint* X, ulong index){
 uint lo=X[2*index], h=X[2*index+1];int exponent=int((h>>20)&2047)-1023;
 float sign=(h>>31)?-1.0f:1.0f;
 float a=ldexp(sign*(1.0f+float(h&1048575)*0x1p-20f),exponent);
 float b=ldexp(sign*float(lo>>16)*0x1p-36f,exponent);
 float c=ldexp(sign*float(lo&65535)*0x1p-52f,exponent);
 return add2(add2(float2(a,0),float2(b,0)),float2(c,0));
}
'''
# Extract standard library-generated sources rather than copying kernel logic.
import inspect,re
src=inspect.getsource(__import__('prototype'))
fwdsrc=re.search(r"output_names=\['resid_hi','resid_lo','loss'\],source=r'''(.*?)'''\)",src,re.S).group(1)
bwdsrc=re.search(r"output_names=\['grad_hi','grad_lo'\],source=r'''(.*?)'''\)",src,re.S).group(1)
fwdsrc=fwdsrc.replace('float2(X[ulong(row)*D+j],0)','decode64(X,ulong(row)*D+j)')
bwdsrc=bwdsrc.replace('float x=col<D?X[ulong(row)*D+col]:1.0f;g=add2(g,mul2(float2(x,0),float2(resid_hi[row],resid_lo[row])));','float2 x=col<D?decode64(X,ulong(row)*D+col):float2(1.0f,0);g=add2(g,mul2(x,float2(resid_hi[row],resid_lo[row])));')
fwd=mx.fast.metal_kernel(name='gpu_cert_forward_64bits',header=header+decode,input_names=['X','coef','bias','y','sw'],output_names=['resid_hi','resid_lo','loss'],source=fwdsrc)
bwd=mx.fast.metal_kernel(name='gpu_cert_back_64bits',header=header+decode,input_names=['X','coef','resid_hi','resid_lo','l2'],output_names=['grad_hi','grad_lo'],source=bwdsrc)

def gpu_score(X,y,coef,bias):
 n,d=X.shape; hi=np.float32(bias);lo=np.float32(bias-float(hi))
 # view() is a zero-arithmetic transport of the original IEEE bytes. A native
 # C++ buffer bridge can replace this NumPy view for true no-NumPy input.
 xm=mx.array(X.view(np.uint32).reshape(n,d,2));ym=mx.array(y,dtype=mx.float32);cm=mx.array(coef,dtype=mx.float32);bm=mx.array([float(hi),float(lo)]);sm=mx.ones((n,));l2=mx.array(1.0/n);mx.eval(xm,ym,cm,bm,sm,l2)
 def run():
  a,b,loss=fwd(inputs=[xm,cm,bm,ym,sm],template=[('N',n),('D',d)],grid=((n+3)//4*128,1,1),threadgroup=(128,1,1),output_shapes=[(n,)]*3,output_dtypes=[mx.float32]*3)
  gh,gl=bwd(inputs=[xm,cm,a,b,l2],template=[('N',n),('D',d)],grid=((d+1)*32,1,1),threadgroup=(32,1,1),output_shapes=[(d+1,)]*2,output_dtypes=[mx.float32]*2)
  mx.eval(gh,gl,loss);return gh,gl
 times=[]
 for i in range(9):
  start=time.perf_counter();a,b=run();t=time.perf_counter()-start
  if i>=3:times.append(t)
 return np.asarray(a).astype(np.float64)+np.asarray(b).astype(np.float64),times

def main():
 n,d=20000,1024;rng=np.random.default_rng(492)
 X=np.ascontiguousarray(10000.0+rng.normal(scale=.0001,size=(n,d)))
 y=np.arange(n)%2;coef=np.zeros(d,dtype=np.float32);coef[0]=700.0;bias=-7000000.0
 with threadpool_limits(1):
  raw=X@coef.astype(np.float64)+bias;res=(expit(raw)-y);ref=np.r_[X.T@res/n+coef.astype(np.float64)/n,np.mean(res)]
  X32=X.astype(np.float32).astype(np.float64);raw32=X32@coef.astype(np.float64)+bias;res32=expit(raw32)-y;downcast=np.r_[X32.T@res32/n+coef.astype(np.float64)/n,np.mean(res32)]
 gpu,times=gpu_score(X,y,coef,bias)
 out=dict(n=n,d=d,offset=10000,scale=.0001,gpu_median_s=float(np.median(times)),gpu_samples_s=times,ref_grad_max=float(np.max(abs(ref))),gpu_grad_max=float(np.max(abs(gpu))),gpu_grad_error_max=float(np.max(abs(ref-gpu))),downcast_grad_max=float(np.max(abs(downcast))),downcast_grad_error_max=float(np.max(abs(ref-downcast))))
 print(out,flush=True);Path('bench/gpu_cert/results64.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
