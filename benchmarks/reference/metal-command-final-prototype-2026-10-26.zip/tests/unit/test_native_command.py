"""Contracts for the optional native Metal command loop and its caller."""

from __future__ import annotations

import ctypes
import gc
import subprocess
import sys
import weakref
from types import SimpleNamespace

import mlx.core as mx
import numpy as np
import pytest
from scipy.special import expit

from mlxlearn._common.config import tuning_context
from mlxlearn._common.device import gpu_available, use_device
from mlxlearn._solvers import native_command, native_logistic
from mlxlearn._solvers.lbfgs import LBFGSConfig, LBFGSState


@pytest.fixture
def cpu():
    # Contract tests use a fake extension and must not contend with GPU work.
    with use_device("cpu"):
        yield


def _inputs(n=5, d=513):
    X = mx.ones((n, d), dtype=mx.float32)
    y = mx.array(np.arange(n) % 2, dtype=mx.float32)
    parts = mx.zeros((2, (n + 255) // 256, d + 1), dtype=mx.float32)
    return X, y, parts


def _objective(value=0.5, grad=0.0):
    def direct(theta):
        return value, mx.full(theta.shape, grad, dtype=mx.float32)

    return direct


def _fake_loop(monkeypatch, *, status=1, grad=0.0, callback=None):
    calls = []

    def run(source, capsules, n, d, p, history, blocks, groups, max_iter, *args):
        calls.append((source, capsules, n, d, p, history, blocks, groups, max_iter, args))
        if callback is not None:
            callback(capsules)
        return np.zeros(p, dtype=np.float32).tobytes(), 2, status, 16

    monkeypatch.setattr(native_command, "_metal_loop", SimpleNamespace(run=run))
    monkeypatch.setattr(native_command, "_source", lambda *args: "fake Metal source")
    return calls


def _run(X, y, parts, *, config=None, fun=None, weights=None, fit_intercept=True):
    return native_command.run_native_loop(
        X,
        y,
        weights,
        float(X.shape[0]),
        0.1,
        fit_intercept,
        LBFGSConfig() if config is None else config,
        _objective() if fun is None else fun,
        initial_parts=parts,
    )


def test_missing_extension_declines_without_preparing_inputs(cpu, monkeypatch):
    X, y, parts = _inputs()
    monkeypatch.setattr(native_command, "_metal_loop", None)

    def unexpected(*args, **kwargs):
        pytest.fail("unavailable extension must not prepare or execute the native loop")

    monkeypatch.setattr(native_command.mx, "eval", unexpected)
    assert _run(X, y, parts) is None


@pytest.mark.parametrize(
    "failure",
    [
        'ImportError("broken extension load")',
        'ModuleNotFoundError("missing dependency", name="missing_dependency")',
    ],
)
def test_broken_extension_import_is_not_treated_as_absent(failure):
    # A fresh interpreter lets a finder intercept only the optional extension
    # without reloading or corrupting the imported module in this test process.
    script = f"""
import importlib.abc, importlib.machinery, sys
class Fault(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def find_spec(self, fullname, path, target=None):
        if fullname == 'mlxlearn._solvers._metal_loop':
            return importlib.machinery.ModuleSpec(fullname, self)
    def create_module(self, spec):
        return None
    def exec_module(self, module):
        raise {failure}
sys.meta_path.insert(0, Fault())
try:
    import mlxlearn._solvers.native_command
except ImportError as error:
    assert str(error) in ('broken extension load', 'missing dependency')
else:
    raise AssertionError('broken extension was silently treated as unavailable')
"""
    result = subprocess.run([sys.executable, "-c", script], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr


@pytest.mark.parametrize(
    "d,intercept,history,line_search",
    [(511, True, 10, 32), (4097, True, 10, 32), (513, False, 10, 32),
     (513, True, 3, 32), (513, True, 10, 7)],
)
def test_unsupported_solver_contract_declines(cpu, monkeypatch, d, intercept, history, line_search):
    X, y, parts = _inputs(d=d)
    calls = _fake_loop(monkeypatch)
    config = LBFGSConfig(history_size=history, max_line_search=line_search)
    assert _run(X, y, parts, config=config, fit_intercept=intercept) is None
    assert not calls


def test_missing_or_invalid_initial_statistics(cpu, monkeypatch):
    X, y, parts = _inputs()
    calls = _fake_loop(monkeypatch)
    assert _run(X, y, None) is None
    with pytest.raises(ValueError, match="initial_parts"):
        _run(X, y, parts[:, :, :-1])
    assert not calls


def test_success_requires_direct_objective_and_gradient(cpu, monkeypatch):
    X, y, parts = _inputs()
    calls = _fake_loop(monkeypatch)
    checked = []

    def objective(theta):
        checked.append(np.asarray(theta).copy())
        return 0.25, mx.full(theta.shape, 1e-6, dtype=mx.float32)

    state = _run(X, y, parts, fun=objective)
    assert isinstance(state, LBFGSState)
    assert state.converged and state.stop_reason == "gtol"
    assert state.n_iter == 2 and state.n_fev == 17
    assert state.objective == 0.25 and state.grad_max_abs == pytest.approx(1e-6)
    np.testing.assert_array_equal(checked[-1], np.asarray(state.x))
    assert len(calls) == 1


@pytest.mark.parametrize("status", [0, 2, 3])
def test_unsupported_native_status_uses_existing_solver(cpu, monkeypatch, status):
    X, y, parts = _inputs()
    _fake_loop(monkeypatch, status=status)

    def unexpected(theta):
        pytest.fail("unsuccessful native state must not be presented as a result")

    assert _run(X, y, parts, fun=unexpected) is None


@pytest.mark.parametrize("value,grad", [(0.2, 1e-2), (np.nan, 0), (0.2, np.nan)])
def test_direct_certification_rejects_false_convergence(cpu, monkeypatch, value, grad):
    X, y, parts = _inputs()
    _fake_loop(monkeypatch)
    assert _run(X, y, parts, fun=_objective(value, grad)) is None


def test_extension_and_direct_objective_exceptions_propagate(cpu, monkeypatch):
    X, y, parts = _inputs()
    error = RuntimeError("native command failed")

    def broken(*args):
        raise error

    monkeypatch.setattr(native_command, "_metal_loop", SimpleNamespace(run=broken))
    monkeypatch.setattr(native_command, "_source", lambda *args: "source")
    with pytest.raises(RuntimeError, match="native command failed") as caught:
        _run(X, y, parts)
    assert caught.value is error
    _fake_loop(monkeypatch)

    def broken_objective(theta):
        raise RuntimeError("direct objective failed")

    with pytest.raises(RuntimeError, match="direct objective failed"):
        _run(X, y, parts, fun=broken_objective)


def test_exported_capsules_and_owners_live_through_synchronous_native_call(cpu, monkeypatch):
    X, y, parts = _inputs()
    weights = mx.ones(X.shape[0], dtype=mx.float32)
    refs = [weakref.ref(array) for array in (X, y, weights)]
    real_eval = mx.eval
    calls = []

    def observed_eval(*args):
        calls.append("eval")
        return real_eval(*args)

    is_valid = ctypes.pythonapi.PyCapsule_IsValid
    is_valid.argtypes = [ctypes.py_object, ctypes.c_char_p]
    is_valid.restype = ctypes.c_int

    def inspect(capsules):
        # Producer evaluation must precede submission to the external queue.
        assert calls
        gc.collect()
        assert all(ref() is not None for ref in refs)
        assert len(capsules) == 6
        assert all(is_valid(capsule, b"dltensor") for capsule in capsules)

    monkeypatch.setattr(mx, "eval", observed_eval)
    _fake_loop(monkeypatch, callback=inspect)
    assert _run(X, y, parts, weights=weights).converged


def test_minimize_returns_native_success_and_declines_to_existing_solver(cpu, monkeypatch):
    X, y, parts = _inputs()
    expected = LBFGSState(mx.zeros((1, X.shape[1] + 1)), 0.0, 0.0, 0, 1, True, "gtol")
    monkeypatch.setattr(native_command, "run_native_loop", lambda *a, **kw: expected)
    result = native_logistic.minimize_binary(
        X, y, None, float(X.shape[0]), 0.1, True, LBFGSConfig(), _objective(),
        initial_parts=parts,
    )
    assert result is expected

    monkeypatch.setattr(native_command, "run_native_loop", lambda *a, **kw: None)

    def fallback_reached(*args):
        raise RuntimeError("existing solver reached")

    monkeypatch.setattr(native_logistic, "initial_from_parts", fallback_reached)
    with pytest.raises(RuntimeError, match="existing solver reached"):
        native_logistic.minimize_binary(
            X, y, None, float(X.shape[0]), 0.1, True, LBFGSConfig(), _objective(),
            initial_parts=parts,
        )


@pytest.mark.gpu
@pytest.mark.parametrize("width", [519, 1025, 2049])
@pytest.mark.parametrize("weighted", [False, True])
def test_real_loop_fit_tails_ownership_and_independent_gradient(monkeypatch, weighted, width):
    if not gpu_available():
        pytest.skip("requires an MLX GPU")
    if native_command._metal_loop is None:
        pytest.skip("optional native command extension is not built")
    from mlxlearn.linear_model import LogisticRegression
    from mlxlearn.linear_model import _logistic as estimator

    # Exercise prepared input and real command execution with tail blocks.
    monkeypatch.setattr(estimator, "_CENTERED_INPUT_MIN_ELEMENTS", 1)
    seen = []
    original = native_command.run_native_loop

    def observe(*args, **kwargs):
        result = original(*args, **kwargs)
        seen.append(result)
        return result

    monkeypatch.setattr(native_command, "run_native_loop", observe)
    rng = np.random.default_rng(139)
    X = rng.normal(scale=0.1, size=(259, width)).astype(np.float32) + np.float32(0.25)
    y = rng.integers(0, 2, len(X))
    weights = np.linspace(0, 2, len(X), dtype=np.float32) if weighted else None
    before = X.copy()
    X.flags.writeable = False
    with tuning_context(force_backend="mlx"):
        model = LogisticRegression(C=0.1, tol=1e-5, max_iter=200).fit(X, y, sample_weight=weights)
    assert seen and seen[-1] is not None and seen[-1].converged
    assert model.execution_backend_ == "mlx"
    np.testing.assert_array_equal(X, before)
    raw = X.astype(np.float64) @ model.coef_[0] + model.intercept_[0]
    residual = expit(raw) - y
    denominator = len(X)
    if weighted:
        residual *= weights
        denominator = weights.sum(dtype=np.float64)
    grad = residual @ X / denominator + model.coef_[0] / (0.1 * denominator)
    grad = np.append(grad, residual.sum() / denominator)
    assert np.max(np.abs(grad)) <= 1.05e-5
    prediction = model.predict_proba(before[:10])
    X.flags.writeable = True
    X.fill(0)
    np.testing.assert_array_equal(model.predict_proba(before[:10]), prediction)
