"""Warm, repeated scratch continuation outcomes; not a production benchmark."""
from __future__ import annotations
import hashlib
import json
import statistics
import sys
import traceback
from pathlib import Path

import continuation

base = Path(__file__).resolve().parent
settings = [
    ('ill4096', 41, 200, 96, False, 1.0),
    ('ill4096', 83, 200, 96, False, 1.0),
    ('ill4096', 2027, 200, 96, False, 1.0),
    ('ill4096', 41, 200, 96, False, 0.1),
    ('ill4096', 41, 200, 96, False, 10.0),
    ('ill4096', 41, 80, 96, False, 1.0),
    ('ill4096', 83, 80, 96, False, 1.0),
    ('rank1024', 41, 200, 32, True, None),
    ('weightedill1024', 41, 200, 64, True, None),
    ('shifted1024', 41, 200, 32, True, None),
]
results = {'method': 'one warmup and three measured scratch full-continuation fits per case; independently scored original represented inputs',
           'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'cases': []}
for kind, seed, initial_budget, steps, force, C in settings:
    records = []
    output = base / f'panel-{kind}-{seed}-{initial_budget}-{C}.json'
    for repetition in range(4):
        sys.argv = ['continuation.py', '--case', kind, '--seed', str(seed), '--steps', str(steps),
                    '--initial-budget', str(initial_budget), '--output', str(output)]
        if force:
            sys.argv += ['--force-managed']
        if C is not None:
            sys.argv += ['--C', str(C)]
        try:
            continuation.run()
            record = json.loads(output.read_text())
            record['repetition'] = repetition
        except Exception as exc:
            record = {'repetition': repetition, 'error': repr(exc), 'traceback': traceback.format_exc(),
                      'converged': False}
        if repetition:
            records.append(record)
    valid = [r for r in records if 'wall_total_excluding_independent_scoring_ms' in r]
    row = {'case': kind, 'seed': seed, 'initial_budget': initial_budget, 'cg_steps': steps,
           'force_managed': force, 'C': C, 'samples': records,
           'median_full_ms': statistics.median(r['wall_total_excluding_independent_scoring_ms'] for r in valid) if valid else None,
           'median_fit_ms': statistics.median(r['fit_ms'] for r in valid) if valid else None,
           'all_converged': all(r.get('converged', False) for r in records),
           'source_integrity': all(r.get('integrity', False) for r in records)}
    results['cases'].append(row)
    print('PANEL',kind,seed,'C',C,'initial',initial_budget,'cg',steps,'median',row['median_full_ms'],
          'fit',row['median_fit_ms'],'converged',row['all_converged'],flush=True)
    (base/'continuation-panel.json').write_text(json.dumps(results,indent=2)+'\n')
