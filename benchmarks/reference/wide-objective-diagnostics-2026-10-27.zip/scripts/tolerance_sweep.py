"""Probe tighter internal gtol against sklearn's unchanged public tolerance.

For each candidate, only the GPU solver's config tol is changed, not sklearn's
or the estimator's parameter. Each fit is fresh; scoring is out of the timer.
Run on an exclusive GPU lane. Raw results are diagnostic, not a release gate.
"""
from __future__ import annotations

import contextlib
import json
import statistics
from dataclasses import replace
from pathlib import Path

import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits

from benchmarks.logistic_gpu import Case, make_data, quality
from benchmarks.logistic_wide import fit_once, frozen_reference
from mlxlearn._solvers import native_logistic


@contextlib.contextmanager
def internal_tol(tol):
    old = native_logistic.minimize_binary

    def wrapped(*args, **kwargs):
        vals = list(args)
        vals[6] = replace(vals[6], tol=tol)
        return old(*vals, **kwargs)

    native_logistic.minimize_binary = wrapped
    try:
        yield
    finally:
        native_logistic.minimize_binary = old


def gradient_norms(model, X, y):
    x64 = np.asarray(X, dtype=np.float64)
    w = model.coef_[0]
    raw = x64 @ w + model.intercept_[0]
    residual = expit(raw) - y
    g = residual @ x64 / len(y) + w / len(y)
    g = np.r_[g, residual.mean()]
    return {"l2": float(np.linalg.norm(g)), "max": float(np.abs(g).max()),
            "sq": float(g @ g)}


def run():
    out = []
    tol = 1e-4
    factors = (1.0, 0.8, 0.6, 0.5, 0.3, 0.2)
    archive = Path('benchmarks/reference/overhead-logistic-2026-10-26.zip')
    with threadpool_limits(limits=1), frozen_reference(archive=archive) as reference:
        for d in (4096, 1024):
            case = Case(f"wide_20k_{d}", 20_000, d)
            X, y, weight = make_data(case, 41, dtype='float32')
            _, ref, ref_meta = fit_once('sklearn', X, y, weight, reference=reference,
                                        max_iter=200, tol=tol)
            print('case', d, 'sklearn', ref_meta['n_iter'], flush=True)
            for factor in factors:
                vals, meta, model = [], [], None
                # Warm once per factor; caches are per-shape rather than per tol.
                with internal_tol(tol*factor):
                    fit_once('optimized_gpu', X, y, weight, reference=reference,
                             max_iter=200, tol=tol)
                    for _ in range(3):
                        elapsed, model, details = fit_once('optimized_gpu', X, y, weight,
                                                          reference=reference, max_iter=200, tol=tol)
                        vals.append(elapsed)
                        meta.append(details)
                score = quality(model, ref, X, y, weight)
                norms = gradient_norms(model, X, y)
                row = {'width': d, 'factor': factor, 'seconds': vals,
                       'median_ms': 1000*statistics.median(vals), 'metadata': meta,
                       'quality': score, 'gradient': norms}
                out.append(row)
                print(d, factor, row['median_ms'], meta[-1]['n_iter'], score['objective_relative_gap_to_sklearn'], norms, flush=True)
                Path('bench/objective_accuracy_sweep/results.json').write_text(json.dumps(out, indent=2)+'\n')


if __name__ == '__main__':
    run()
