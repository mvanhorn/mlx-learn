"""Record the complete objective path with sklearn's tolerance unchanged.

Diagnostic only: deliberately truncated budgets warn and are not interpreted as
converged timings. The reference package is immutable. All independent scoring
occurs after every fitting measurement.
"""
from __future__ import annotations

import json
from dataclasses import replace
from pathlib import Path

import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits
from benchmarks.logistic_gpu import Case, make_data
from benchmarks.logistic_wide import fit_once, frozen_reference


def run():
    case=Case('wide_20k_4096',20_000,4096)
    X,y,weight=make_data(case,41,dtype='float32')
    archive=Path('benchmarks/reference/overhead-logistic-2026-10-26.zip')
    with threadpool_limits(limits=1), frozen_reference(archive=archive) as reference:
        _,sk,skmeta=fit_once('sklearn',X,y,weight,reference=reference,max_iter=200,tol=1e-4)
        old=reference.native.minimize_binary
        def enforce(*args,**kwargs):
            a=list(args);a[6]=replace(a[6],tol=1e-8);return old(*a,**kwargs)
        reference.native.minimize_binary=enforce
        recorded=[]
        for budget in range(11,20):
            elapsed,model,meta=fit_once('previous_native',X,y,weight,reference=reference,max_iter=budget,tol=1e-4)
            recorded.append((budget,elapsed,model,meta))
            print('fit',budget,'iters',meta['n_iter'],flush=True)
        X64=np.asarray(X,dtype=np.float64)
        def independent(model):
            w=model.coef_[0];z=X64@w+model.intercept_[0]
            residual=expit(z)-y;g=residual@X64/len(y)+w/len(y);g=np.r_[g,residual.mean()]
            objective=float(np.mean(np.logaddexp(0,z)-y*z)+np.dot(w,w)/(2*len(y)))
            return {'objective':objective,'max_grad':float(np.abs(g).max()),'l2_grad':float(np.linalg.norm(g)),'grad_sq':float(g@g)}
        ref=independent(sk);output=[]
        for budget,elapsed,model,meta in recorded:
            score=independent(model); score['gap_to_sklearn']=(score['objective']-ref['objective'])/abs(ref['objective'])
            output.append({'budget':budget,'seconds_diagnostic':elapsed,'metadata':meta,'quality':score})
            print(budget,score,flush=True)
        Path('bench/objective_accuracy_sweep/iteration-results.json').write_text(json.dumps({'sklearn':ref,'sklearn_metadata':skmeta,'results':output},indent=2)+'\n')

if __name__=='__main__':run()
