"""Diagnostic: trace objective, norm and L-BFGS slope by accepted iteration.

The source is the archived frozen solver. Independent float64 scoring is outside
all fits. Truncated budgets warn intentionally; no timings are performance claims.
"""
from __future__ import annotations
import json
from dataclasses import replace
from pathlib import Path
import mlx.core as mx
import numpy as np
from scipy.special import expit
from threadpoolctl import threadpool_limits
from benchmarks.logistic_gpu import Case, make_data
from benchmarks.logistic_wide import fit_once, frozen_reference


def run():
    data=[]
    with threadpool_limits(limits=1), frozen_reference(archive=Path('benchmarks/reference/overhead-logistic-2026-10-26.zip')) as ref:
        old_min=ref.native.minimize_binary;old_step=ref.native.step
        for d,weighted in [(1024,False),(1024,True),(4096,False)]:
            X,y,sw=make_data(Case('case',20_000,d,weighted=weighted),41,dtype='float32')
            traces=[]
            def override(*args,**kwargs):
                a=list(args);a[6]=replace(a[6],tol=1e-8);return old_min(*a,**kwargs)
            def capture(*args):
                result=old_step(*args);traces.append((args,result));return result
            ref.native.minimize_binary=override;ref.native.step=capture
            _,model,meta=fit_once('previous_native',X,y,sw,reference=ref,max_iter=16,tol=1e-4)
            ref.native.minimize_binary=old_min;ref.native.step=old_step
            Xm=np.asarray(traces[0][0][0],dtype=np.float64);weights=np.ones(len(y)) if sw is None else np.asarray(sw,dtype=np.float64)
            denom=float(weights.sum());reg=1.0/denom;rows=[];seen=set()
            for args,state in traces:
                mx.eval(*state)
                meta_np=np.asarray(state[7]);n_iter=int(meta_np[0]);status=int(meta_np[1])
                if n_iter in seen or status!=0:continue
                seen.add(n_iter)
                w,g,oldw,oldg,hs,hy,hc,m,raw=state
                p=w.size;memory=hs.shape[0]
                direction=ref.native._direction(inputs=[w,g,oldw,oldg,hs,hy,hc,m,args[3],mx.array(0.0),args[6],args[8],args[10]],template=[('P',p),('M',memory)],grid=(32,1,1),threadgroup=(32,1,1),output_shapes=[(p,),(memory,p),(memory,p),(memory,2),(10,)],output_dtypes=[mx.float32]*5)
                mx.eval(direction)
                slope=float(np.asarray(direction[-1])[5]);theta=np.asarray(w,dtype=np.float64)
                z=Xm@theta[:d]+theta[d];resid=(expit(z)-y)*weights
                f=float(np.sum(weights*(np.logaddexp(0,z)-y*z))/denom+0.5*reg*(theta[:d]@theta[:d]))
                grad=resid@Xm/denom+reg*theta[:d];grad=np.r_[grad,resid.sum()/denom]
                rows.append({'iteration':n_iter,'objective':f,'gradient_max':float(np.max(np.abs(grad))),'gradient_l2':float(np.linalg.norm(grad)),'slope':slope,'half_newton_proxy_relative':-.5*slope/abs(f)})
            for i,r in enumerate(rows):
                r['previous_relative_decrease']=None if i==0 else (rows[i-1]['objective']-r['objective'])/abs(r['objective'])
            data.append({'width':d,'weighted':weighted,'rows':rows,'fit_metadata':meta})
            print('case',d,weighted,flush=True)
            for r in rows:
                if 5<=r['iteration']<=16:print(r,flush=True)
            Path('bench/objective_accuracy_sweep/step-progress-results.json').write_text(json.dumps(data,indent=2)+'\n')

if __name__=='__main__':run()
