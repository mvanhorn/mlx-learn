# Wide objective diagnostic scripts

Run from a checkout with the frozen reference and existing benchmarks:

```bash
PYTHONPATH=. python3 PATH/step_progress.py
PYTHONPATH=. python3 PATH/iteration_sweep.py
PYTHONPATH=. python3 PATH/tolerance_sweep.py
PYTHONPATH=. python3 PATH/fine_sweep.py
```

Replace PATH with the directory where these source-only scripts were extracted.
The step/iteration scripts load `benchmarks/reference/overhead-logistic-2026-10-26.zip` as a complete immutable previous package; tolerance scripts used the live package and make no source-audit guarantee. Each script writes to `bench/objective_accuracy_sweep/`. The tolerance runs alter only GPU internal tolerance, leaving sklearn's public tolerance at 1e-4. Budget-truncated iteration diagnostics warn by design. The `step_progress` scores on the centered float32 design promoted to float64; `iteration_sweep` scores the original design in float64. No in-run binary/source hash audit was captured, and these short probes are not benchmark claims.
