# Large-case fixed versus adaptive schedule audit

The benchmark compares the frozen previous solver, the current native command
loop using fixed chunks of eight, the same loop using adaptive 8-then-1-then-4
chunks, and sklearn. The only source difference between native modes is the
scratch-only `_set_ab_fixed` selector in `_metal_loop.mm`; it is set outside each
fit timer. The scratch source is copied from the production implementation, then
the selector and one scheduling expression are added. Every fit is fresh and
synchronized. Each native fit is independently checked against float64 gradient,
objective and prediction limits; identical fitted parameter fingerprints are
scored once and the result associated with each repeat.

**Do not use the timing differences to claim a speedup or regression.** The 32
orders alternate four rotations and four reversed rotations, balancing position
but not immediate predecessor: adaptive follows sklearn in half of the rounds,
while fixed never does. Previous investigations show this can affect timing. An
attempted 48-repeat all-permutations follow-up was stopped after inspection showed
that no timing comparison was needed to answer the scheduling question.

All native fits on 60,000 x 1,024 and 40,000 x 2,048 used exactly seven accepted
iterations for float32 and float64. Both policies therefore submit the same initial
8-step command buffer and never execute their different later-chunk branches.
Within each shape, their coefficient/intercept SHA-256 fingerprints are identical
across both input dtypes and all repeats. Thus choosing fixed-eight solely for
unweighted fits cannot explain or fix the observed larger-case regressions on
these datasets. This is a control-flow conclusion, not a timing claim.

Raw, unfiltered case records and exact orders:
`benchmarks/results/native-loop-large-chunk-ab-2026-10-26.json`.
The manifest records post-run source and binary hashes; an in-run source hash
was not collected. No compiled artifacts are included in this source archive.

To reproduce on Apple Silicon with Xcode and the listed dependencies, extract the
full prior prototype package and frozen baseline, then overlay these three source
files and the scratch benchmark before building:

```bash
experiment_dir=$(mktemp -d)
unzip -q benchmarks/reference/metal-command-final-prototype-2026-10-26.zip -d "$experiment_dir"
unzip -q benchmarks/reference/native-loop-large-chunk-ab-2026-10-26.zip -d "$experiment_dir"
cd "$experiment_dir"
cp sources/_metal_loop.mm src/mlxlearn/_solvers/_metal_loop.mm
cp sources/native_command.py src/mlxlearn/_solvers/native_command.py
cp sources/native_logistic.py src/mlxlearn/_solvers/native_logistic.py
cp sources/setup.py setup.py
cp sources/logistic_wide.py benchmarks/logistic_wide.py
python3 setup.py build_ext --inplace --force
PYTHONPATH="$PWD:$PWD/src" python3 scripts/run_chunk_ab.py
```

This archive contains an optional 48-round all-permutations runner for a properly
predecessor-balanced future timing study; its stopped incomplete run is not used.
