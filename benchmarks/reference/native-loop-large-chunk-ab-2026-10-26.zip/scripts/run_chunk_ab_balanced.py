import hashlib
import itertools
import random
import json
import statistics
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits

from benchmarks.logistic_gpu import Case, make_data, quality
from benchmarks.logistic_wide import fit_once, frozen_reference
from mlxlearn._solvers import native_command

NAMES = ('previous_native', 'fixed', 'adaptive', 'sklearn')
REPEATS = 48
WARMUP = 3

ALL_ORDERS = list(itertools.permutations(NAMES)) * 2
random.Random(7301).shuffle(ALL_ORDERS)
def order(i):
    return ALL_ORDERS[i % len(ALL_ORDERS)]

def fit(name, X, y, ref):
    if name in ('fixed', 'adaptive'):
        native_command._metal_loop._set_ab_fixed(name == 'fixed')
        mode = 'optimized_gpu'
    else:
        mode = name
    return fit_once(mode, X, y, None, reference=ref, max_iter=200, tol=1e-4)

def digest(model):
    return hashlib.sha256(model.coef_.tobytes()+model.intercept_.tobytes()).hexdigest()

output = []
with threadpool_limits(1), frozen_reference(archive=Path('benchmarks/reference/overhead-logistic-2026-10-26.zip')) as ref:
    for dtype in ('float32', 'float64'):
        for n, d in ((60_000, 1024), (40_000, 2048)):
            case = Case(f'{n}_{d}',n,d)
            X,y,_ = make_data(case,41,dtype=dtype)
            samples={k:[] for k in NAMES};details={k:[] for k in NAMES};models={k:[] for k in NAMES}
            for i in range(WARMUP):
                for name in order(i): fit(name,X,y,ref)
            for i in range(REPEATS):
                for name in order(i):
                    elapsed,model,meta=fit(name,X,y,ref)
                    samples[name].append(elapsed*1000);details[name].append(meta);models[name].append(model)
            groups={};all_quality={}
            for name in NAMES:
                all_quality[name]=[]
                for model,meta in zip(models[name],details[name]):
                    if name in ('fixed','adaptive'):
                        assert meta['implementation']=='native_command_loop' and not meta['warnings'],meta
                        for state in meta['solutions']+meta['solver_calls']:
                            assert state['converged'] and state['stop_reason']=='gtol' and state['grad_max_abs']<=1e-4,state
                    key=digest(model)
                    if key not in groups:
                        groups[key]=quality(model,models['sklearn'][-1],X,y,None)
                    q=groups[key]
                    if name in ('fixed','adaptive'):
                        assert q['gradient_max_abs_float64']<=1e-4,q
                        assert q['objective_relative_gap_to_sklearn']<=1e-5,q
                        assert q['prediction_agreement_sklearn']>=.995,q
                    all_quality[name].append({'fingerprint':key,**q})
            item={'dtype':dtype,'shape':[n,d],'seed':41,'orders':[order(i) for i in range(REPEATS)],'samples_ms':samples,'details':details,'quality_every_fit':all_quality}
            output.append(item);Path('chunk-ab-48.json').write_text(json.dumps(output,indent=2)+'\n')
            print(dtype,n,d,{k:round(statistics.median(v),3) for k,v in samples.items()},flush=True)
            print('adaptive_paired_wins',sum(b<a for a,b in zip(samples['fixed'],samples['adaptive'])),'unique_scores',len(groups),flush=True)
