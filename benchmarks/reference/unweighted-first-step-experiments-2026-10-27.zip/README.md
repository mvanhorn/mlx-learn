# Unweighted input preparation and one-candidate Armijo experiments

Scratch-only diagnostic; neither candidate is production code. `compare.py` uses the `onepass.py` candidate: a near-centered input may skip exact centering after a finite mean/scale screen, with original centering retained on screen failure. `one_candidate.py` retains the full original 32-candidate fallback but runs the initial native search with just one candidate. Both use all 24 permutations of four variants and score each fit independently after timing. Datasets are synthetic seed 41; 4096-feature case uses a shared tol=1e-5.

Reproduction requires Apple Silicon, compatible dependencies, `benchmarks/reference/certified-start-2026-10-27.zip` and the matching ABI3 binary. Extract that source archive to `bench/unweighted_opt/snapshot`, copy the reference extension to its `mlxlearn/_solvers/_metal_loop.abi3.so`, and place the matching extension at `bench/certified-start/_metal_loop.abi3.so`. Then run from repository root:

```sh
PYTHONPATH=bench/unweighted_opt/snapshot:bench/unweighted_opt:. python3 bench/unweighted_opt/compare.py --dtype float32 --repeats 24 --warmup 3
PYTHONPATH=bench/unweighted_opt/snapshot:bench/unweighted_opt:. python3 bench/unweighted_opt/one_candidate.py --dtype float32 --repeats 24 --warmup 3
```

The first-candidate candidate falls back to the original solver when a full native result cannot be certified. All 24 strict 4096-feature candidates did so after rejecting a first candidate, adding substantial cost. Raw files retain every variant order, timing, fit detail, and independent float64 score. The raw timing binary hashes were computed immediately after the run, not by an in-run integrity audit.
