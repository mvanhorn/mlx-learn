"""Diagnostic single-pass near-centered binary input preparation, not production.

The benchmark tests an optimization upper bound. Input-dependent screening uses
bounded, shifted means and raw second moments; uncertain inputs fall back to the
unchanged prepared-centering path. It keeps the borrowed array alive until all
GPU consumers have completed. No global input or fitted-state cache is used.
"""
from contextlib import contextmanager
import mlx.core as mx

from mlxlearn._common.device import use_device
from mlxlearn.linear_model import _logistic as estimator

_original_prepare = estimator._prepare_centered_logistic_input
EVENTS = []

_onepass = mx.fast.metal_kernel(
    name="mlxlearn_unweighted_copy_initial_means_diag",
    input_names=["X", "y"],
    output_names=["owned", "parts", "means", "flags"],
    source=r"""
uint tid=thread_position_in_threadgroup.x, lane=tid%32, sg=tid/32;
uint cb=threadgroup_position_in_grid.x, col=cb*32+lane;
uint block=threadgroup_position_in_grid.y;
float grad=0.0f,diag=0.0f,mean=0.0f;
float anchor=col<D?X[col]*0.25f:0.0f;
bool good=true;
if(col<P){
 for(ulong row=ulong(block)*256+sg;row<min(ulong(N),(ulong(block)+1)*256);row+=4){
  float x=1.0f;
  if(col<D){
   ulong i=row*D+col;x=X[i];owned[i]=x;
   good=good && isfinite(x);mean+=(x*.25f-anchor)*(1.0f/N);
  }
  grad+=x*(.5f-y[row]);diag+=.25f*x*x;
 }
}
threadgroup float gp[128], hp[128], mp[128];
threadgroup uint valid[4];
gp[tid]=grad;hp[tid]=diag;mp[tid]=mean;
bool allgood=simd_all(good);
if(lane==0)valid[sg]=uint(allgood);
threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==0 && col<P){
 parts[ulong(block)*P+col]=gp[tid]+gp[tid+32]+gp[tid+64]+gp[tid+96];
 parts[ulong(B)*P+ulong(block)*P+col]=hp[tid]+hp[tid+32]+hp[tid+64]+hp[tid+96];
 if(col<D)means[ulong(block)*D+col]=(mp[tid]+mp[tid+32])+(mp[tid+64]+mp[tid+96]);
}
if(tid==0)flags[ulong(block)*COLS+cb]=valid[0]&valid[1]&valid[2]&valid[3];
""",
)

@contextmanager
def fast_prepare(X, y, weights, *, native):
    if weights is not None or not native:
        EVENTS.append("ineligible")
        with _original_prepare(X,y,weights,native=native) as result:
            yield result
        return
    with use_device("gpu"):
        borrowed = mx.asarray(X) if hasattr(mx,"asarray") else mx.array(X)
        labels=mx.array(y,dtype=mx.float32)
        n,d=borrowed.shape
        p=d+1; blocks=(n+255)//256; cols=(p+31)//32
        owned,parts,means,flags=_onepass(
            inputs=[borrowed,labels],
            template=[("N",n),("D",d),("P",p),("B",blocks),("COLS",cols)],
            grid=(cols*128,blocks,1),threadgroup=(128,1,1),
            output_shapes=[(n,d),(2,blocks,p),(blocks,d),(blocks,cols)],
            output_dtypes=[mx.float32,mx.float32,mx.float32,mx.uint32],
        )
        bound=3.4028234663852886e38*.25
        mean=mx.clip(borrowed[0]*.25+mx.sum(means,axis=0),-bound,bound)*4
        moment=mx.sum(parts[1,:,:d],axis=0)*(4.0/n)
        safe=mx.all(mx.isfinite(mean)&mx.isfinite(moment)&(mx.abs(mean)<=.05*mx.sqrt(mx.maximum(moment,0))))
        finite=mx.all(flags!=0)
        center=mx.zeros(d,dtype=mx.float32)
        try:
            mx.eval(owned,parts,safe,finite,center)
            if not bool(finite):
                EVENTS.append("nonfinite")
                yield owned,center,False,parts
            elif bool(safe):
                EVENTS.append("fast")
                yield owned,center,True,parts
            else:
                EVENTS.append("screen_fallback")
                with _original_prepare(X,y,weights,native=native) as result:
                    yield result
        finally:
            mx.synchronize()
