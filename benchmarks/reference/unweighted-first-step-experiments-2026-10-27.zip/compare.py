"""Interleaved complete fits for diagnostic one-pass near-centered preparation.

Not a production change. Every sample, order, path, convergence result and
independent accuracy is retained. Score every timed model after timing a case.
"""
import argparse
import contextlib
import time
import hashlib
import itertools
import json
import statistics
import sys
from pathlib import Path

import numpy as np
from threadpoolctl import threadpool_limits

sys.path.insert(0, str(Path(__file__).resolve().parent))
import onepass
from benchmarks.logistic_gpu import Case, make_data, quality
from benchmarks.logistic_wide import fit_once, frozen_reference
from mlxlearn.linear_model import _logistic as estimator


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--repeats',type=int,default=24)
    parser.add_argument('--warmup',type=int,default=3)
    parser.add_argument('--output',type=Path,default=Path('bench/unweighted_opt/results.json'))
    parser.add_argument('--dtype',choices=('float32','float64','both'),default='both')
    parser.add_argument('--shift',type=float,default=0)
    args=parser.parse_args()
    variants=('previous_native','current','fast','sklearn')
    permutations=list(itertools.permutations(variants))
    assert args.repeats%len(permutations)==0, 'use 24, 48, ... repeats for balanced ordering'
    original=estimator._prepare_centered_logistic_input
    cases=(Case('20k1024',20000,1024),Case('60k1024',60000,1024))
    if args.shift:cases=(Case('20k1024_shift',20000,1024),)
    result={'method':{'variants':variants,'permutations':len(permutations),'warmup':args.warmup,
                      'repeats':args.repeats,'score':'every fit after timing','shift':args.shift},
            'candidate_sha256':hashlib.sha256(Path(onepass.__file__).read_bytes()).hexdigest(),
            'harness_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'cases':[]}
    archive=Path('benchmarks/reference/certified-start-2026-10-27.zip')
    binary=Path('bench/certified-start/_metal_loop.abi3.so')
    with frozen_reference(archive=archive,extension=binary) as reference,threadpool_limits(limits=1):
        for dtype in (('float32','float64') if args.dtype=='both' else (args.dtype,)):
            for case in cases:
                X,y,weights=make_data(case,41,dtype=dtype)
                if args.shift:X+=np.asarray(args.shift,dtype=X.dtype)
                rec={'name':case.name,'shape':[case.n_samples,case.n_features],
                     'dtype':dtype,'order':[], 'fits':{k:[] for k in variants},
                     'samples':{k:[] for k in variants}}
                models={k:[] for k in variants}
                def fit(variant):
                    elapsed_prepare=[]
                    @contextlib.contextmanager
                    def instrument(factory,*a,**kw):
                        start=time.perf_counter()
                        with factory(*a,**kw) as value:
                            elapsed_prepare.append((time.perf_counter()-start)*1000)
                            yield value
                    ref_original=reference.estimator._prepare_centered_logistic_input
                    factory=onepass.fast_prepare if variant=='fast' else original
                    estimator._prepare_centered_logistic_input=lambda *a,**kw: instrument(factory,*a,**kw)
                    if variant=='previous_native':
                        reference.estimator._prepare_centered_logistic_input=lambda *a,**kw: instrument(ref_original,*a,**kw)
                    start_events=len(onepass.EVENTS)
                    mapped='optimized_gpu' if variant in ('fast','current') else variant
                    try:
                        elapsed,model,meta=fit_once(mapped,X,y,weights,reference=reference,max_iter=200,tol=1e-4)
                    finally:
                        estimator._prepare_centered_logistic_input=original
                        reference.estimator._prepare_centered_logistic_input=ref_original
                    return elapsed,model,{**meta,'prepare_events':onepass.EVENTS[start_events:],'prepare_ms':elapsed_prepare}
                for _ in range(args.warmup):
                    for v in variants:fit(v)
                for i in range(args.repeats):
                    order=permutations[i%len(permutations)]
                    rec['order'].append(order)
                    for v in order:
                        t,m,meta=fit(v);rec['samples'][v].append(t);rec['fits'][v].append(meta);models[v].append(m)
                X64=X.astype(np.float64,copy=False)
                # Each score outside the timed loop. sklearn's final fit is a
                # common reference for every method and repetition.
                sk=models['sklearn'][-1]
                rec['quality']={k:[quality(m,sk,X64,y,weights) for m in ms] for k,ms in models.items() if k!='sklearn'}
                rec['median_ms']={k:statistics.median(v)*1000 for k,v in rec['samples'].items()}
                rec['mean_ms']={k:statistics.mean(v)*1000 for k,v in rec['samples'].items()}
                rec['paired_wins_fast_vs_current']=sum(a<b for a,b in zip(rec['samples']['fast'],rec['samples']['current']))
                print(dtype,case.name,rec['median_ms'],rec['paired_wins_fast_vs_current'],flush=True)
                result['cases'].append(rec); args.output.parent.mkdir(parents=True,exist_ok=True)
                args.output.write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
