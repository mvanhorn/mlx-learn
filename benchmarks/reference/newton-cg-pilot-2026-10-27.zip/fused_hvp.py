"""Scratch single-pass Metal Hessian-vector product; not production code.

For nonnegative per-row curvature c_i, computes
    X.T @ (c * (X @ v_features + v_bias)) + regularization * v
with the optional last coordinate unregularized. Inputs must be contiguous
float32 GPU arrays. A nonfinite or negative curvature propagates a NaN; rows
whose curvature is exactly zero are skipped before loading the row's data.
"""
from __future__ import annotations

import mlx.core as mx

_one_pass_hvp = mx.fast.metal_kernel(
    name="mlxlearn_scratch_single_pass_hvp",
    input_names=["X", "curvature", "vector"],
    output_names=["parts"],
    source=r"""
uint tid=thread_position_in_threadgroup.x,lane=tid%32,sg=tid/32;
uint block=threadgroup_position_in_grid.x;
constexpr uint V=(D+32*FEATURE_GROUPS-1)/(32*FEATURE_GROUPS);
constexpr uint CHUNK=V*32,DPAD=CHUNK*FEATURE_GROUPS;
constexpr uint ROW_GROUPS=GROUPS/FEATURE_GROUPS;
uint fs=sg%FEATURE_GROUPS,rs=sg/FEATURE_GROUPS;
threadgroup float scratch[ROW_GROUPS*DPAD];
float accumulator[V];for(uint k=0;k<V;++k)accumulator[k]=0.0f;
float local_bias=0.0f;
for(uint rr=0;rr<ROWS;++rr){
 uint row=block*(ROW_GROUPS*ROWS)+rr*ROW_GROUPS+rs;
 float c=row<N?curvature[row]:0.0f;
 bool invalid=row<N && (!isfinite(c) || c<0.0f);
 bool load=row<N && (c>0.0f || invalid);
 float values[V],dot=0.0f;
 if(load){for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;
  values[k]=j<D?X[ulong(row)*D+j]:0.0f;
  if(j<D)dot=fma(values[k],vector[j],dot);
 }}else{for(uint k=0;k<V;++k)values[k]=0.0f;}
 dot=simd_sum(dot);
 if(FEATURE_GROUPS>1){
  if(lane==0)scratch[sg]=dot;
  threadgroup_barrier(mem_flags::mem_threadgroup);
  dot=0.0f;for(uint f=0;f<FEATURE_GROUPS;++f)dot+=scratch[rs*FEATURE_GROUPS+f];
  threadgroup_barrier(mem_flags::mem_threadgroup);
 }
 if(P>D)dot+=vector[D];
 float weighted=0.0f;
 if(lane==0 && row<N){
  weighted=invalid?as_type<float>(0x7fc00000u):(c==0.0f?0.0f:c*dot);
  if(fs==0)local_bias+=weighted;
 }
 weighted=simd_shuffle(weighted,ushort(0));
 for(uint k=0;k<V;++k)accumulator[k]=fma(values[k],weighted,accumulator[k]);
}
if(lane==0)scratch[sg]=local_bias;
threadgroup_barrier(mem_flags::mem_threadgroup);
if(sg==0 && lane==0 && P>D){float total=0.0f;
 for(uint s=0;s<GROUPS;++s)total+=scratch[s];
 parts[ulong(block)*P+D]=total;
}
threadgroup_barrier(mem_flags::mem_threadgroup);
for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;scratch[rs*DPAD+j]=accumulator[k];}
threadgroup_barrier(mem_flags::mem_threadgroup);
if(rs==0){for(uint k=0;k<V;++k){uint j=fs*CHUNK+lane+k*32;if(j<D){
 float total=0.0f;for(uint r=0;r<ROW_GROUPS;++r)total+=scratch[r*DPAD+j];
 parts[ulong(block)*P+j]=total;
}}}
""",
)


def geometry(n: int, d: int):
    if d <= 1024:
        groups, feature_groups, rows = 2, 1, 16
    else:
        groups, feature_groups, rows = 8, 4, 8
    if n >= 16384:
        if d <= 1024:
            groups, rows = 4, 32
        else:
            rows = 32 if d <= 2048 else 64
    blocks = (n + (groups // feature_groups) * rows - 1) // ((groups // feature_groups) * rows)
    return groups, feature_groups, rows, blocks


def fused_hvp(X, curvature, vector, regularization):
    """Return the exact-form HVP in float32; direct finite checks remain required."""
    if X.ndim != 2 or not X.shape[0] or not 1 <= X.shape[1] <= 4096:
        raise ValueError("X must be a nonempty matrix of at most 4096 features")
    n, d = X.shape
    if (X.dtype != mx.float32 or curvature.dtype != mx.float32 or vector.dtype != mx.float32
        or regularization.dtype != mx.float32 or curvature.shape != (n,)
        or vector.shape not in ((d,), (d + 1,)) or regularization.shape != vector.shape):
        raise ValueError("curvature, vector and regularization must match float32 design")
    p = vector.shape[0]
    groups, feature_groups, rows, blocks = geometry(n, d)
    parts = _one_pass_hvp(
        inputs=[X, curvature, vector],
        template=[("N", n), ("D", d), ("P", p), ("B", blocks), ("GROUPS", groups),
                  ("FEATURE_GROUPS", feature_groups), ("ROWS", rows)],
        grid=(blocks * groups * 32, 1, 1), threadgroup=(groups * 32, 1, 1),
        output_shapes=[(blocks, p)], output_dtypes=[mx.float32],
    )[0]
    return mx.sum(parts, axis=0) + regularization * vector
