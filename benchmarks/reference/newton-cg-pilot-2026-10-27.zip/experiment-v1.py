"""Isolated GPU Newton-CG correction experiment; never modifies production.

The Hessian is exact for the fitted binary objective in represented float32
arithmetic. No diagonal/block preconditioner is used: with scalar initialization,
the Krylov vectors remain in range(X.T) in exact arithmetic. This is a pilot,
not a certificate or a production implementation.
"""
from __future__ import annotations

import argparse
import json
import math
import time
import warnings
from pathlib import Path
from types import SimpleNamespace

import mlx.core as mx
import numpy as np
from threadpoolctl import threadpool_limits

from benchmarks.hessian_logistic import Case, dataset, independent_score, sources
from mlxlearn._common.config import tuning_context
from mlxlearn.linear_model import LogisticRegression


def check_vector(vec):
    mx.eval(vec)
    return bool(mx.all(mx.isfinite(vec)))


def cg_step(X, y, sw, wsum, coef, bias, C, steps):
    """Compute one Newton direction using unpreconditioned truncated CG."""
    d = X.shape[1]
    theta = mx.concatenate([coef.reshape(-1), mx.array([bias], mx.float32)])
    z = X @ theta[:d] + theta[d]
    p = mx.sigmoid(z)
    residual = (p - y) * sw
    grad = mx.concatenate([X.T @ residual / wsum + theta[:d] / (C * wsum),
                           mx.sum(residual, keepdims=True) / wsum])
    diagonal = p * (1.0 - p) * sw / wsum
    mx.eval(theta, z, p, grad, diagonal)
    mx.synchronize()
    if not check_vector(grad):
        raise RuntimeError("nonfinite gradient")

    x = mx.zeros_like(theta)
    r = -grad
    direction = r
    rr = mx.sum(r * r)
    mx.eval(rr)
    records = []
    for i in range(steps):
        projection = X @ direction[:d] + direction[d]
        weighted = diagonal * projection
        hd = mx.concatenate([X.T @ weighted + direction[:d] / (C * wsum),
                             mx.sum(weighted, keepdims=True)])
        denominator = mx.sum(direction * hd)
        mx.eval(denominator, rr)
        denom_value = float(denominator)
        rr_value = float(rr)
        if not math.isfinite(denom_value) or denom_value <= 0 or not math.isfinite(rr_value):
            records.append({"iteration": i, "error": "nonpositive or nonfinite curvature"})
            break
        alpha = rr / denominator
        x_next = x + alpha * direction
        r_next = r - alpha * hd
        rr_next = mx.sum(r_next * r_next)
        mx.eval(x_next, r_next, rr_next)
        new_rr = float(rr_next)
        if not math.isfinite(new_rr):
            records.append({"iteration": i, "error": "nonfinite residual"})
            break
        records.append({"iteration": i + 1, "residual_norm": math.sqrt(new_rr)})
        x, r = x_next, r_next
        if new_rr <= 1e-20:
            break
        direction = r + (rr_next / rr) * direction
        rr = rr_next
    mx.eval(x, grad)
    return theta, x, grad, records


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=41)
    ap.add_argument("--case", choices=("ill4096", "normal4096", "rank1024", "weightedill1024"), default="ill4096")
    ap.add_argument("--steps", type=int, nargs="+", default=[4, 8, 16, 32])
    ap.add_argument("--output", type=Path, default=Path("bench/cg_polish/results.json"))
    args = ap.parse_args()
    cases = {
        "ill4096": Case("ill_conditioned_4096", 20_000, 4_096, seed=args.seed, ill_conditioned=True),
        "normal4096": Case("wide_4096", 20_000, 4_096, seed=args.seed),
        "rank1024": Case("rank_deficient_1024", 20_000, 1_024, seed=args.seed, rank_deficient=True, C=1e6),
        "weightedill1024": Case("weighted_ill_1024", 20_000, 1_024, seed=args.seed, ill_conditioned=True, weighted=True),
    }
    case = cases[args.case]
    hashes = sources([Path(__file__).resolve()])
    with threadpool_limits(limits=1):
        X, y, weights, ratio = dataset(case)
        with warnings.catch_warnings(record=True) as caught, tuning_context(force_backend="mlx", lbfgs_sketch_size=0):
            warnings.simplefilter("always")
            mx.synchronize()
            begin = time.perf_counter()
            model = LogisticRegression(C=case.C, tol=1e-4, max_iter=200).fit(X, y, sample_weight=weights)
            mx.synchronize()
            baseline_ms = (time.perf_counter() - begin) * 1000
        original, _ = independent_score(model, X, y, weights, case.C, ratio)
        center = np.mean(X, axis=0, dtype=np.float64).astype(np.float32)
        centered_bias = float(model.intercept_[0] + model.coef_[0] @ center.astype(np.float64))
        Xdev = mx.array(X, dtype=mx.float32) - mx.array(center)
        ydev = mx.array(y, dtype=mx.float32)
        swdev = mx.ones((len(y),), mx.float32) if weights is None else mx.array(weights, dtype=mx.float32)
        wsum = float(len(y) if weights is None else np.sum(weights, dtype=np.float64))
        coef = mx.array(model.coef_[0], dtype=mx.float32)
        mx.eval(Xdev, ydev, swdev, coef)
        mx.synchronize()
        rows = []
        for steps in args.steps:
            start = time.perf_counter()
            theta, delta, gradient, trace = cg_step(Xdev, ydev, swdev, wsum, coef, centered_bias, case.C, steps)
            slope = float(mx.sum(gradient * delta))
            theta_host, delta_host = np.array(theta, dtype=np.float64), np.array(delta, dtype=np.float64)
            elapsed = (time.perf_counter() - start) * 1000
            trials = []
            for alpha in (1.0, .5, .25, .125):
                params = theta_host + alpha * delta_host
                candidate = SimpleNamespace(coef_=params[:-1].reshape(1, -1),
                    intercept_=np.array([params[-1] - params[:-1] @ center.astype(np.float64)]))
                score, _ = independent_score(candidate, X, y, weights, case.C, ratio)
                trials.append({"alpha": alpha, "score": score})
            rows.append({"steps": steps, "ms": elapsed, "gradient_dot_direction": slope,
                         "trace": trace, "trials": trials})
            print(args.case, args.seed, "cg", steps, "ms", round(elapsed, 2),
                  "slope", slope, "objective", [r["score"]["objective_float64"] for r in trials], flush=True)
        payload = {"case": args.case, "seed": args.seed, "baseline_ms": baseline_ms,
                   "baseline_iter": model.n_iter_.tolist(), "baseline_warnings": [str(x.message) for x in caught],
                   "baseline_score": original, "cg": rows, "source_before": hashes,
                   "source_after": sources([Path(__file__).resolve()])}
        payload["integrity"] = payload["source_before"] == payload["source_after"]
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(payload, indent=2) + "\n")


if __name__ == "__main__":
    main()
