"""Balanced first-step scale experiment with two-step progress certification.

All eight variants occupy every position equally often and have every possible
immediate predecessor equally often. Every model is independently scored in
float64 after all timings for its case. Objective/gradient failures, warnings,
and fallback routes are retained, not filtered.
"""
import argparse
import gc
import hashlib
import importlib.util
import itertools
import json
import statistics
import time
import warnings
from pathlib import Path
from types import SimpleNamespace

import mlx.core as mx
import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits

from benchmarks.logistic_gpu import Case,make_data
from benchmarks.logistic_wide import frozen_reference,observed_implementation,package_source_paths
from mlxlearn import config_context
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import logistic,native_command,native_logistic
from mlxlearn.linear_model import LogisticRegression
from mlxlearn.linear_model import _logistic as estimator


def progress2_source(source):
    changes={
      'stats[4]=maxgrad;stats[5]=active?slope:0.0f':'stats[4]=meta[4];stats[5]=active?slope:0.0f',
      'i==8?alpha:(i==9?stats[9]+(stats[1]==0?CAND:0):(i==10?(accepted?accepted_diff:stats[10])':'i==4?(accepted?accepted_diff:stats[4]):(i==8?alpha:(i==9?stats[9]+(stats[1]==0?CAND:0):(i==10?(accepted?(stats[0]==0?abs(accepted_diff):0.5f*(abs(accepted_diff)+abs(stats[4]))):stats[10])',
      'stats[11]+accepted_diff:stats[i])))));':'stats[11]+accepted_diff:stats[i]))))));',
    }
    for old,new in changes.items():
        if source.count(old)!=1:raise RuntimeError('Unexpected source fragment '+old)
        source=source.replace(old,new)
    return source


def score(model,reference,X64,y,weights,C):
    W=np.asarray(model.coef_,dtype=np.float64);b=np.asarray(model.intercept_,dtype=np.float64)
    codes=np.searchsorted(model.classes_,y);denom=len(y) if weights is None else float(weights.sum(dtype=np.float64))
    raw=X64@W[0]+b[0];residual=expit(raw)-codes
    if weights is not None:residual*=weights
    grad=residual@X64/denom+W[0]/(C*denom);gb=float(residual.sum()/denom)
    obj=logistic.reference_objective(W,b,X64,codes,n_classes=2,C=C,sample_weight=weights)
    ref=logistic.reference_objective(reference.coef_,reference.intercept_,X64,codes,n_classes=2,C=C,sample_weight=weights)
    refraw=X64@np.asarray(reference.coef_[0],dtype=np.float64)+float(reference.intercept_[0])
    return {'gradient_max_abs_float64':max(float(np.max(np.abs(grad))),abs(gb)),
            'objective_float64':float(obj),
            'objective_relative_gap_to_sklearn':float((obj-ref)/max(abs(ref),np.finfo(float).tiny)),
            'prediction_agreement_sklearn':float(np.mean((raw>0)==(refraw>0)))}


def main():
    p=argparse.ArgumentParser();p.add_argument('--repeats',type=int,default=18);p.add_argument('--warmup',type=int,default=2)
    p.add_argument('--dtype',choices=('float32','float64','both'),default='float32')
    p.add_argument('--seed',type=int,default=41)
    p.add_argument('--output',type=Path,default=Path('bench/unweighted_opt/scale_tuning/heldout-results.json'))
    p.add_argument('--case',action='append',default=[]);a=p.parse_args()
    variants=('avg2','alpha125','sklearn')
    scale={'alpha125':1.25}
    orders=list(itertools.permutations(variants))
    assert a.repeats%len(orders)==0
    original=native_command._metal_loop
    binary=Path('bench/unweighted_opt/scale_tuning/_metal_loop.abi3.so').resolve()
    spec=importlib.util.spec_from_file_location('_scale_tuning._metal_loop',binary)
    tuned=importlib.util.module_from_spec(spec);spec.loader.exec_module(tuned)
    cases=((Case('normal83',20000,1024),1.0),(Case('normal2027',20000,1024),1.0),
           (Case('normal60000',60000,1024),1.0),(Case('unbalanced',20000,1024),1.0),
           (Case('ill_conditioned',10000,1024,ill_conditioned=True),1.0),
           (Case('shifted',20000,1024),1.0))
    if a.case:
        assert not set(a.case)-{c.name for c,_ in cases}
        cases=tuple((c,C) for c,C in cases if c.name in a.case)
    paths=package_source_paths()+[Path(__file__),Path('bench/unweighted_opt/scale_tuning/_metal_loop.mm'),
      binary,Path('bench/certified-start/_metal_loop.abi3.so'),Path('benchmarks/reference/certified-start-2026-10-27.zip'),
      Path('benchmarks/logistic_wide.py'),Path('benchmarks/logistic_gpu.py')]
    hashes={str(q.resolve()):hashlib.sha256(q.read_bytes()).hexdigest() for q in paths}
    out={'method':{'variants':variants,'orders':orders,'repeats':a.repeats,'warmups':a.warmup,
          'score':'every fit independently after timing','tol':1e-4,'max_iter':200,
          'averaged_guard':'mean of absolute previous two accepted objective deltas, except first step',
          'scales':'first iteration only; 1.0 afterward; unchanged Armijo and fallback'},'hashes':hashes,'cases':[]}
    archive=Path('benchmarks/reference/certified-start-2026-10-27.zip'); ext=Path('bench/certified-start/_metal_loop.abi3.so')
    with frozen_reference(archive=archive,extension=ext) as reference,threadpool_limits(limits=1):
      for dtype in (('float32','float64') if a.dtype=='both' else (a.dtype,)):
       for case,C in cases:
        seed=83 if case.name=='normal83' else 2027 if case.name=='normal2027' else a.seed
        X,y,weights=make_data(case,seed,dtype=dtype)
        if case.name=='unbalanced':
            y=(X[:,0]+np.random.default_rng(862).normal(scale=.5,size=len(X))>2.0).astype(np.int32)
        if case.name=='shifted':
            X=X+np.asarray(1000.0,dtype=X.dtype)
        samples={v:[] for v in variants};models={v:[] for v in variants};details={v:[] for v in variants};order_used=[]
        def fit(v):
            device_calls=[]
            if v=='avg2':
                def run(source,*args):
                    q=original.run(progress2_source(source),*args);device_calls.append({'status':q[2],'n_iter':q[1]});return q
                native_command._metal_loop=SimpleNamespace(run=run)
            elif v in scale:
                def run(source,*args):
                    q=tuned.run(progress2_source(source),*args,scale[v]);device_calls.append({'status':q[2],'n_iter':q[1]});return q
                native_command._metal_loop=SimpleNamespace(run=run)
            if v=='previous_native':
                cls=reference.estimator.LogisticRegression;settings=reference.config.config_context;tuning=reference.config.tuning_context
                obs=observed_implementation(reference.estimator,reference.solver,reference.native)
            else:
                cls=SkLogisticRegression if v=='sklearn' else LogisticRegression;settings=config_context;tuning=tuning_context
                obs=observed_implementation(estimator,logistic,native_logistic)
            try:
                with settings(device='auto'),tuning(force_backend='' if v=='sklearn' else 'mlx'),obs as observed,warnings.catch_warnings(record=True) as caught:
                    warnings.simplefilter('always');mx.synchronize();enabled=gc.isenabled();gc.disable()
                    try:
                        start=time.perf_counter();m=cls(C=C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weights);mx.synchronize();elapsed=time.perf_counter()-start
                    finally:
                        if enabled:gc.enable()
                info={'backend':getattr(m,'_execution_backend_','sklearn'),'n_iter':m.n_iter_.tolist(),
                      'implementation':observed['solver_calls'][-1]['implementation'] if observed['solver_calls'] else 'sklearn',
                      'warnings':[{'category':x.category.__name__,'message':str(x.message)} for x in caught],
                      'device_calls':device_calls,**observed}
                return elapsed,m,info
            finally:native_command._metal_loop=original
        for i in range(a.warmup):
            for v in orders[i%len(orders)]:fit(v)
        for i in range(a.repeats):
            order=orders[i%len(orders)];order_used.append(order)
            for v in order:
                t,m,info=fit(v);samples[v].append(t);models[v].append(m);details[v].append(info)
        X64=np.asarray(X,dtype=np.float64);reference_model=models['sklearn'][-1]
        quality={v:[score(m,reference_model,X64,y,weights,C) for m in models[v]] for v in variants if v!='sklearn'}
        row={'name':case.name,'dtype':dtype,'shape':[case.n_samples,case.n_features],
             'C':C,'seed':seed,'weighted':case.weighted,'orders':order_used,'samples_s':samples,'fits':details,'quality_each_fit':quality,
             'median_ms':{v:1000*float(np.median(samples[v])) for v in variants},
             'mean_ms':{v:1000*float(np.mean(samples[v])) for v in variants},
             'paired_wins_vs_avg2':{v:sum(x<y for x,y in zip(samples[v],samples['avg2'])) for v in scale}}
        out['cases'].append(row)
        out['source_integrity']={path:Path(path).is_file() and hashlib.sha256(Path(path).read_bytes()).hexdigest()==h for path,h in hashes.items()}
        a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(out,indent=2)+'\n')
        print(dtype,case.name,'median_ms',row['median_ms'],'iterations',{v:sorted({tuple(i['n_iter']) for i in details[v]}) for v in variants},
              'wins',row['paired_wins_vs_avg2'],'maxgap',{v:max(q['objective_relative_gap_to_sklearn'] for q in quality[v]) for v in quality},
              'maxgrad',{v:max(q['gradient_max_abs_float64'] for q in quality[v]) for v in quality},
              'warnings',{v:sum(bool(i['warnings']) for i in details[v]) for v in variants},flush=True)

if __name__=='__main__':main()
