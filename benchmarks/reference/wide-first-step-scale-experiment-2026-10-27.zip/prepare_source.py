"""Generate a scratch native-loop extension with a per-call first-step scale.

No production files are changed. The full Armijo batch, fallback, iteration
budget, two-step progress criterion, and direct original-coordinate convergence
check remain as in the source being copied. Do not build/run during another
agent's timed GPU experiment.
"""
import hashlib
from pathlib import Path

source=Path('src/mlxlearn/_solvers/_metal_loop.mm')
s=source.read_text()
needle='    double denom_d,tol_d,c1_d,mincurv_d;'
assert s.count(needle)==1
s=s.replace(needle,'    double denom_d,tol_d,c1_d,mincurv_d,first_alpha_d;',1)
needle='"sOiiiiiiiddddOy#",&source,&capsules,&n,&d,&p,&m,&blocks,&groups,&max_iter,&denom_d,&tol_d,&c1_d,&mincurv_d,&owner_bundle,&center_data,&center_bytes)'
assert s.count(needle)==1
s=s.replace(needle,'"sOiiiiiiiddddOy#d",&source,&capsules,&n,&d,&p,&m,&blocks,&groups,&max_iter,&denom_d,&tol_d,&c1_d,&mincurv_d,&owner_bundle,&center_data,&center_bytes,&first_alpha_d)',1)
needle='            for(int k=0;k<chunk;++k) {\n              int next=1-cur;'
assert s.count(needle)==1
s=s.replace(needle,'            for(int k=0;k<chunk;++k) {\n              alpha=(n_iter==0 && k==0) ? float(first_alpha_d) : 1.0f;\n              int next=1-cur;',1)
# This class exists only for fault-injection tests. Renaming it prevents the
# Objective-C runtime from colliding with the production binary when both are
# loaded into the same benchmark process; no training path instantiates it.
needle='MLXLearnRetainTestBufferV2'
assert needle in s
s=s.replace(needle,'MLXLearnRetainTestBufferTuning')
out=Path('bench/unweighted_opt/scale_tuning');out.mkdir(parents=True,exist_ok=True)
(out/'_metal_loop.mm').write_text(s)
(out/'baseline-source.sha256').write_text(hashlib.sha256(source.read_bytes()).hexdigest()+'\n')
print('Generated scratch source for production SHA:',hashlib.sha256(source.read_bytes()).hexdigest())
