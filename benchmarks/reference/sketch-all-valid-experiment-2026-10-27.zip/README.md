# All-valid sketch-history no-gather experiment

Scratch-only. The candidate is an exact copy of `build_sketch_history` except
when all k sampled curvature pairs pass the existing validity checks: it reuses
`mx.contiguous(s)` / `mx.contiguous(y)` and the `sy` / `yy` vectors instead of
four `mx.take` calls. Partial-valid and zero-valid paths are unchanged. This
preserves the history's value semantics and provides contiguous buffers even
when the no-intercept inputs are transposed.

The GPU component audit found bitwise-identical S, Y and history coefficients
on five all-valid shapes, including weighted and no-intercept inputs, history
sizes both equal to and larger than k, and row/feature tails. The zero-valid and
partial-valid paths (three out of four pairs) were also bitwise identical.

The full-fit benchmark uses six variants in rotating paired order, three warmups
and 16 repeats, reports device-resident inputs separately from host fits, scores
every returned model on the original data in float64, records warnings/routes
and hashes all production sources plus the loaded native binary before and
after. Every candidate/control model was bitwise identical (96 host/device
pairs total), all numerical checks passed, no fits emitted warnings, and the
source/binary audit passed. The original sklearn input may not be a trusted
reference when its independent original-coordinate gradient fails; in that case
the harness uses a separate tight centered reference.

| case | host current ms | host no-gather ms | host wins | device current ms | device no-gather ms | device wins |
|---|---:|---:|---:|---:|---:|---:|
| 20k × 1,024 | 8.476 | 8.527 | 8/16 | 9.996 | 10.064 | 8/16 |
| 20k × 4,096 | 52.400 | 52.540 | 5/16 | 56.696 | 56.419 | 7/16 |
| 20k × 1,024 weighted ill-conditioned | 82.681 | 82.060 | 13/16 | 84.896 | 85.966 | 7/16 |

There is no consistent speed gain; the optimization should not be promoted.
The benchmark source and runtime hashes were captured in-run. Audit source was
captured with this archive after measurement.

```
python3 bench/sketch_all_valid/audit.py
python3 bench/sketch_all_valid/benchmark.py --case wide1024 --case wide4096 --case weightedill --repeats 16 --warmups 3
```
