"""Bitwise compare old/fast history, including invalid probe subsets."""
from __future__ import annotations
import json,sys
from pathlib import Path
import mlx.core as mx
import numpy as np
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).resolve().parent))
from fast import build_sketch_history as fast
from mlxlearn_device.hessian_sketch import build_sketch_history as current


def compare(X,sw,swsum,l2,fit,h0,*,history=10,size=4,seed=0):
    a=current(X,sw,swsum,l2,fit,h0,history_size=history,sketch_size=size,seed=seed)
    b=fast(X,sw,swsum,l2,fit,h0,history_size=history,sketch_size=size,seed=seed)
    mx.eval(*a[:3],*b[:3]);mx.synchronize()
    equal=[bool(np.array_equal(np.asarray(x).view(np.uint32),np.asarray(y).view(np.uint32))) for x,y in zip(a[:3],b[:3],strict=True)]
    return {'count':a[3],'fast_count':b[3],'bitwise_equal':equal}


def main():
    rows=[]
    for n,d,fit,weighted,history,size in [(1024,512,True,False,10,4),(2049,513,True,True,10,4),
                                           (3073,1024,False,True,10,4),(2048,512,True,False,4,4),
                                           (3073,2049,True,True,10,4)]:
        rng=np.random.default_rng(36);X=mx.array(rng.standard_normal((n,d),dtype=np.float32));
        sw=mx.array(rng.uniform(.1,3.,n).astype(np.float32)) if weighted else None
        swsum=float(np.sum(np.asarray(sw),dtype=np.float64)) if sw is not None else float(n)
        out=compare(X,sw,swsum,1/swsum,fit,mx.ones((d+int(fit),),mx.float32),history=history,size=size)
        row={'case':'all_valid','n':n,'d':d,'intercept':fit,'weighted':weighted,'history':history,'sketch_size':size,**out};rows.append(row);print(row,flush=True)
        if out['count']!=size or out['fast_count']!=out['count'] or not all(out['bitwise_equal']):raise AssertionError(row)
    Xzero=mx.zeros((8,512),mx.float32);out=compare(Xzero,None,8.,1/8,True,mx.ones((513,),mx.float32));row={'case':'zero_valid',**out};rows.append(row);print(row,flush=True)
    if out['count']!=0 or out['fast_count']!=0 or not all(out['bitwise_equal']):raise AssertionError(row)
    X=np.zeros((8,512),np.float32);X[0,0]=1.;X[1,0]=-1.;Xm=mx.array(X)
    partial=None
    for seed in range(30):
        result=compare(Xm,None,8.,1/8,True,mx.ones((513,),mx.float32),seed=seed)
        if 0<result['count']<4:
            partial={'case':'partial_valid','seed':seed,**result};rows.append(partial);print(partial,flush=True);break
    if partial is None or partial['fast_count']!=partial['count'] or not all(partial['bitwise_equal']):raise AssertionError(partial)
    Path('bench/sketch_all_valid/audit.json').write_text(json.dumps(rows,indent=2)+'\n');return 0
if __name__=='__main__':raise SystemExit(main())
