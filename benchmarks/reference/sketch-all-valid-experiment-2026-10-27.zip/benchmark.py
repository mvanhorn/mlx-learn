"""Measure no-gather all-valid sketch on paired fresh full fits.

Timing includes input preparation, GPU sketch, optimizer, checks and export.
Device variants receive resident arrays; upload is separately reported. Models
are scored on the original inputs outside the timer in independent float64.
"""
from __future__ import annotations
import argparse,contextlib,gc,hashlib,json,math,statistics,sys,time,warnings
from pathlib import Path
from types import SimpleNamespace
import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SkLR
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));sys.path.insert(0,str(Path(__file__).resolve().parent))
from fast import build_sketch_history as fast
from benchmarks.hessian_logistic import Case,dataset,independent_score
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression
import mlxlearn_device.hessian_sketch as sketch
import mlxlearn_device._logistic as device


@contextlib.contextmanager
def selected(enable):
    old=sketch.build_sketch_history;old_device=device.build_sketch_history;command=native_command.run_native_loop
    telemetry={'sketch_counts':[],'routes':[]}
    def wrapper(*args,**kwargs):
        result=(fast if enable else old)(*args,**kwargs);telemetry['sketch_counts'].append(result[3]);return result
    def native(*args,**kwargs):
        result=command(*args,**kwargs);state=getattr(result,'state',result)
        telemetry['routes'].append('ineligible' if state is None else 'converged' if state.converged else state.stop_reason)
        return result
    sketch.build_sketch_history=wrapper;device.build_sketch_history=wrapper;native_command.run_native_loop=native
    try:yield telemetry
    finally:
        sketch.build_sketch_history=old;device.build_sketch_history=old_device;native_command.run_native_loop=command


def source_hashes():
    paths=[p for d in (ROOT/'src/mlxlearn',ROOT/'src/mlxlearn_device') for p in d.rglob('*')
           if p.is_file() and '__pycache__' not in p.parts and (p.suffix in {'.py','.mm','.so'} or p.name=='py.typed')]
    paths += [ROOT/'benchmarks/hessian_logistic.py',ROOT/'benchmarks/logistic_gpu.py',Path(__file__).resolve(),Path(__file__).with_name('fast.py').resolve()]
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths))}


def equal_parameters(a,b):
    if hasattr(a,'centered_intercept_'):
        return (np.array_equal(np.asarray(a.coef_).view(np.uint32),np.asarray(b.coef_).view(np.uint32))
                and np.array_equal(np.asarray(a.center_).view(np.uint32),np.asarray(b.center_).view(np.uint32))
                and np.array_equal(np.asarray(a.centered_intercept_).view(np.uint32),np.asarray(b.centered_intercept_).view(np.uint32)))
    return (np.array_equal(np.asarray(a.coef_).view(np.uint64),np.asarray(b.coef_).view(np.uint64))
            and np.array_equal(np.asarray(a.intercept_).view(np.uint64),np.asarray(b.intercept_).view(np.uint64)))


def fit_once(name,X,y,weights,case,device_data):
    isdev=name.startswith('device');enabled=name in ('fast','device_fast');force=name!='sklearn';size=0 if name=='unseeded' else 4
    with selected(enabled) as events,tuning_context(force_backend='mlx' if force else '',lbfgs_sketch_size=size),warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always');mx.synchronize();was=gc.isenabled();gc.disable();start=time.perf_counter()
        try:
            if isdev:
                model=device.fit_logistic(device_data[0],device_data[1],sample_weight=device_data[2],C=case.C,tol=1e-4,max_iter=200,sketch_size=4)
            else:
                cls=SkLR if name=='sklearn' else LogisticRegression
                model=cls(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weights)
            mx.synchronize();elapsed=(time.perf_counter()-start)*1000
        finally:
            if was:gc.enable()
    meta={'ms':elapsed,'warnings':[{'category':w.category.__name__,'message':str(w.message)} for w in caught],**events}
    if isdev:meta.update(n_iter=[model.n_iter],converged=model.converged,device_fallback=model.used_unsketched_fallback_)
    else:meta.update(n_iter=model.n_iter_.tolist(),backend=getattr(model,'_execution_backend_','sklearn'))
    return model,meta


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--repeats',type=int,default=12);parser.add_argument('--warmups',type=int,default=3);parser.add_argument('--seed',type=int,default=41);parser.add_argument('--case',action='append');args=parser.parse_args()
    variants=('unseeded','current','fast','device_current','device_fast','sklearn')
    cases=(Case('wide1024',20000,1024,seed=args.seed),Case('wide4096',20000,4096,seed=args.seed),
           Case('weightedill',20000,1024,seed=83,weighted=True,ill_conditioned=True),
           Case('ill4096',20000,4096,seed=args.seed,ill_conditioned=True),
           Case('rank',20000,1024,seed=args.seed,rank_deficient=True,C=1e6),
           Case('shifted',20000,1024,seed=args.seed,shifted=True))
    before=source_hashes();out={'method':'6 same-input variants, paired rotated fresh complete fits; host inputs are ready and device inputs resident; all original-input float64 scores outside timer','parameters':vars(args),'source_before':before,'cases':[]}
    with threadpool_limits(limits=1):
      for case in cases:
       if args.case and case.name not in args.case:continue
       X,y,weights,ratio=dataset(case);mx.synchronize();t=time.perf_counter();dX=mx.array(X);dy=mx.array(y);dw=None if weights is None else mx.array(weights,mx.float32);mx.eval(*[a for a in (dX,dy,dw) if a is not None]);mx.synchronize();upload=(time.perf_counter()-t)*1000
       arrays=(dX,dy,dw); models={v:[] for v in variants};records={v:[] for v in variants}
       for i in range(args.warmups+args.repeats):
        order=variants[i%len(variants):]+variants[:i%len(variants)]
        if i%2:order=order[::-1]
        for name in order:
         model,meta=fit_once(name,X,y,weights,case,arrays)
         if i>=args.warmups:models[name].append(model);records[name].append(meta)
       refscore,refpred=independent_score(models['sklearn'][-1],X,y,weights,case.C,ratio)
       stock_warnings=records['sklearn'][-1]['warnings']
       refinfo={'kind':'stock','score':refscore,'warnings':stock_warnings}
       if (not math.isfinite(refscore['gradient_max_abs_float64']) or refscore['gradient_max_abs_float64']>1e-4
               or any(w['category']=='ConvergenceWarning' for w in stock_warnings)):
        center=X.mean(axis=0,dtype=np.float64);centered=np.asarray(X,dtype=np.float64)-center
        with warnings.catch_warnings(record=True) as caught:
         warnings.simplefilter('always');ref=SkLR(C=case.C,tol=1e-9,max_iter=3000).fit(centered,y,sample_weight=weights)
        transformed=SimpleNamespace(coef_=ref.coef_,intercept_=ref.intercept_-ref.coef_@center)
        refscore,refpred=independent_score(transformed,X,y,weights,case.C,ratio)
        refinfo={'kind':'centered_tight','score':refscore,'warnings':[{'category':x.category.__name__,'message':str(x.message)} for x in caught]}
        del centered
       refvalid=math.isfinite(refscore['objective_float64']) and math.isfinite(refscore['gradient_max_abs_float64']) and refscore['gradient_max_abs_float64']<=1e-4 and not any(w['category']=='ConvergenceWarning' for w in refinfo['warnings'])
       for name in variants:
        for m,meta in zip(models[name],records[name],strict=True):
         q,_=independent_score(m,X,y,weights,case.C,ratio,(refscore['objective_float64'],refpred));meta['quality']=q
       matches={variant:[equal_parameters(a,b) for a,b in zip(models[reference],models[variant],strict=True)]
                for reference,variant in [('current','fast'),('device_current','device_fast')]}
       audit=[]
       if not refvalid:audit.append({'variant':'reference','fit':None,'issues':['reference not trustworthy']})
       for reference,variant in [('current','fast'),('device_current','device_fast')]:
        base=records[reference][-1]['quality']['objective_float64']
        for i,meta in enumerate(records[variant]):
         q=meta['quality'];delta=(q['objective_float64']-base)/max(abs(base),np.finfo(float).tiny)
         issues=[]
         if meta['warnings'] or (variant.startswith('device') and not meta.get('converged',True)):issues.append('reported nonconvergence')
         if meta['sketch_counts'] != [4]:issues.append('four sketch pairs not exercised')
         if not matches[variant][i]:issues.append('model differs bitwise from control')
         if not math.isfinite(q['gradient_max_abs_float64']) or q['gradient_max_abs_float64']>1e-4:issues.append('gradient')
         if not math.isfinite(delta) or delta>1e-5:issues.append('objective vs current')
         if refvalid and (not math.isfinite(q['objective_relative_gap_to_sklearn']) or q['objective_relative_gap_to_sklearn']>1e-5):issues.append('objective vs reference')
         if refvalid and (not math.isfinite(q['prediction_agreement_sklearn']) or q['prediction_agreement_sklearn']<.995):issues.append('prediction agreement')
         if ratio is not None and (not math.isfinite(q['nullspace_coefficient_relative']) or q['nullspace_coefficient_relative']>1e-3):issues.append('nullspace')
         if issues:audit.append({'variant':variant,'fit':i,'issues':issues})
       row={'case':case.name,'seed':case.seed,'shape':[case.rows,case.features],'reference':refinfo,'upload_ms':upload,'median_ms':{v:statistics.median(x['ms'] for x in records[v]) for v in variants},
            'paired_wins':{'host':sum(a['ms']<b['ms'] for a,b in zip(records['fast'],records['current'],strict=True)),'device':sum(a['ms']<b['ms'] for a,b in zip(records['device_fast'],records['device_current'],strict=True))},
            'bitwise_model_equal':matches,'audit_failures':audit,'records':records}
       out['cases'].append(row);print(case.name,{v:round(x,3) for v,x in row['median_ms'].items()},'wins',row['paired_wins'],'matches', {k:sum(v) for k,v in matches.items()},'failure',audit[:2],flush=True)
       Path('bench/sketch_all_valid/results.partial.json').write_text(json.dumps(out,indent=2)+'\n')
       del X,y,weights,arrays,dX,dy,dw,models;mx.clear_cache()
    out['source_after']=source_hashes();out['source_integrity_pass']=before==out['source_after'];out['all_quality_pass']=all(not c['audit_failures'] for c in out['cases'])
    Path('bench/sketch_all_valid/results.json').write_text(json.dumps(out,indent=2)+'\n');return int(not out['source_integrity_pass'] or not out['all_quality_pass'])
if __name__=='__main__':raise SystemExit(main())
