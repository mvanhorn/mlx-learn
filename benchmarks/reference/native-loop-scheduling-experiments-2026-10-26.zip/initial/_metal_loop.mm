// Optional native command-buffer loop for wide binary logistic regression.
// The only foreign resources are evaluated Metal DLPack buffers held by the
// calling Python frame until after every command buffer has completed.
#define PY_SSIZE_T_CLEAN
#include <Python.h>
#import <Foundation/Foundation.h>
#import <Metal/Metal.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <list>
#include <memory>
#include <mutex>
#include <unordered_map>
#include <stdexcept>
#include <string>
#include <vector>

static std::atomic<int> scratch_mode{0};

struct DLDevice { int device_type, device_id; };
struct DLDataType { uint8_t code, bits; uint16_t lanes; };
struct DLTensor {
    void* data; DLDevice device; int ndim; DLDataType dtype;
    int64_t* shape; int64_t* strides; uint64_t byte_offset;
};
struct DLManagedTensor { DLTensor dl_tensor; void* manager_ctx; void (*deleter)(DLManagedTensor*); };

struct ReleaseGIL {
    PyThreadState* state;
    ReleaseGIL() : state(PyEval_SaveThread()) {}
    ~ReleaseGIL() { PyEval_RestoreThread(state); }
};

struct ExternalBuffer { id<MTLBuffer> buffer; NSUInteger offset; };

static ExternalBuffer tensor(PyObject* capsules, Py_ssize_t index, const std::vector<int64_t>& shape) {
    PyObject* capsule = PyTuple_GetItem(capsules, index);
    if (!capsule) throw std::runtime_error("missing Metal DLPack capsule");
    auto* managed = static_cast<DLManagedTensor*>(PyCapsule_GetPointer(capsule, "dltensor"));
    if (!managed) throw std::runtime_error("invalid Metal DLPack capsule");
    const DLTensor& t = managed->dl_tensor;
    if (t.device.device_type != 8 || t.device.device_id != 0 || t.dtype.code != 2 ||
        t.dtype.bits != 32 || t.dtype.lanes != 1 || t.ndim != int(shape.size()) || !t.data)
        throw std::runtime_error("native loop requires float32 Metal DLPack tensors");
    int64_t size = 1;
    for (int i = t.ndim - 1; i >= 0; --i) {
        if (t.shape[i] != shape[i] || (t.strides && t.strides[i] != size))
            throw std::runtime_error("native loop requires contiguous Metal tensors");
        size *= t.shape[i];
    }
    id<MTLBuffer> buffer = (__bridge id<MTLBuffer>)t.data;
    if (![buffer conformsToProtocol:@protocol(MTLBuffer)] || t.byte_offset % 4 ||
        t.byte_offset > buffer.length || uint64_t(size) * 4 > buffer.length - t.byte_offset)
        throw std::runtime_error("invalid Metal buffer extent");
    return {buffer, NSUInteger(t.byte_offset)};
}

static id<MTLBuffer> create_buffer(id<MTLDevice> device, size_t bytes) {
    id<MTLBuffer> result = [device newBufferWithLength:std::max(bytes, size_t(4))
                                              options:MTLResourceStorageModeShared];
    if (!result || !result.contents) throw std::runtime_error("Metal buffer allocation failed");
    memset(result.contents, 0, result.length);
    return result;
}

struct Pipelines {
    id<MTLDevice> device;
    id<MTLCommandQueue> queue;
    id<MTLComputePipelineState> direction, speculative, reduce, accept, accept_flag, active, backward, finish, init_parts, init_metric;
};

static std::shared_ptr<Pipelines> pipeline_for(const char* source) {
    static std::mutex lock;
    static std::list<std::string> order;
    static std::unordered_map<std::string, std::pair<std::shared_ptr<Pipelines>, std::list<std::string>::iterator>> cache;
    std::lock_guard<std::mutex> guard(lock);
    auto found=cache.find(source);
    if(found!=cache.end()) {
        order.splice(order.begin(),order,found->second.second);
        return found->second.first;
    }
    auto pl=std::make_shared<Pipelines>();
    pl->device=MTLCreateSystemDefaultDevice();
    if(!pl->device) throw std::runtime_error("no Metal device");
    pl->queue=[pl->device newCommandQueue];
    if(!pl->queue) throw std::runtime_error("Metal command queue creation failed");
    NSError* error=nil;
    id<MTLLibrary> lib=[pl->device newLibraryWithSource:[NSString stringWithUTF8String:source] options:nil error:&error];
    if(!lib) throw std::runtime_error(error.localizedDescription.UTF8String ?: "Metal compilation failed");
    auto make=[&](NSString* name) -> id<MTLComputePipelineState> {
        id<MTLFunction> f=[lib newFunctionWithName:name];
        NSError* pipeline_error=nil;
        id<MTLComputePipelineState> pipeline=f ? [pl->device newComputePipelineStateWithFunction:f error:&pipeline_error] : nil;
        if(!pipeline) throw std::runtime_error(pipeline_error.localizedDescription.UTF8String ?: "Metal pipeline creation failed");
        return pipeline;
    };
    pl->direction=make(@"direction_kernel"); pl->speculative=make(@"speculative_kernel");
    pl->reduce=make(@"reduce_spec"); pl->accept=make(@"accept_kernel"); pl->accept_flag=make(@"accept_flag_kernel");
    pl->active=make(@"make_active"); pl->backward=make(@"backward_kernel"); pl->finish=make(@"finish_grad");
    pl->init_parts=make(@"init_parts"); pl->init_metric=make(@"init_metric");
    order.emplace_front(source);
    cache.emplace(order.front(),std::make_pair(pl,order.begin()));
    if(cache.size()>32){ cache.erase(order.back());order.pop_back(); }
    return pl;
}

struct Slice {
    id<MTLBuffer> buffer; NSUInteger offset;
    void* contents() const { return static_cast<char*>(buffer.contents)+offset; }
};

static void bind(id<MTLComputeCommandEncoder> e, Slice s, NSUInteger i) {
    [e setBuffer:s.buffer offset:s.offset atIndex:i];
}
static void bind(id<MTLComputeCommandEncoder> e, id<MTLBuffer> b, NSUInteger i, NSUInteger offset=0) {
    [e setBuffer:b offset:offset atIndex:i];
}
static void dispatch(id<MTLComputeCommandEncoder> e, id<MTLComputePipelineState> p, NSUInteger count, NSUInteger width=128) {
    [e setComputePipelineState:p];
    [e dispatchThreads:MTLSizeMake(count,1,1) threadsPerThreadgroup:MTLSizeMake(width,1,1)];
    [e memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static PyObject* run(PyObject*, PyObject* args) {
    const char* source; PyObject* capsules;
    int n,d,p,m,blocks,groups,max_iter;
    double denom_d,tol_d,c1_d,mincurv_d,l2_d;
    if (!PyArg_ParseTuple(args,"sOiiiiiiiddddd",&source,&capsules,&n,&d,&p,&m,&blocks,&groups,&max_iter,&denom_d,&tol_d,&c1_d,&mincurv_d,&l2_d)) return nullptr;
    int mode=scratch_mode.load();
    if (!PyTuple_Check(capsules) || PyTuple_Size(capsules)!=((mode&8)?4:6) || n<=0 || d<=0 || p!=d+1 ||
        m<=0 || blocks<=0 || groups<=0 || max_iter<=0) {
        PyErr_SetString(PyExc_ValueError,"invalid native command loop arguments"); return nullptr;
    }
    @autoreleasepool {
      @try {
       try {
        ExternalBuffer X=tensor(capsules,0,{n,d}), y=tensor(capsules,1,{n}), sw=tensor(capsules,2,{n});
        int nb=(n+255)/256;
        ExternalBuffer initial{},h0{},reg{},parts{};
        if(mode&8) parts=tensor(capsules,3,{2,nb,p});
        else { initial=tensor(capsules,3,{p}); h0=tensor(capsules,4,{p}); reg=tensor(capsules,5,{p}); }
        auto pl = pipeline_for(source);
        id<MTLDevice> device=pl->device;
        if (X.buffer.device != device || y.buffer.device != device || sw.buffer.device != device ||
            ((mode&8)?parts.buffer.device!=device:(initial.buffer.device != device || h0.buffer.device != device || reg.buffer.device != device)))
            throw std::runtime_error("DLPack buffers belong to a different Metal device");
        size_t total=2*(size_t(p)*8+size_t(m)*p*8+size_t(m)*8+40+size_t(n)*4)
            +size_t(p)*12+40+size_t(n)*8+size_t(8)*blocks*4+size_t(blocks)*p*4
            +32+size_t(nb)*p*4+4+32*256 + ((mode&8)?(size_t(p)*12+768):0);
        id<MTLBuffer> arena=create_buffer(device,total);
        size_t cursor=0;
        auto alloc=[&](size_t size) -> Slice {
            cursor=(cursor+255)&~size_t(255);
            if(size>total-cursor) throw std::runtime_error("Metal arena exhausted");
            Slice result={arena,cursor};cursor+=size;return result;
        };
        Slice w[2],g[2],hs[2],hy[2],hc[2],meta[2],raw[2];
        for(int i=0;i<2;++i) {
          w[i]=alloc(size_t(p)*4);g[i]=alloc(size_t(p)*4);
          hs[i]=alloc(size_t(m)*p*4);hy[i]=alloc(size_t(m)*p*4);
          hc[i]=alloc(size_t(m)*2*4);meta[i]=alloc(40);raw[i]=alloc(size_t(n)*4);
        }
        Slice diagonal{};
        if(mode&8){
          Slice regbuf=alloc(size_t(p)*4),h0buf=alloc(size_t(p)*4);diagonal=alloc(size_t(p)*4);
          float* rr=static_cast<float*>(regbuf.contents());
          for(int i=0;i<p;++i) rr[i]=i<d?float(l2_d):0.0f;
          reg={regbuf.buffer,regbuf.offset};h0={h0buf.buffer,h0buf.offset};
        } else {
          if (!initial.buffer.contents) throw std::runtime_error("initial gradient buffer is not CPU-visible");
          memcpy(g[0].contents(),static_cast<const char*>(initial.buffer.contents)+initial.offset,size_t(p)*4);
          memcpy(g[1].contents(),g[0].contents(),size_t(p)*4);
        }
        auto direction=alloc(size_t(p)*4), stats=alloc(40);
        auto dr=alloc(size_t(n)*4), partial=alloc(size_t(8)*blocks*4);
        auto gradparts=alloc(size_t(blocks)*p*4), diffs=alloc(32);
        auto first=alloc(size_t(p)*4), residual=alloc(size_t(n)*4);
        auto backparts=alloc(size_t(nb)*p*4), flag=alloc(4);
        float denom=float(denom_d),tol=float(tol_d),c1=float(c1_d),mincurv=float(mincurv_d),alpha=1,l2=float(l2_d);
        int cur=0,n_iter=0,status=0,n_fev=0;
        std::string failure;
        {
        ReleaseGIL released;
        id<MTLCommandBuffer> pending = nil;
        @try {
        while (n_iter<max_iter) {
          @autoreleasepool {
            id<MTLCommandBuffer> cb=[pl->queue commandBuffer];
            if (!cb) { failure="Metal command buffer creation failed"; break; }
            id<MTLComputeCommandEncoder> e=[cb computeCommandEncoder];
            if (!e) { failure="Metal compute encoder creation failed"; break; }
            if((mode&8) && n_iter==0){
              bind(e,parts.buffer,0,parts.offset);[e setBytes:&denom length:4 atIndex:1];
              [e setBytes:&l2 length:4 atIndex:2];bind(e,g[0],3);bind(e,diagonal,4);
              dispatch(e,pl->init_parts,NSUInteger((p+31)/32)*128,128);
              bind(e,diagonal,0);bind(e,h0.buffer,1,h0.offset);
              dispatch(e,pl->init_metric,128,128);
            }
            int desired=8;
            if ((mode&3)!=0 && n_iter>0) desired=n_iter==8 ? (mode&3) : 4;
            int chunk=std::min(desired,max_iter-n_iter);
            for(int k=0;k<chunk;++k) {
              int next=1-cur;
              bind(e,w[cur],0);bind(e,g[cur],1);bind(e,w[next],2);bind(e,g[next],3);
              bind(e,hs[cur],4);bind(e,hy[cur],5);bind(e,hc[cur],6);bind(e,meta[cur],7);
              bind(e,reg.buffer,8,reg.offset);[e setBytes:&tol length:4 atIndex:9];bind(e,h0.buffer,10,h0.offset);
              [e setBytes:&mincurv length:4 atIndex:11];[e setBytes:&alpha length:4 atIndex:12];
              bind(e,direction,13);bind(e,hs[next],14);bind(e,hy[next],15);bind(e,hc[next],16);bind(e,stats,17);
              dispatch(e,pl->direction,32,32);
              bind(e,X.buffer,0,X.offset);bind(e,direction,1);bind(e,raw[cur],2);bind(e,y.buffer,3,y.offset);
              bind(e,sw.buffer,4,sw.offset);bind(e,stats,5);[e setBytes:&denom length:4 atIndex:6];
              bind(e,dr,7);bind(e,partial,8);bind(e,gradparts,9);
              dispatch(e,pl->speculative,NSUInteger(blocks)*groups*32,groups*32);
              bind(e,partial,0);bind(e,gradparts,1);[e setBytes:&denom length:4 atIndex:2];bind(e,diffs,3);bind(e,first,4);
              dispatch(e,pl->reduce,NSUInteger((p+31)/32)*128,128);
              bind(e,w[cur],0);bind(e,raw[cur],1);bind(e,direction,2);bind(e,dr,3);bind(e,y.buffer,4,y.offset);
              bind(e,sw.buffer,5,sw.offset);bind(e,stats,6);bind(e,diffs,7);[e setBytes:&c1 length:4 atIndex:8];
              bind(e,w[next],9);bind(e,raw[next],10);bind(e,residual,11);bind(e,meta[next],12);
              if (mode&4) { bind(e,flag,13); dispatch(e,pl->accept_flag,std::max(n,p),256); }
              else { dispatch(e,pl->accept,std::max(n,p),256);
                bind(e,meta[next],0);[e setBytes:&alpha length:4 atIndex:1];bind(e,flag,2);
                dispatch(e,pl->active,1,1); }
              bind(e,X.buffer,0,X.offset);bind(e,residual,1);bind(e,flag,2);bind(e,backparts,3);
              [e setComputePipelineState:pl->backward];
              [e dispatchThreadgroups:MTLSizeMake((p+31)/32,nb,1) threadsPerThreadgroup:MTLSizeMake(128,1,1)];
              [e memoryBarrierWithScope:MTLBarrierScopeBuffers];
              bind(e,backparts,0);bind(e,first,1);bind(e,meta[next],2);[e setBytes:&alpha length:4 atIndex:3];
              bind(e,g[cur],4);bind(e,w[next],5);bind(e,reg.buffer,6,reg.offset);
              [e setBytes:&denom length:4 atIndex:7];bind(e,g[next],8);dispatch(e,pl->finish,p);
              cur=next;
            }
            [e endEncoding];pending=cb;[cb commit];[cb waitUntilCompleted];pending=nil;
            if(cb.status != MTLCommandBufferStatusCompleted) {
              failure = cb.error.localizedDescription.UTF8String ?: "Metal command buffer failed"; break;
            }
            float* h=static_cast<float*>(meta[cur].contents());
            n_iter=int(h[0]);status=int(h[1]);n_fev=int(h[9]);
            float maxgrad=0;const float* grad=static_cast<const float*>(g[cur].contents());
            for(int i=0;i<p;++i) maxgrad=std::max(maxgrad,std::abs(grad[i]));
            if(status==0 && maxgrad<=tol) status=1;
            if(status!=0) break;
          }
        }
        } @catch (NSException* exception) {
          failure = exception.reason.UTF8String ?: "Metal command encoding exception";
          // If submission occurred, keep the producer capsules alive until the
          // submitted GPU work finishes even when an Objective-C API throws.
          @try {
            if (pending && pending.status >= MTLCommandBufferStatusCommitted &&
                pending.status < MTLCommandBufferStatusCompleted)
              [pending waitUntilCompleted];
          } @catch (NSException* wait_exception) {
            failure += "; failed to wait for the submitted Metal command buffer";
          }
        }
        }
        if(!failure.empty()) throw std::runtime_error(failure);
        PyObject* bytes=PyBytes_FromStringAndSize(static_cast<const char*>(w[cur].contents()),Py_ssize_t(p)*4);
        if (!bytes) return nullptr;
        PyObject* result=Py_BuildValue("Niii",bytes,n_iter,status,n_fev);
        return result;
       } catch(const std::exception& e) {
        if (!PyErr_Occurred()) PyErr_SetString(PyExc_RuntimeError,e.what());
        return nullptr;
       }
      } @catch (NSException* exception) {
        PyErr_SetString(PyExc_RuntimeError, exception.reason.UTF8String ?: "Metal API exception");
        return nullptr;
      }
    }
}

static PyObject* set_scratch_mode(PyObject*, PyObject* args) { int value; if(!PyArg_ParseTuple(args,"i",&value)) return nullptr; scratch_mode.store(value); Py_RETURN_NONE; }
static PyObject* get_scratch_mode(PyObject*, PyObject*) { return PyLong_FromLong(scratch_mode.load()); }
static PyMethodDef methods[]={{"get_scratch_mode",get_scratch_mode,METH_NOARGS,"Get scratch test mode."},{"run",run,METH_VARARGS,"Execute a bounded Metal L-BFGS loop."},{"set_scratch_mode",set_scratch_mode,METH_VARARGS,"Set scratch test mode."},{nullptr,nullptr,0,nullptr}};
static struct PyModuleDef module={PyModuleDef_HEAD_INIT,"_metal_loop",nullptr,-1,methods,nullptr,nullptr,nullptr,nullptr};
PyMODINIT_FUNC PyInit__metal_loop(void) { return PyModule_Create(&module); }
