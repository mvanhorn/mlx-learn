import argparse
import json
import statistics
from pathlib import Path

from benchmarks.logistic_gpu import Case, make_data, quality
from benchmarks.logistic_wide import fit_once, frozen_reference
from mlxlearn._solvers import native_command
from threadpoolctl import threadpool_limits

ap=argparse.ArgumentParser();ap.add_argument('--repeats',type=int,default=16);ap.add_argument('--warmup',type=int,default=2);ap.add_argument('--out',default='modes.json');args=ap.parse_args()
modes={'previous_native':None,'mode1':1,'mode9':9,'sklearn':None}
names=tuple(modes)
def order(i):
 b=names if i%2==0 else names[::-1];k=(i//2)%len(names);return b[k:]+b[:k]
def fit(name, X,y,sw,ref):
 if name.startswith('mode'):
  native_command._metal_loop.set_scratch_mode(modes[name]); mode='optimized_gpu'
 else: mode=name
 return fit_once(mode,X,y,sw,reference=ref,max_iter=200,tol=1e-4)
output=[]
with threadpool_limits(1),frozen_reference(archive=Path('benchmarks/reference/overhead-logistic-2026-10-26.zip')) as ref:
 for dtype in ['float32','float64']:
  for weighted in [False,True]:
   c=Case('target_weighted' if weighted else 'target',20000,1024,weighted=weighted)
   X,y,sw=make_data(c,41,dtype=dtype);samples={k:[] for k in names}; details={k:[] for k in names};models={}
   for j in range(args.warmup):
    for name in order(j): fit(name,X,y,sw,ref)
   for j in range(args.repeats):
    for name in order(j):
     elapsed,model,metadata=fit(name,X,y,sw,ref)
     samples[name].append(elapsed*1000);details[name].append(metadata);models[name]=model
   scores={k:quality(v,models['sklearn'],X,y,sw) for k,v in models.items()}
   for name in names:
    if name in ('sklearn','previous_native'):continue
    for detail in details[name]:
     assert detail['implementation']=='native_command_loop',detail
     assert not detail['warnings'],detail
     for s in detail['solutions']+detail['solver_calls']:
      assert s['converged'] and s['stop_reason']=='gtol' and s['grad_max_abs']<=1e-4,s
    assert scores[name]['gradient_max_abs_float64']<=1e-4,scores[name]
    assert scores[name]['objective_relative_gap_to_sklearn']<=1e-5,scores[name]
    assert scores[name]['prediction_agreement_sklearn']>=.995,scores[name]
   item={'dtype':dtype,'weighted':weighted,'orders':[order(i) for i in range(args.repeats)],'samples_ms':samples,'details':details,'quality':scores}
   output.append(item);Path(args.out).write_text(json.dumps(output,indent=2)+'\n')
   print(dtype,weighted,{k:round(statistics.median(v),3) for k,v in samples.items()},flush=True)
   print('paired_wins_vs_mode1',{k:sum(b<a for a,b in zip(samples['mode1'],v)) for k,v in samples.items() if k.startswith('mode')},flush=True)
