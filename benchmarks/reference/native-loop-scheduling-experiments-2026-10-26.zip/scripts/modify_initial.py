from pathlib import Path
p=Path('src/mlxlearn/_solvers/native_command.py');s=p.read_text()
needle='    header += r"""\nkernel void reduce_spec'
assert needle in s
s=s.replace(needle,'''    header += r"""
kernel void init_parts(device const float* parts [[buffer(0)]],
                       constant float& denom [[buffer(1)]],
                       constant float& l2 [[buffer(2)]],
                       device float* gradient [[buffer(3)]],
                       device float* diagonal [[buffer(4)]],
                       uint t [[thread_position_in_threadgroup]],
                       uint group [[threadgroup_position_in_grid]]) {
 const uint nb=(N+255)/256, lane=t%32, sg=t/32, col=group*32+lane;
 float g=0, h=0;
 if(col<P)for(uint i=sg;i<nb;i+=4){g+=parts[ulong(i)*P+col];h+=parts[ulong(nb+i)*P+col];}
 threadgroup float gs[128], hs[128]; gs[t]=g;hs[t]=h;
 threadgroup_barrier(mem_flags::mem_threadgroup);
 if(sg==0 && col<P){gradient[col]=(gs[t]+gs[t+32]+gs[t+64]+gs[t+96])/denom;
  diagonal[col]=(hs[t]+hs[t+32]+hs[t+64]+hs[t+96])/denom + (col<D?l2:0.0f);}
}
kernel void init_metric(device const float* diagonal [[buffer(0)]],
                        device float* h0 [[buffer(1)]],
                        uint t [[thread_position_in_threadgroup]]) {
 float x=0; for(uint j=t;j<P;j+=128)x+=diagonal[j];
 x=simd_sum(x); threadgroup float shared[4],scale;
 if(t%32==0)shared[t/32]=x;
 threadgroup_barrier(mem_flags::mem_threadgroup);
 if(t==0){float d=(shared[0]+shared[1]+shared[2]+shared[3])/float(P);
  scale=isfinite(d)&&d>1e-12f?1.0f/d:1.0f;}
 threadgroup_barrier(mem_flags::mem_threadgroup);
 for(uint j=t;j<P;j+=128)h0[j]=scale;
}
kernel void reduce_spec''')
old='''    from .native_logistic import initial_from_parts

    p = d + 1'''
new='''    p = d + 1'''
assert old in s;s=s.replace(old,new)
old='''    reg = mx.concatenate([mx.full(d, l2, dtype=mx.float32), mx.zeros(1, dtype=mx.float32)])
    denom = mx.array(sw_sum, dtype=mx.float32)
    g, h0 = initial_from_parts(initial_parts, reg, denom)
    # Export synchronizes the producer; keep every capsule and array alive
    # until the native command buffer has finished executing.
    mx.eval(X, y, sw, g, h0, reg)
    mx.synchronize()
    capsules = tuple(value.__dlpack__() for value in (X, y, sw, g, h0, reg))'''
new='''    native_init = bool(_metal_loop.get_scratch_mode() & 8)
    if native_init:
        arrays = (X, y, sw, initial_parts)
    else:
        from .native_logistic import initial_from_parts
        reg = mx.concatenate([mx.full(d, l2, dtype=mx.float32), mx.zeros(1, dtype=mx.float32)])
        denom = mx.array(sw_sum, dtype=mx.float32)
        g, h0 = initial_from_parts(initial_parts, reg, denom)
        arrays = (X, y, sw, g, h0, reg)
    # The frame retains arrays and capsules through the synchronous completion.
    mx.eval(*arrays)
    mx.synchronize()
    capsules = tuple(value.__dlpack__() for value in arrays)'''
assert old in s;s=s.replace(old,new)
old='''config.max_iter, float(np.float32(sw_sum)), float(tol), config.c1, config.min_curvature)'''
new='''config.max_iter, float(np.float32(sw_sum)), float(tol), config.c1, config.min_curvature, float(np.float32(l2)))'''
assert old in s;s=s.replace(old,new);p.write_text(s)
p=Path('src/mlxlearn/_solvers/_metal_loop.mm');s=p.read_text()
s=s.replace('direction, speculative, reduce, accept, accept_flag, active, backward, finish;', 'direction, speculative, reduce, accept, accept_flag, active, backward, finish, init_parts, init_metric;')
s=s.replace('pl->active=make(@"make_active"); pl->backward=make(@"backward_kernel"); pl->finish=make(@"finish_grad");','pl->active=make(@"make_active"); pl->backward=make(@"backward_kernel"); pl->finish=make(@"finish_grad");\n    pl->init_parts=make(@"init_parts"); pl->init_metric=make(@"init_metric");')
s=s.replace('double denom_d,tol_d,c1_d,mincurv_d;', 'double denom_d,tol_d,c1_d,mincurv_d,l2_d;')
s=s.replace('"sOiiiiiiidddd",&source,&capsules,&n,&d,&p,&m,&blocks,&groups,&max_iter,&denom_d,&tol_d,&c1_d,&mincurv_d', '"sOiiiiiiiddddd",&source,&capsules,&n,&d,&p,&m,&blocks,&groups,&max_iter,&denom_d,&tol_d,&c1_d,&mincurv_d,&l2_d')
s=s.replace('    if (!PyTuple_Check(capsules) || PyTuple_Size(capsules)!=6 || n<=0', '    int mode=scratch_mode.load();\n    if (!PyTuple_Check(capsules) || PyTuple_Size(capsules)!=((mode&8)?4:6) || n<=0')
old='''        ExternalBuffer initial=tensor(capsules,3,{p}), h0=tensor(capsules,4,{p}), reg=tensor(capsules,5,{p});
        auto pl = pipeline_for(source);'''
new='''        int nb=(n+255)/256;
        ExternalBuffer initial{},h0{},reg{},parts{};
        if(mode&8) parts=tensor(capsules,3,{2,nb,p});
        else { initial=tensor(capsules,3,{p}); h0=tensor(capsules,4,{p}); reg=tensor(capsules,5,{p}); }
        auto pl = pipeline_for(source);'''
assert old in s;s=s.replace(old,new)
old='''        if (X.buffer.device != device || y.buffer.device != device || sw.buffer.device != device ||
            initial.buffer.device != device || h0.buffer.device != device || reg.buffer.device != device)
            throw std::runtime_error("DLPack buffers belong to a different Metal device");
        int nb=(n+255)/256;'''
new='''        if (X.buffer.device != device || y.buffer.device != device || sw.buffer.device != device ||
            ((mode&8)?parts.buffer.device!=device:(initial.buffer.device != device || h0.buffer.device != device || reg.buffer.device != device)))
            throw std::runtime_error("DLPack buffers belong to a different Metal device");'''
assert old in s;s=s.replace(old,new)
s=s.replace('+32+size_t(nb)*p*4+4+32*256;', '+32+size_t(nb)*p*4+4+32*256 + ((mode&8)?(size_t(p)*12+768):0);')
old='''        if (!initial.buffer.contents) throw std::runtime_error("initial gradient buffer is not CPU-visible");
        memcpy(g[0].contents(),static_cast<const char*>(initial.buffer.contents)+initial.offset,size_t(p)*4);
        memcpy(g[1].contents(),g[0].contents(),size_t(p)*4);'''
new='''        Slice diagonal{};
        if(mode&8){
          Slice regbuf=alloc(size_t(p)*4),h0buf=alloc(size_t(p)*4);diagonal=alloc(size_t(p)*4);
          float* rr=static_cast<float*>(regbuf.contents());
          for(int i=0;i<p;++i) rr[i]=i<d?float(l2_d):0.0f;
          reg={regbuf.buffer,regbuf.offset};h0={h0buf.buffer,h0buf.offset};
        } else {
          if (!initial.buffer.contents) throw std::runtime_error("initial gradient buffer is not CPU-visible");
          memcpy(g[0].contents(),static_cast<const char*>(initial.buffer.contents)+initial.offset,size_t(p)*4);
          memcpy(g[1].contents(),g[0].contents(),size_t(p)*4);
        }'''
assert old in s;s=s.replace(old,new)
s=s.replace('float denom=float(denom_d),tol=float(tol_d),c1=float(c1_d),mincurv=float(mincurv_d),alpha=1;', 'float denom=float(denom_d),tol=float(tol_d),c1=float(c1_d),mincurv=float(mincurv_d),alpha=1,l2=float(l2_d);')
s=s.replace('int mode=scratch_mode.load();\n        std::string failure;', 'std::string failure;')
needle='''            int desired=8;
'''
insert='''            if((mode&8) && n_iter==0){
              bind(e,parts.buffer,0,parts.offset);[e setBytes:&denom length:4 atIndex:1];
              [e setBytes:&l2 length:4 atIndex:2];bind(e,g[0],3);bind(e,diagonal,4);
              dispatch(e,pl->init_parts,NSUInteger((p+31)/32)*128,128);
              bind(e,diagonal,0);bind(e,h0.buffer,1,h0.offset);
              dispatch(e,pl->init_metric,128,128);
            }
            int desired=8;
'''
assert needle in s;s=s.replace(needle,insert)
s=s.replace('static PyMethodDef methods[]={{"run",run', 'static PyObject* get_scratch_mode(PyObject*, PyObject*) { return PyLong_FromLong(scratch_mode.load()); }\nstatic PyMethodDef methods[]={{"get_scratch_mode",get_scratch_mode,METH_NOARGS,"Get scratch test mode."},{"run",run')
p.write_text(s)
