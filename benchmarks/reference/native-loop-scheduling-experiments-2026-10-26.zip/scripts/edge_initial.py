import json, warnings
from pathlib import Path
import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression as Sk
from threadpoolctl import threadpool_limits
from mlxlearn._common.config import tuning_context
from mlxlearn.linear_model import LogisticRegression
from mlxlearn.linear_model import _logistic as estimator
from mlxlearn._solvers import native_command

estimator._CENTERED_INPUT_MIN_ELEMENTS=1
rng=np.random.default_rng(461)
def make(kind):
 n,d=(516,519) if kind.startswith('near_tolerance') else (1027,520)
 X=rng.normal(size=(n,d)).astype(np.float32)
 y=(X[:,0]+rng.normal(scale=.5,size=n)>0).astype(int)
 weights=None
 if kind=='offset': X += np.float32(1000)
 if kind=='ill_conditioned':
  X[:,d//2:] = .999*X[:,:d//2]+.001*X[:,d//2:]
  X *= np.logspace(-1,1,d,dtype=np.float32)
 if kind=='zero_weight':
  weights=rng.uniform(.25,3,n).astype(np.float32); weights[::2]=0
 if kind.startswith('near_tolerance'):
  y=np.tile([0,1],n//2)
  base=np.max(np.abs((.5-y.astype(np.float64))@X.astype(np.float64)/n))
  factor=.9995 if kind.endswith('below') else 1.0005
  X *= np.float32(1e-4*factor/base)
 return X,y,weights

def metrics(model,X,y,w):
 xx=X.astype(np.float64);raw=xx@model.coef_[0]+model.intercept_[0];r=expit(raw)-y
 if w is None: sw=float(len(y));weighted=np.ones(len(y))
 else: weighted=w.astype(np.float64);sw=float(weighted.sum())
 g=(r*weighted)@xx/sw+model.coef_[0]/sw
 g=np.r_[g,(r*weighted).sum()/sw]
 obj=float((weighted*np.logaddexp(0,(1-2*y)*raw)).sum()/sw+np.sum(model.coef_[0]**2)/(2*sw))
 return {'grad_max':float(np.max(np.abs(g))),'objective':obj,'coef_max':float(np.max(np.abs(model.coef_))),'n_iter':model.n_iter_.tolist()}

out=[]
with threadpool_limits(1),tuning_context(force_backend='mlx'):
 for kind in ('zero_weight','ill_conditioned','near_tolerance_below','near_tolerance_above','offset'):
  X,y,w=make(kind); models={};detail={}
  for mode in (1,9):
   native_command._metal_loop.set_scratch_mode(mode);calls=[]
   original=native_command.run_native_loop
   def wrap(*args,**kwargs):
    result=original(*args,**kwargs);calls.append(result is not None);return result
   native_command.run_native_loop=wrap
   with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always'); model=LogisticRegression(max_iter=200,tol=1e-4).fit(X,y,sample_weight=w)
   native_command.run_native_loop=original
   models[mode]=model;detail[str(mode)]=metrics(model,X,y,w);detail[str(mode)].update(native_completed=calls,warnings=[str(a.message) for a in caught])
  with warnings.catch_warnings(record=True) as caught:
   warnings.simplefilter('always'); ref=Sk(max_iter=200,tol=1e-4).fit(X,y,sample_weight=w)
  detail['sklearn']=metrics(ref,X,y,w);detail['sklearn']['warnings']=[str(a.message) for a in caught]
  d=detail['9']['objective']-detail['1']['objective'];detail['objective_difference_new_old']=d
  out.append({'case':kind,'details':detail});Path('initial-edge.json').write_text(json.dumps(out,indent=2)+'\n')
  print(kind,json.dumps(detail),flush=True)
