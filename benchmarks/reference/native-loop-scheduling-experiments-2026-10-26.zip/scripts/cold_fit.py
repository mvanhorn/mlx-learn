import argparse,json
from pathlib import Path
from benchmarks.logistic_gpu import Case, make_data
from benchmarks.logistic_wide import fit_once,frozen_reference
from mlxlearn._solvers import native_command
from threadpoolctl import threadpool_limits
p=argparse.ArgumentParser();p.add_argument('variant',choices=['previous_native','native_adaptive']);p.add_argument('--dtype',default='float32');p.add_argument('--weighted',action='store_true');a=p.parse_args()
X,y,sw=make_data(Case('target',20000,1024,weighted=a.weighted),41,a.dtype)
if a.variant=='native_adaptive':native_command._metal_loop.set_scratch_mode(1)
with threadpool_limits(1),frozen_reference(archive=Path('benchmarks/reference/overhead-logistic-2026-10-26.zip')) as ref:
 elapsed,model,detail=fit_once('optimized_gpu' if a.variant=='native_adaptive' else 'previous_native',X,y,sw,reference=ref,max_iter=200,tol=1e-4)
print(json.dumps({'variant':a.variant,'dtype':a.dtype,'weighted':a.weighted,'fit_ms':elapsed*1000,'detail':detail}))
