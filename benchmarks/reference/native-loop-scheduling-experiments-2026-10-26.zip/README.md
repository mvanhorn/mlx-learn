# Native-loop scheduling and initialization experiments

These are benchmark-only scratch variants, not the production extension. Start from
`benchmarks/reference/metal-command-final-prototype-2026-10-26.zip`, which contains
the complete package, build script and frozen previous implementation. That archive's
SHA-256 is 2dae1d663d33f50a9d45e5cefa4eb51fc4b04691f651c864e7ed72ab5c9ef031.
The original measured extension binary is not archived; the scratch extension's
measurement-time binary hash was not recorded, so source/binary correspondence has
not been independently verified at measurement time.

The schedule variant includes instrumented scratch-only `set_scratch_mode` values:
0 = original eight-step chunks, 1 = first eight, then one, then four; 2 = first eight,
then two, then four; 4 = original chunks and fused acceptance flag; 5 and 6 combine
flag fusion with mode 1 and 2. The flag-fusion candidates were not retained.
`run_modes.py` measures the old frozen solver, all six modes, and sklearn; its 32
repeats use every one of the sixteen alternating/reversed rotations twice. Each mode
records per-fit metadata and every order, with no filtering. Independent float64
quality scoring runs after all timed fits for that case. First-fit measurements in
`cold_fit.py` begin after package import, data creation and GPU synchronization;
they include shader compilation and are fresh-process fits, not full process startup.

The initialization variant adds mode 9: mode 1 plus native reduction of prepared
initial gradient and diagonal parts using the same scalar trace preconditioner.
`run_initial.py` compares mode 1, mode 9, the frozen solver and sklearn; all timed
native fits check route/gtol/warnings and the final fit per case receives independent
float64 gradient, objective and prediction checks. `edge_initial.py` compares zero
weights, an ill-conditioned design, true gradients immediately above/below tolerance,
and an offset design. In that offset design, the original-coordinate gradient is
already much larger than tol in both paths; it is not evidence of sklearn parity.
The initial reduction changed accumulation order and was not retained due to mixed
complete-fit results.

The synchronization variant adds mode 17: mode 1 without the extra `mx.synchronize`
after `mx.eval` of every exported buffer. Mode 1 retains both calls. MLX eval remains
the producer completion boundary; consumer-side and ownership cleanup are unchanged.
The timings did not show a dependable benefit, so the explicit synchronize was retained.
Official `eval` waits on outputs or the evaluator synchronizer in MLX v0.29 through
v0.32; see https://github.com/ml-explore/mlx/blob/v0.29.0/mlx/transforms.cpp#L284-L297
and https://github.com/ml-explore/mlx/blob/v0.32.2/mlx/transforms.cpp#L343-L357 .
MLX v0.29-0.31 use a different DLPack exporter than 0.32, so this source-only
experiment was run only on MLX 0.32.2 and does not establish older-version safety.

Reproduction on compatible Apple Silicon with Python, MLX and Xcode installed:

```bash
experiment_dir=$(mktemp -d)
unzip -q benchmarks/reference/metal-command-final-prototype-2026-10-26.zip -d "$experiment_dir"
unzip -q benchmarks/reference/native-loop-scheduling-experiments-2026-10-26.zip -d "$experiment_dir"
cd "$experiment_dir"
cp schedule/native_command.py src/mlxlearn/_solvers/native_command.py
cp schedule/_metal_loop.mm src/mlxlearn/_solvers/_metal_loop.mm
python3 setup.py build_ext --inplace --force
PYTHONPATH="$PWD:$PWD/src" python3 scripts/run_modes.py --repeats 32 --warmup 3 --out modes.json
PYTHONPATH="$PWD:$PWD/src" python3 scripts/cold_fit.py native_adaptive --weighted
cp initial/native_command.py src/mlxlearn/_solvers/native_command.py
cp initial/_metal_loop.mm src/mlxlearn/_solvers/_metal_loop.mm
python3 setup.py build_ext --inplace --force
PYTHONPATH="$PWD:$PWD/src" python3 scripts/run_initial.py --repeats 32 --warmup 3 --out initial.json
PYTHONPATH="$PWD:$PWD/src" python3 scripts/edge_initial.py
cp synchronization/native_command.py src/mlxlearn/_solvers/native_command.py
PYTHONPATH="$PWD:$PWD/src" python3 scripts/run_sync.py --repeats 32 --warmup 3 --out sync.json
```
