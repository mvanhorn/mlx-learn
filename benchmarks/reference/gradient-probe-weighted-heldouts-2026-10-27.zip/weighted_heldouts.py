"""Stress the initial-gradient Hessian probe only on weighted 1024 designs.

Compares complete sklearn-compatible fits, including preparation and scoring,
against the unseeded current solver, four-pair solver and sklearn. Candidate
sketch-size one is injected only in this standalone process. All measured fits,
warnings, route metadata and independent float64 quality records are retained.
"""

from __future__ import annotations

import contextlib
import gc
import importlib.util
import json
import math
import statistics
import sys
import time
import warnings
from dataclasses import asdict, dataclass, replace
from pathlib import Path

import mlx.core as mx
import numpy as np
from benchmarks.hessian_logistic import independent_score, observed_sketch, sources
from benchmarks.logistic_wide import observed_implementation
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits

import mlxlearn_device.hessian_sketch as sketch
from mlxlearn import config_context
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import logistic, native_logistic
from mlxlearn.linear_model import LogisticRegression
from mlxlearn.linear_model import _logistic as estimator_module

path = Path(__file__).with_name("gradient_probe.py")
spec = importlib.util.spec_from_file_location("gradient_probe_weighted", path)
gp = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = gp
spec.loader.exec_module(gp)


@dataclass(frozen=True)
class Case:
    name: str
    seed: int
    imbalance: bool = False
    zeros: bool = False
    classes: bool = False
    shift: float = 0.0
    exponent: float = 1.0
    duplicate: bool = False
    C: float = 1.0


CASES = tuple(
    Case(name, seed, **options)
    for name, options in (
        ("weighted", {}),
        ("unbalanced", {"imbalance": True}),
        ("class_zero", {"zeros": True, "classes": True}),
        ("shifted", {"shift": 1000.0}),
        ("duplicate_C1", {"duplicate": True}),
        ("duplicate_C1e6", {"duplicate": True, "C": 1e6}),
        ("extreme2", {"exponent": 2.0}),
        ("extreme4", {"exponent": 4.0}),
    )
    for seed in (41, 83, 2027)
)


def dataset(case):
    rng = np.random.default_rng(case.seed)
    n, d = 20_000, 1_024
    X = rng.standard_normal((n, d), dtype=np.float32)
    signal = X[:, 0] + rng.normal(scale=0.5, size=n)
    cutoff = float(np.quantile(signal, 0.98)) if case.imbalance else 0.0
    y = (signal > cutoff).astype(np.int32)
    ratio = None
    if case.duplicate:
        X[:, :512] *= np.logspace(-case.exponent, case.exponent, 512, dtype=np.float32)
        ratio = np.tile(np.array([2.0, 0.5], dtype=np.float32), 256)
        X[:, 512:] = X[:, :512] * ratio
    else:
        X[:, 512:] = X[:, :512] + np.float32(0.01) * X[:, 512:]
        X *= np.logspace(-case.exponent, case.exponent, d, dtype=np.float32)
    if case.shift:
        X += np.float32(case.shift)
    sample_weight = rng.uniform(0.25, 3.0, n)
    if case.zeros:
        sample_weight[::2] = 0.0
    class_weight = {0: 0.2, 1: 5.0} if case.classes else None
    effective = sample_weight.copy()
    if class_weight:
        effective *= np.where(y == 0, class_weight[0], class_weight[1])
    return X, y, sample_weight, class_weight, effective, ratio


@contextlib.contextmanager
def candidate(factor):
    original_init = sketch.initial_metric_from_parts
    original_build = sketch.build_sketch_history
    original_guard = native_logistic._conservative_config_for_skewed_curvature
    storage = {}

    def init(parts, reg, denom):
        g, h = original_init(parts, reg, denom)
        storage["g"] = g
        return g, h

    def build(
        X,
        sw,
        sw_sum,
        l2,
        fit_intercept,
        h0inv,
        *,
        history_size=10,
        sketch_size=4,
        seed=0,
        min_curvature=1e-12,
    ):
        if "g" not in storage:
            raise RuntimeError("initial gradient not captured")
        return gp.history(
            X,
            sw,
            sw_sum,
            l2,
            fit_intercept,
            h0inv,
            storage["g"],
            history_size=history_size,
            min_curvature=min_curvature,
        )

    def guard(parts, d, sw_sum, l2, config):
        out = original_guard(parts, d, sw_sum, l2, config)
        return replace(out, tol=min(out.tol, factor * config.tol))

    sketch.initial_metric_from_parts = init
    sketch.build_sketch_history = build
    native_logistic._conservative_config_for_skewed_curvature = guard
    try:
        yield
    finally:
        sketch.initial_metric_from_parts = original_init
        sketch.build_sketch_history = original_build
        native_logistic._conservative_config_for_skewed_curvature = original_guard


def fit_once(variant, X, y, sw, class_weight, C):
    seeded = variant in ("four_pair", "gradient_half", "gradient_quarter")
    factor = 0.5 if variant == "gradient_half" else 0.25
    patch = candidate(factor) if variant.startswith("gradient_") else contextlib.nullcontext()
    cls = SkLogisticRegression if variant == "sklearn" else LogisticRegression
    size = 4 if variant == "four_pair" else 1 if seeded else 0
    backend = "" if variant == "sklearn" else "mlx"
    with (
        patch,
        config_context(device="auto"),
        tuning_context(force_backend=backend, lbfgs_sketch_size=size),
        observed_sketch(native_logistic) as sketch_calls,
        observed_implementation(estimator_module, logistic, native_logistic) as records,
        warnings.catch_warnings(record=True) as caught,
    ):
        warnings.simplefilter("always")
        mx.synchronize()
        was_enabled = gc.isenabled()
        gc.disable()
        model = None
        error = None
        try:
            start = time.perf_counter()
            try:
                model = cls(C=C, tol=1e-4, max_iter=200, class_weight=class_weight).fit(
                    X, y, sample_weight=sw
                )
                mx.synchronize()
            except Exception as exc:
                error = {"type": type(exc).__name__, "message": str(exc)}
            elapsed = time.perf_counter() - start
        finally:
            if was_enabled:
                gc.enable()
    return (
        model,
        elapsed,
        {
            "backend": getattr(model, "_execution_backend_", "sklearn") if model else None,
            "n_iter": model.n_iter_.tolist() if model else None,
            "error": error,
            "warnings": [
                {"category": w.category.__name__, "message": str(w.message)} for w in caught
            ],
            "sketch_calls": sketch_calls,
            **records,
        },
    )


def score_models(models, X, y, effective, C, ratio):
    reference = next((m for m in reversed(models["sklearn"]) if m is not None), None)
    ref_score, ref_pred = (
        independent_score(reference, X, y, effective, C, ratio)
        if reference is not None
        else (None, None)
    )
    ref = (ref_score["objective_float64"], ref_pred) if ref_score is not None else None
    out = {
        v: [
            independent_score(m, X, y, effective, C, ratio, ref)[0] if m is not None else None
            for m in group
        ]
        for v, group in models.items()
    }
    return out, ref_score


def analyze(scores, details, tol=1e-4):
    result = {}
    valid_reference = {}
    for v in ("current", "four_pair", "sklearn"):
        q = scores[v][-1]
        d = details[v][-1]
        valid_reference[v] = bool(
            q is not None
            and math.isfinite(q["objective_float64"])
            and math.isfinite(q["gradient_max_abs_float64"])
            and q["gradient_max_abs_float64"] <= tol
            and not d["error"]
            and not any(w["category"] == "ConvergenceWarning" for w in d["warnings"])
            and all(s["converged"] for s in d["solutions"])
        )
    for v, group in scores.items():
        reports = []
        for i, q in enumerate(group):
            d = details[v][i]
            issues = []
            if q is None:
                reports.append(["fit_exception"])
                continue
            if not math.isfinite(q["objective_float64"]) or not math.isfinite(
                q["gradient_max_abs_float64"]
            ):
                issues.append("nonfinite_score")
            if q["gradient_max_abs_float64"] > tol:
                issues.append("gradient")
            if q["nullspace_coefficient_relative"] is not None and (
                not math.isfinite(q["nullspace_coefficient_relative"])
                or q["nullspace_coefficient_relative"] > 1e-3
            ):
                issues.append("nullspace")
            if any(w["category"] == "ConvergenceWarning" for w in d["warnings"]):
                issues.append("warning")
            if d.get("n_iter") is not None and d["n_iter"][0] > 200:
                issues.append("budget")
            for reference in ("current", "four_pair"):
                r = scores[reference][-1]
                delta = (
                    None
                    if r is None
                    else (
                        (q["objective_float64"] - r["objective_float64"])
                        / max(abs(r["objective_float64"]), np.finfo(float).tiny)
                    )
                )
                q[f"objective_gap_to_{reference}"] = delta
                q[f"{reference}_reference_valid"] = valid_reference[reference]
                if reference != v and valid_reference[reference] and delta > 1e-5:
                    issues.append(f"objective_vs_{reference}")
            q["sklearn_reference_valid"] = valid_reference["sklearn"]
            if valid_reference["sklearn"] and q["objective_relative_gap_to_sklearn"] > 1e-5:
                issues.append("objective_vs_sklearn")
            if valid_reference["sklearn"] and q["prediction_agreement_sklearn"] < 0.995:
                issues.append("predictions_vs_sklearn")
            if v.startswith("gradient_") and not any(
                a["seeded"] and a["pairs"] == 1 for a in d["sketch_calls"]
            ):
                issues.append("gradient_pair_not_used")
            reports.append(issues)
        result[v] = reports
    return result


def sanitized(value):
    """Write strict JSON without silently turning non-finite values into zero."""
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {key: sanitized(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [sanitized(item) for item in value]
    return value


def write_results(payload):
    Path("bench/sketch_speed/weighted_heldouts_results.json").write_text(
        json.dumps(sanitized(payload), indent=2, allow_nan=False) + "\n"
    )


def decisive_failure(row):
    """Stop if both candidates fail an objective/null-space gate in ordinary-scale data."""
    if row["case"]["exponent"] > 1.0:
        return False
    signals = ("objective_vs_", "gradient", "nullspace", "fit_exception")
    return all(
        any(
            any(issue.startswith(prefix) for prefix in signals)
            for repeat in row["quality_issues"][variant]
            for issue in repeat
        )
        for variant in ("gradient_half", "gradient_quarter")
    )


def main():
    variants = ("current", "four_pair", "gradient_half", "gradient_quarter", "sklearn")
    files = [Path(__file__).resolve(), path.resolve()]
    before = sources(files)
    out = {
        "method": "2 warmups and 4 balanced measured complete fits; original-weight float64 scoring on every fit; sklearn single CPU thread. Class weights pass through public estimator API.",
        "source_integrity_before": before,
        "cases": [],
    }
    with threadpool_limits(limits=1):
        for case in CASES:
            X, y, sw, class_weight, effective, ratio = dataset(case)
            samples = {v: [] for v in variants}
            details = {v: [] for v in variants}
            models = {v: [] for v in variants}
            for i in range(6):
                order = variants[i % len(variants) :] + variants[: i % len(variants)]
                if i % 2:
                    order = order[::-1]
                for v in order:
                    model, seconds, record = fit_once(v, X, y, sw, class_weight, case.C)
                    if i >= 2:
                        samples[v].append(seconds * 1000)
                        details[v].append(record)
                        models[v].append(model)
            scores, sk_score = score_models(models, X, y, effective, case.C, ratio)
            row = {
                "case": asdict(case),
                "class_weight": class_weight,
                "sample_weight_zeros": int(np.count_nonzero(sw == 0)),
                "positive_rate": float(y.mean()),
                "median_ms": {v: statistics.median(a) for v, a in samples.items()},
                "samples_ms": samples,
                "details": details,
                "quality_each_fit": scores,
                "sklearn_score": sk_score,
                "quality_issues": analyze(scores, details),
            }
            out["cases"].append(row)
            print(
                case.name,
                case.seed,
                "median_ms",
                {v: round(a, 2) for v, a in row["median_ms"].items()},
                "iterations",
                {v: details[v][-1]["n_iter"] for v in variants},
                "candidate issues",
                {v: row["quality_issues"][v][-1] for v in ("gradient_half", "gradient_quarter")},
                flush=True,
            )
            write_results(out)
            if decisive_failure(row):
                out["stopped_early"] = {
                    "case": asdict(case),
                    "reason": "both candidates failed a required objective, gradient, or null-space gate",
                }
                print("DECISIVE_FAILURE", case.name, case.seed, flush=True)
                break
    out["source_integrity_after"] = sources(files)
    out["source_integrity_pass"] = out["source_integrity_before"] == out["source_integrity_after"]
    write_results(out)


if __name__ == "__main__":
    main()
