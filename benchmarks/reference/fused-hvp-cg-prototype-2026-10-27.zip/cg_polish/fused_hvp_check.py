"""Numerical and isolated full-HVP timing checks for the scratch Metal kernel."""
from __future__ import annotations

import json
import math
import statistics
import time
from pathlib import Path

import mlx.core as mx
import numpy as np

from fused_hvp import fused_hvp


@mx.compile
def two_pass(X, curvature, vector, regularization):
    d = X.shape[1]
    projection = X @ vector[:d]
    if vector.shape[0] > d:
        projection = projection + vector[d]
    weighted = curvature * projection
    feature = X.T @ weighted
    if vector.shape[0] > d:
        result = mx.concatenate([feature, mx.sum(weighted, keepdims=True)])
    else:
        result = feature
    return result + regularization * vector


compiled_fused = mx.compile(fused_hvp)


def check_case(n, d, intercept, seed):
    rng = np.random.default_rng(seed)
    X = rng.standard_normal((n, d), dtype=np.float32)
    # Produce X centered with the same represented values used by the kernels.
    center = X.mean(axis=0, dtype=np.float64).astype(np.float32)
    X -= center
    sw = rng.uniform(0.05, 2.0, n).astype(np.float32)
    sw[::7] = 0.0
    probability = rng.uniform(0.01, 0.99, n).astype(np.float32)
    curvature = (sw * probability * (1.0 - probability) / sw.sum(dtype=np.float32)).astype(np.float32)
    vector = rng.standard_normal(d + int(intercept), dtype=np.float32)
    reg = np.full(vector.shape, 0.002, dtype=np.float32)
    if intercept:
        reg[-1] = 0.0
    arrays = tuple(mx.array(v) for v in (X, curvature, vector, reg))
    a = compiled_fused(*arrays)
    b = two_pass(*arrays)
    mx.eval(a, b)
    a, b = np.asarray(a), np.asarray(b)
    X64, curv64, v64, reg64 = (v.astype(np.float64) for v in (X, curvature, vector, reg))
    projected = X64 @ v64[:d] + (v64[d] if intercept else 0.0)
    weighted = curv64 * projected
    reference = X64.T @ weighted
    if intercept:
        reference = np.concatenate([reference, [weighted.sum()]])
    reference += reg64 * v64
    max_error = float(np.max(np.abs(a.astype(np.float64) - reference)))
    norm_reference = float(np.max(np.abs(reference)))
    max_vs_mlx = float(np.max(np.abs(a - b)))
    if not np.all(np.isfinite(a)) or not np.allclose(a, reference, rtol=7e-5, atol=1e-5):
        raise AssertionError((n, d, intercept, max_error, norm_reference))
    return {"n": n, "d": d, "intercept": intercept, "max_absolute_error": max_error,
            "max_reference": norm_reference, "max_difference_two_pass": max_vs_mlx}


def main():
    cases = []
    with mx.stream(mx.gpu):
        for d in (1, 3, 31, 32, 33, 511, 512, 513, 1023, 1024, 1025, 2047, 2048, 2049, 4095, 4096):
            for intercept in (False, True):
                cases.append(check_case(259, d, intercept, d + int(intercept)))
        # A zero-curvature extreme row must be skipped before its dot overflows.
        extreme = mx.array([[1e38, -1e38, 1e38], [0, 0, 0]], dtype=mx.float32)
        result = compiled_fused(extreme, mx.array([0, 1.0]), mx.array([10.0, -10.0, 10.0, 2.0]), mx.zeros((4,)))
        mx.eval(result)
        if not np.isfinite(np.asarray(result)).all():
            raise AssertionError("zero-curvature row produced a nonfinite HVP")
        for bad in (-1.0, float("nan"), float("inf")):
            invalid = compiled_fused(mx.ones((2, 3)), mx.array([bad, 1.0]), mx.ones((4,)), mx.zeros((4,)))
            mx.eval(invalid)
            if np.isfinite(np.asarray(invalid)).all():
                raise AssertionError(("invalid curvature was not propagated", bad))

        # Exact duplicated columns have an analytically known null space.
        rng = np.random.default_rng(114)
        left = rng.standard_normal((513, 256), dtype=np.float32)
        ratios = np.resize(np.array([2.0, 0.5], dtype=np.float32), 256)
        design = np.concatenate([left, left * ratios], axis=1)
        random_coefficients = rng.standard_normal(256, dtype=np.float32)
        null = np.concatenate([-ratios * random_coefficients, random_coefficients, [0]]).astype(np.float32)
        curvature = mx.array(rng.uniform(0, 0.01, 513).astype(np.float32))
        reg = mx.concatenate([mx.full((512,), 1e-4), mx.zeros((1,))])
        null_result = compiled_fused(mx.array(design), curvature, mx.array(null), reg)
        u = mx.array(rng.standard_normal(513, dtype=np.float32))
        v = mx.array(rng.standard_normal(513, dtype=np.float32))
        Hu = compiled_fused(mx.array(design), curvature, u, reg)
        Hv = compiled_fused(mx.array(design), curvature, v, reg)
        direct_Hu = two_pass(mx.array(design), curvature, u, reg)
        direct_Hv = two_pass(mx.array(design), curvature, v, reg)
        mx.eval(null_result, Hu, Hv, direct_Hu, direct_Hv)
        null_residual = float(mx.max(mx.abs(null_result - reg * mx.array(null))))
        lhs, rhs = float(mx.sum(u * Hv)), float(mx.sum(v * Hu))
        symmetry_relative_error = abs(lhs - rhs) / max(abs(lhs), abs(rhs), 1.0)
        direct_lhs, direct_rhs = float(mx.sum(u * direct_Hv)), float(mx.sum(v * direct_Hu))
        direct_symmetry_error = abs(direct_lhs-direct_rhs)/max(abs(direct_lhs), abs(direct_rhs), 1.0)
        if null_residual > 1e-4 or symmetry_relative_error > max(1e-5, 3 * direct_symmetry_error):
            raise AssertionError(("rank or symmetry", null_residual, symmetry_relative_error, direct_symmetry_error))

        rng = np.random.default_rng(847)
        X = mx.array(rng.standard_normal((20_000, 4096), dtype=np.float32))
        curvature = mx.array(rng.uniform(0.0, 0.25 / 20_000, 20_000).astype(np.float32))
        vector = mx.array(rng.standard_normal(4097, dtype=np.float32))
        regularization = mx.concatenate([mx.full((4096,), 1 / 20_000), mx.zeros((1,))])
        mx.eval(X, curvature, vector, regularization)
        samples = {"fused": [], "two_pass": []}
        for rep in range(24):
            for name in (("fused", "two_pass") if rep % 2 == 0 else ("two_pass", "fused")):
                mx.synchronize()
                start = time.perf_counter()
                out = (compiled_fused if name == "fused" else two_pass)(X, curvature, vector, regularization)
                mx.eval(out)
                mx.synchronize()
                if rep >= 4:
                    samples[name].append((time.perf_counter() - start) * 1000)
        a, b = compiled_fused(X, curvature, vector, regularization), two_pass(X, curvature, vector, regularization)
        mx.eval(a, b)
        max_diff = float(mx.max(mx.abs(a - b)))
        if not math.isfinite(max_diff):
            raise AssertionError("wide comparison produced nonfinite output")
    result = {"cases": cases, "extreme_zero_weight_pass": True, "invalid_curvature_pass": True,
              "null_residual_max_abs": null_residual, "symmetry_relative_error": symmetry_relative_error,
              "two_pass_symmetry_relative_error": direct_symmetry_error,
              "wide_20000x4096": {"samples_ms": samples,
              "median_ms": {k: statistics.median(v) for k, v in samples.items()},
              "max_difference_two_pass": max_diff}}
    Path("bench/cg_polish/fused-hvp-check.json").write_text(json.dumps(result, indent=2) + "\n")
    print("cases", len(cases), "wide", result["wide_20000x4096"]["median_ms"], "max_diff", max_diff, flush=True)


if __name__ == "__main__":
    main()
