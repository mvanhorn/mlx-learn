"""Scratch full-fit screen of 512-thread wide Metal tiles.

The copied package and extension are frozen before timing. Fits retain the
existing direct checks and unchanged objective. No observed fit is discarded.
"""
from __future__ import annotations
import gc
import hashlib
import inspect
import json
import math
import statistics
import sys
import time
import warnings
from dataclasses import asdict
from pathlib import Path
from types import SimpleNamespace

root = Path(__file__).resolve().parent
sys.path.insert(0, str(root.parents[1]))
sys.path.insert(0, str(root / 'snapshot/src'))
import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case, dataset, independent_score
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression

original = native_command.run_native_loop
source = inspect.getsource(original)
old = 'groups, feature_groups, rows = (4, 1, 32) if d <= 1024 else (8, 4, 32 if d <= 2048 else 64)'
assert source.count(old) == 1
source = source.replace(old, 'groups, feature_groups, rows = _experimental_geometry.get(d, ((4, 1, 32) if d <= 1024 else (8, 4, 32 if d <= 2048 else 64)))')
namespace = {}
exec(compile(source, '<experimental-native-geometry>', 'exec'), native_command.__dict__, namespace)
trial = namespace['run_native_loop']
variants = {'baseline': None, 'g16f8r16': (16,8,16), 'g16f8r32': (16,8,32), 'g16f8r64': (16,8,64), 'g16f16r32': (16,16,32), 'g16f16r64': (16,16,64)}
class Proxy:
    def __init__(self, module): self.module=module; self.calls=[]
    def run(self,*args):
        out=self.module.run(*args); self.calls.append({'iterations':out[1], 'status':out[2], 'function_evaluations':out[3]}); return out
ext=native_command._metal_loop
proxy=Proxy(ext)

def hashes():
    paths=[root/'panel.py']+[p for p in (root/'snapshot/src').rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    paths += [Path('benchmarks/hessian_logistic.py').resolve(), Path('benchmarks/logistic_gpu.py').resolve(), Path('benchmarks/sketch_weighted.py').resolve()]
    return {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}

def input_data(case,rank=False):
    X,y,w,_=dataset(case)
    ratio=None
    if rank:
        half=case.features//2
        ratio=np.tile(np.array([2.0,0.5],np.float32),half//2)
        X[:,half:]=X[:,:half]*ratio
    return X,y,w,ratio

def fit(X,y,w,case,variant,sketch):
    geo=variants[variant]
    native_command._experimental_geometry = {} if geo is None else {case.features:geo}
    native_command.run_native_loop=trial
    native_command._metal_loop=proxy
    proxy.calls.clear()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        mx.synchronize(); enabled=gc.isenabled(); gc.disable()
        try:
            start=time.perf_counter()
            with tuning_context(force_backend='mlx',lbfgs_sketch_size=4 if sketch else 0):
                model=LogisticRegression(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=w)
            mx.synchronize(); elapsed=(time.perf_counter()-start)*1000
        finally:
            if enabled: gc.enable()
    return model,elapsed,{'backend':getattr(model,'_execution_backend_',None),'n_iter':model.n_iter_.tolist(), 'warnings':[{'category':x.category.__name__,'message':str(x.message)} for x in caught], 'native':proxy.calls.copy()}

def main():
    # Sample goal: establish whether any geometry wins before testing variants
    # on wider quality/stability fixtures. Every fit is preserved.
    cases=[(Case('ordinary_4096',20000,4096,seed=41),False,False),(Case('ordinary_4096',20000,4096,seed=83),False,False)]
    out={'method':'512-thread native tiles; isolated snapshot; original float64 score; centered tight reference; one BLAS thread','source_before':hashes(),'cases':[]}
    with threadpool_limits(limits=1):
        for case,sketch,rank in cases:
            X,y,w,ratio=input_data(case,rank)
            center=X.mean(axis=0,dtype=np.float64); centered=X.astype(np.float64)-center
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter('always'); ref=SK(C=case.C,tol=1e-10,max_iter=3000).fit(centered,y,sample_weight=w)
            reference=SimpleNamespace(coef_=ref.coef_,intercept_=ref.intercept_-ref.coef_@center)
            refscore,pred=independent_score(reference,X,y,w,case.C,ratio)
            refwarnings=[{'category':x.category.__name__,'message':str(x.message)} for x in caught]
            refvalid=math.isfinite(refscore['gradient_max_abs_float64']) and refscore['gradient_max_abs_float64']<=1e-7 and not any(q['category']=='ConvergenceWarning' for q in refwarnings)
            del centered
            samples={v:[] for v in variants}; models={v:[] for v in variants}; details={v:[] for v in variants}
            names=tuple(variants)
            for rep in range(6):
                order=names[rep%len(names):]+names[:rep%len(names)]
                for variant in order:
                    m,ms,detail=fit(X,y,w,case,variant,sketch)
                    if rep>=2:samples[variant].append(ms);models[variant].append(m);details[variant].append(detail)
            scores={v:[independent_score(m,X,y,w,case.C,ratio,(refscore['objective_float64'],pred))[0] for m in group] for v,group in models.items()}
            failed=[]
            if not refvalid:failed.append({'variant':'reference','reason':'unusable tight reference','score':refscore,'warnings':refwarnings})
            for v in variants:
                for i,(q,info) in enumerate(zip(scores[v],details[v],strict=True)):
                    relative=(q['objective_float64']-scores['baseline'][i]['objective_float64'])/abs(scores['baseline'][i]['objective_float64'])
                    if (not refvalid or not math.isfinite(q['gradient_max_abs_float64']) or q['gradient_max_abs_float64']>1e-4 or not math.isfinite(q['objective_relative_gap_to_sklearn']) or q['objective_relative_gap_to_sklearn']>1e-5 or not math.isfinite(relative) or relative>1e-5 or info['warnings'] or info['backend']!='mlx' or not info['native'] or info['native'][-1]['status']!=1):
                        failed.append({'variant':v,'fit':i,'score':q,'relative_gap_baseline':relative,'info':info})
            row={'case':asdict(case),'reference':refscore,'reference_warnings':refwarnings,'reference_valid':refvalid,'median_ms':{v:statistics.median(a) for v,a in samples.items()},'samples_ms':samples,'scores':scores,'details':details,'failures':failed}
            out['cases'].append(row);print(case.name,case.seed,row['median_ms'],'failures',failed[:2],flush=True)
            (root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
    out['source_after']=hashes();out['source_integrity_pass']=out['source_before']==out['source_after'];(root/'results.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__': main()
