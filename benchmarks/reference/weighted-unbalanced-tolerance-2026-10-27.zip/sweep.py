import sys,time,warnings,json
from types import SimpleNamespace
import numpy as np
import mlx.core as mx
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case,dataset,independent_score
from mlxlearn.linear_model import LogisticRegression
from mlxlearn._common.config import tuning_context
with threadpool_limits(limits=1):
 for seed in (41,83,2027):
  case=Case('weighted_unbalanced',20000,1024,seed=seed,weighted=True)
  X,y,weights,ratio=dataset(case); y=(X[:,0]>np.quantile(X[:,0],.90)).astype(np.int32)
  with warnings.catch_warnings(record=True) as w:
   ref=SK(C=1,tol=1e-9,max_iter=1000).fit(X,y,sample_weight=weights)
  refscore,pred=independent_score(ref,X,y,weights,1,ratio)
  print('REFERENCE',seed,ref.n_iter_.tolist(),refscore,[str(x.message) for x in w],flush=True)
  for tol in (1e-4,5e-5,2e-5,1e-5,5e-6,1e-6):
   with tuning_context(force_backend='mlx',lbfgs_sketch_size=0),warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always');mx.synchronize(); t=time.perf_counter(); model=LogisticRegression(C=1,tol=tol,max_iter=200).fit(X,y,sample_weight=weights);mx.synchronize(); ms=(time.perf_counter()-t)*1000
   score,_=independent_score(model,X,y,weights,1,ratio,(refscore['objective_float64'],pred))
   print('FIT',seed,tol,round(ms,2),model.n_iter_.tolist(),score,[str(x.message) for x in caught],flush=True)
