from pathlib import Path
import subprocess, sysconfig

root=Path(__file__).resolve().parent
candidate=root/'candidate/mlxlearn/_solvers'
def edit(path, old, new):
    content=path.read_text(); count=content.count(old)
    if count!=1: raise RuntimeError((str(path),count,old[:50]))
    path.write_text(content.replace(old,new))

p=candidate/'_metal_loop.mm'
p.write_text(p.read_text().replace('MLXLearnRetainTestBufferV5','MLXLearnRetainTestBufferPriorBias'))
edit(p,'int seed_count=0, weighted=0;','int seed_count=0, weighted=0; double prior_bias=0, prior_objective=std::log(2.0);')
edit(p,'"sOiiiiiiiddddOy#|OiOi"','"sOiiiiiiiddddOy#|OiOidd"')
edit(p,'&seed_capsules,&seed_count,&device_buffers,&weighted))','&seed_capsules,&seed_count,&device_buffers,&weighted,&prior_bias,&prior_objective))')
edit(p,'static_cast<float*>(meta[0].contents())[11]=std::log(2.0f);','''static_cast<float*>(meta[0].contents())[11]=float(prior_objective);
        if(prior_bias!=0.0) {
          for(int a=0;a<2;++a){
            static_cast<float*>(w[a].contents())[d]=float(prior_bias);
            std::fill_n(static_cast<float*>(raw[a].contents()),n,float(prior_bias));
          }
        }''')
p=candidate/'native_command.py'
needle='''    # Export synchronizes the producer; keep every capsule and array alive
    # until the native command buffer has finished executing.
'''
edit(p,needle,'''    prior_bias = 0.0
    prior_objective = math.log(2.0)
    if weighted and n >= 8192 and initial_history is None:
        mx.eval(g, h0)
        positive = 0.5 - float(g[-1])
        if 1e-5 < positive < 1.0-1e-5 and (positive < 0.2 or positive > 0.8):
            # The intercept is the exact zero-coefficient minimizer. Use its
            # represented float32 value consistently for logits and gradient.
            prior_bias = float(np.float32(math.log(positive / (1.0-positive))))
            probability = 1.0 / (1.0 + math.exp(-prior_bias))
            prior_objective = (positive * math.log1p(math.exp(-prior_bias))
                               + (1.0-positive) * math.log1p(math.exp(prior_bias)))
            residual = sw * (np.float32(probability) - y)
            g = mx.concatenate([(mx.transpose(X) @ residual) / denom,
                                mx.sum(residual, keepdims=True) / denom])
            # The unseeded metric is scalar; adjust its weighted data part for
            # the Bernoulli variance at the prior while preserving L2.
            regmean = np.float32(l2 * d / p)
            h0 = 1.0 / ((1.0 / h0 - regmean) * np.float32(4.0 * probability * (1.0-probability)) + regmean)
    # Export synchronizes the producer; keep every capsule and array alive
    # until the native command buffer has finished executing.
''')
edit(p,'''    if weighted:
        arguments += (seed_capsules, seed_count, None, 1)
    elif seed_capsules is not None:
        arguments += (seed_capsules, seed_count)
''','''    if weighted:
        arguments += (seed_capsules, seed_count, None, 1, prior_bias, prior_objective)
    elif seed_capsules is not None:
        arguments += (seed_capsules, seed_count)
''')
p=candidate/'_metal_loop.mm'
out=candidate/'_metal_loop.abi3.so'
cmd=['clang++','-O3','-shared','-fobjc-arc','-std=c++17','-undefined','dynamic_lookup','-framework','Foundation','-framework','Metal',f'-I{sysconfig.get_path("include")}',str(p),'-o',str(out)]
subprocess.run(cmd,check=True)
print('built',out)
