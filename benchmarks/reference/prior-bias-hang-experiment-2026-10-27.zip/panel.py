"""Interleaved prior-bias solver experiment; complete fits and tight scoring."""
import gc, hashlib, importlib.util, json, math, os, statistics, sys, time, warnings
from pathlib import Path
base=Path(__file__).resolve().parent
sys.path.insert(0,str(base.parents[1]));sys.path.insert(0,str(base/'baseline'))
import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case,dataset,independent_score
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression

p=base/'candidate/mlxlearn/_solvers/native_command.py'
spec=importlib.util.spec_from_file_location('mlxlearn._solvers.prior_command',p)
mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
spec=importlib.util.spec_from_file_location('_prior_bias._metal_loop',base/'candidate/mlxlearn/_solvers/_metal_loop.abi3.so')
ext=importlib.util.module_from_spec(spec);spec.loader.exec_module(ext)
mod.NativeAttempt=native_command.NativeAttempt
orig=native_command.run_native_loop
class Proxy:
 def __init__(self,ext):self.ext=ext;self.calls=[]
 def run(self,*args):
  r=self.ext.run(*args);self.calls.append({'iterations':r[1],'status':r[2], 'bias':args[-2] if len(args)>=21 else 0.,'objective':args[-1] if len(args)>=21 else math.log(2)});return r
proxies={'baseline':Proxy(native_command._metal_loop),'candidate':Proxy(ext)}
mod._metal_loop=proxies['candidate'];native_command._metal_loop=proxies['baseline']
cases=[Case('ordinary',20000,1024,seed=41,weighted=True),Case('imbalance',20000,1024,seed=41,weighted=True),Case('imbalance',20000,1024,seed=83,weighted=True),Case('imbalance',20000,1024,seed=2027,weighted=True),Case('rare',20000,1024,seed=2027,weighted=True),Case('inverse',20000,1024,seed=41,weighted=True),Case('effective',20000,1024,seed=83,weighted=True),Case('ill',20000,1024,seed=83,weighted=True,ill_conditioned=True),Case('shifted',20000,1024,seed=41,weighted=True,shifted=True),Case('shifted_imbalance',20000,1024,seed=41,weighted=True,shifted=True),Case('rank',20000,1024,seed=41,weighted=True,rank_deficient=True,C=1e6),Case('normal',20000,1024,seed=41)]
if os.environ.get('PRIOR_BIAS_QUICK') == '1':
 cases=cases[:5]

def hashes():
 files=[q for d in (base/'baseline',base/'candidate') for q in d.rglob('*') if q.is_file() and '__pycache__' not in q.parts]
 files += [base/'prepare.py',base/'panel.py']
 return {str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in files}
def fit(which,X,y,w,case):
 native_command.run_native_loop=orig if which=='baseline' else mod.run_native_loop
 proxies[which].calls.clear()
 with warnings.catch_warnings(record=True) as caught,tuning_context(force_backend='mlx'):
  warnings.simplefilter('always');mx.synchronize();gc_on=gc.isenabled();gc.disable()
  try:
   start=time.perf_counter();m=LogisticRegression(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=w);mx.synchronize();elapsed=1000*(time.perf_counter()-start)
  finally:
   if gc_on:gc.enable()
 return m,elapsed,{'n_iter':m.n_iter_.tolist(),'warnings':[{'category':z.category.__name__,'message':str(z.message)} for z in caught], 'native':proxies[which].calls.copy(),'backend':getattr(m,'_execution_backend_',None)}
def main():
 out={'source_hash_before':hashes(),'method':'interleaved complete fits; 2 warmups + 8 measurements; float64 original-objective checks','cases':[]}
 try:
  with threadpool_limits(limits=1):
   for case in cases:
    X,y,w,ratio=dataset(case)
    if case.name in ('imbalance','shifted_imbalance'):y=(X[:,0]>np.quantile(X[:,0],.90)).astype(np.int32)
    elif case.name=='rare':y=(X[:,0]>np.quantile(X[:,0],.98)).astype(np.int32)
    elif case.name=='inverse':y=(X[:,0]<np.quantile(X[:,0],.90)).astype(np.int32)
    elif case.name=='effective':w=w*np.where(y==1,.1,2.)
    else:pass
    samples={x:[] for x in proxies};models={x:[] for x in proxies};details={x:[] for x in proxies}
    for rep in range(10):
     order=('baseline','candidate') if rep%2==0 else ('candidate','baseline')
     for v in order:
      m,t,d=fit(v,X,y,w,case)
      if rep>=2:samples[v].append(t);models[v].append(m);details[v].append(d)
    scores={v:[independent_score(m,X,y,w,case.C,ratio)[0] for m in group] for v,group in models.items()}
    center=X.mean(axis=0,dtype=np.float64);cx=np.asarray(X,dtype=np.float64)-center
    with warnings.catch_warnings(record=True) as refwarn:
     warnings.simplefilter('always');ref=SK(C=case.C,tol=1e-9,max_iter=3000).fit(cx,y,sample_weight=w)
    ref.intercept_=ref.intercept_-ref.coef_@center
    r,_=independent_score(ref,X,y,w,case.C,ratio);del cx
    refvalid=r['gradient_max_abs_float64']<=1e-7 and not refwarn
    failures=[]
    if not refvalid: failures.append({'reference_invalid':r,'warnings':[str(z.message) for z in refwarn]})
    for i,(x,b,detail) in enumerate(zip(scores['candidate'],scores['baseline'],details['candidate'])):
     gap=(x['objective_float64']-b['objective_float64'])/abs(b['objective_float64'])
     tight=(x['objective_float64']-r['objective_float64'])/abs(r['objective_float64'])
     if gap>1e-5 or (refvalid and tight>1e-5) or x['gradient_max_abs_float64']>1e-4 or detail['warnings'] or detail['backend']!='mlx' or not detail['native']:
      failures.append({'fit':i,'gap':gap,'tight_gap':tight,'gradient':x['gradient_max_abs_float64'],'detail':detail})
    row={'case':case.name,'seed':case.seed,'median_ms':{k:statistics.median(v) for k,v in samples.items()},'samples':samples,'quality':scores,'tight_reference':r,'reference_valid':refvalid,'details':details,'failures':failures}
    out['cases'].append(row);print(case.name,case.seed,row['median_ms'],'iterations',details['baseline'][0]['n_iter'],details['candidate'][0]['n_iter'],'bias',details['candidate'][0]['native'], 'failures',failures[:1],flush=True)
    (base/('quick-results.json' if os.environ.get('PRIOR_BIAS_QUICK') == '1' else 'results.json')).write_text(json.dumps(out,indent=2)+'\n')
 finally:
  native_command.run_native_loop=orig;native_command._metal_loop=proxies['baseline'].ext
 out['source_hash_after']=hashes();out['source_integrity_pass']=out['source_hash_before']==out['source_hash_after'];(base/('quick-results.json' if os.environ.get('PRIOR_BIAS_QUICK') == '1' else 'results.json')).write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
