import warnings,json,time
import numpy as np, mlx.core as mx
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case, dataset, independent_score
from mlxlearn.linear_model import LogisticRegression
from mlxlearn._common.config import tuning_context
from mlxlearn_device import fit_logistic
out=[]
cases=[Case('ill',20000,1024,seed=s,weighted=True,ill_conditioned=True) for s in (41,83)]+[Case('shifted',20000,1024,seed=41,weighted=True,shifted=True)]
with threadpool_limits(limits=1):
 for case in cases:
  X,y,sw,ratio=dataset(case);center=X.mean(axis=0,dtype=np.float64); ref=SK(C=1,tol=1e-10,max_iter=3000).fit(X.astype(np.float64)-center,y,sample_weight=sw)
  ref.intercept_-=ref.coef_@center;score,pred=independent_score(ref,X,y,sw,1,ratio)
  for variant in ('host','sketch','device','device0'):
   with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always'); start=time.perf_counter()
    if variant in ('host','sketch'):
     with tuning_context(force_backend='mlx',lbfgs_sketch_size=4 if variant=='sketch' else 0): m=LogisticRegression(C=1,tol=1e-4,max_iter=200).fit(X,y,sample_weight=sw)
    else:m=fit_logistic(mx.array(X),mx.array(y),sample_weight=mx.array(sw,dtype=mx.float32),C=1,tol=1e-4,max_iter=200,sketch_size=4 if variant=='device' else 0)
    mx.synchronize();ms=(time.perf_counter()-start)*1e3
   q,_=independent_score(m,X,y,sw,1,ratio,(score['objective_float64'],pred));n=getattr(m,'n_iter_',getattr(m,'n_iter',None));n=n.tolist() if hasattr(n,'tolist') else n
   r={'case':case.name,'seed':case.seed,'variant':variant,'ms':ms,'n_iter':n,'score':q,'warnings':[str(w.message) for w in caught]};out.append(r);print(r,flush=True)
open('bench/weighted_new/ill_shift.json','w').write(json.dumps(out,indent=2))
