import numpy as np, warnings, json
import mlx.core as mx
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case, dataset, independent_score
from mlxlearn.linear_model import LogisticRegression
from mlxlearn._common.config import tuning_context
from mlxlearn_device import fit_logistic
out=[]
with threadpool_limits(limits=1):
 for seed in (41,83,2027):
  case=Case('weighted_unbalanced',20000,1024,seed=seed,weighted=True)
  X,y,sw,ratio=dataset(case);y=(X[:,0]>np.quantile(X[:,0],.9)).astype(np.int32)
  ref=SK(C=1,tol=1e-10,max_iter=2000).fit(X,y,sample_weight=sw)
  refscore,pred=independent_score(ref,X,y,sw,1,ratio)
  for variant in ('host','sketch','device','device0'):
   with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always')
    if variant in ('host','sketch'):
     with tuning_context(force_backend='mlx',lbfgs_sketch_size=4 if variant=='sketch' else 0): model=LogisticRegression(C=1,tol=1e-4,max_iter=200).fit(X,y,sample_weight=sw)
    else:
     model=fit_logistic(mx.array(X),mx.array(y),sample_weight=mx.array(sw,dtype=mx.float32),C=1,tol=1e-4,max_iter=200,sketch_size=4 if variant=='device' else 0)
   score,_=independent_score(model,X,y,sw,1,ratio,(refscore['objective_float64'],pred))
   row={'seed':seed,'variant':variant,'iteration':getattr(model,'n_iter_',getattr(model,'n_iter',None)),'score':score,'warnings':[str(w.message) for w in caught]}
   if hasattr(row['iteration'],'tolist'):row['iteration']=row['iteration'].tolist()
   out.append(row); print(row,flush=True)
open('bench/weighted_new/check.json','w').write(json.dumps(out,indent=2))
