import json, time, warnings
from pathlib import Path
import numpy as np
import mlx.core as mx
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case,dataset,independent_score
from mlxlearn.linear_model import LogisticRegression
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command

orig=native_command._metal_loop
EVENTS=[]
class Probe:
 __file__=orig.__file__
 def run(self,*args):
  r=orig.run(*args);EVENTS.append({'iterations':int(r[1]),'status':int(r[2]),'last_delta':float(r[4]),'previous_delta':float(r[5])});return r
native_command._metal_loop=Probe()
out=[]
with threadpool_limits(limits=1):
 for seed in (41,83,2027):
  case=Case('weighted_unbalanced',20000,1024,seed=seed,weighted=True)
  X,y,sw,ratio=dataset(case); y=(X[:,0]>np.quantile(X[:,0],.9)).astype(np.int32)
  ref=SK(C=1,tol=1e-10,max_iter=2000).fit(X,y,sample_weight=sw)
  reference,pred=independent_score(ref,X,y,sw,1,ratio)
  for sketch in (0,4):
   for budget in (16,20,24,28,32,36,40,44,48):
    EVENTS.clear()
    with tuning_context(force_backend='mlx',lbfgs_sketch_size=sketch),warnings.catch_warnings(record=True) as caught:
     warnings.simplefilter('always');mx.synchronize();start=time.perf_counter();m=LogisticRegression(C=1,tol=1e-6,max_iter=budget).fit(X,y,sample_weight=sw);mx.synchronize();elapsed=time.perf_counter()-start
    score,_=independent_score(m,X,y,sw,1,ratio,(reference['objective_float64'],pred));e=EVENTS[-1] if EVENTS else None
    prog=(abs(e['last_delta'])+abs(e['previous_delta']))/(2*score['objective_float64']) if e and e['iterations']>=2 else None
    row={'seed':seed,'sketch':sketch,'budget':budget,'iterations':m.n_iter_.tolist(),'ms':elapsed*1000,'gradient':score['gradient_max_abs_float64'],'gap':score['objective_relative_gap_to_sklearn'],'progress':prog,'events':EVENTS.copy(),'warnings':[str(w.message) for w in caught]}
    out.append(row);print(row,flush=True)
    Path('bench/weighted_new/trace.json').write_text(json.dumps(out,indent=2))
native_command._metal_loop=orig
