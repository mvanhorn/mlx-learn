"""Experimental binary, GPU-resident float32 fit without NumPy calls.

Research prototype: accepts MLX arrays, returns centered-coordinate device
parameters, raises on unhandled native-loop failures. Not a sklearn estimator.
"""
from __future__ import annotations

import ast
import functools
import importlib.util
import math
import struct
from dataclasses import dataclass
from pathlib import Path

import mlx.core as mx

ROOT = Path(__file__).resolve().parents[2]
SOLVERS = ROOT / 'src/mlxlearn/_solvers'


def _load_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Load independent kernel definitions without importing the sklearn wrapper.
_input = _load_file('gpu_only_input', ROOT / 'src/mlxlearn/_kernels/logistic_input.py')
_loop = _load_file('_metal_loop', SOLVERS / '_metal_loop.abi3.so')

# Reuse exactly the production Metal source generator without importing its
# NumPy-using Python bridge. Its generated kernels remain unchanged.
tree = ast.parse((SOLVERS / 'native_command.py').read_text())
selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in {'_kernel_source', '_kernel', '_source'}]
namespace = {'Path': Path, 'functools': functools, 'ast': ast, '__file__': str(SOLVERS / 'native_command.py')}
exec(compile(ast.Module(body=selected, type_ignores=[]), str(SOLVERS / 'native_command.py'), 'exec'), namespace)
_source = namespace['_source']


@dataclass
class DeviceResult:
    coefficients: object
    center: object
    centered_intercept: object
    n_iter: int
    objective: float
    gradient_max_abs: float
    progress: float

    def logits(self, X):
        return (X - self.center) @ self.coefficients + self.centered_intercept


def fit_binary(X, y, *, C=1.0, tol=1e-4, max_iter=200, sample_weight=None):
    """Fit native loop on MLX float32 binary data; no CPU array conversion.

    Returned parameters are in centered coordinates. Strict direct gradient and
    wide progress checks are made, but there is no float64 certificate or
    correction fallback: this cannot be used as a production replacement.
    """
    if X.ndim != 2 or X.dtype != mx.float32:
        raise ValueError('X must be a float32 MLX matrix')
    n, d = X.shape
    if not (n > 0 and 512 <= d <= 4096 and max_iter > 0 and C > 0 and tol > 0):
        raise ValueError('prototype requires positive dimensions, C, tol, max_iter and 512..4096 features')
    if y.ndim != 1 or y.shape[0] != n:
        raise ValueError('y must be a row-aligned MLX vector')
    y = y.astype(mx.float32)
    if sample_weight is None:
        sw = mx.ones((n,), mx.float32)
        sw_sum = float(n)
    else:
        sw = sample_weight.astype(mx.float32)
        if sw.shape != (n,):
            raise ValueError('weights must be a row-aligned MLX vector')
        sw_sum = float(mx.sum(sw))
    denom = mx.array(sw_sum, mx.float32)
    l2 = 1.0 / (float(C) * sw_sum)
    centered, center, finite, parts = _input.prepare_centered(X, y, sw)
    reg = mx.concatenate((mx.full((d,), l2, mx.float32), mx.zeros((1,), mx.float32)))
    init = mx.sum(parts, axis=1) / denom
    diag = mx.mean(init[1] + reg)
    h0 = mx.ones_like(init[0]) * mx.where(mx.isfinite(diag) & (diag > 1e-12), 1 / diag, 1.0)
    g = init[0]
    mx.eval(centered, center, finite, y, sw, g, h0, reg)
    if not bool(finite) or not bool(mx.all(mx.isfinite(sw) & (sw >= 0))) or sw_sum <= 0:
        raise ValueError('input and weights must be finite with nonnegative, positive-sum weights')
    if not bool(mx.all((y == 0) | (y == 1))):
        raise ValueError('labels must be 0 or 1')
    groups, fg, rows = ((4, 1, 32) if d <= 1024 else (8, 4, 32 if d <= 2048 else 64)) if n >= 16384 else ((2, 1, 16) if d <= 1024 else (8, 4, 8))
    blocks = (n + (groups // fg) * rows - 1) // ((groups // fg) * rows)
    code = _source(n, d, d + 1, 10, 8, blocks, groups, rows, fg)
    arrs = (centered, y, sw, g, h0, reg)
    mx.synchronize()
    capsules = tuple(a.__dlpack__() for a in arrs)
    owners = (capsules, *arrs)
    # The existing extension copies this small feature vector to its own arena.
    # This is a host round trip, not an all-device implementation yet.
    center_data = struct.pack(f'{d}f', *center.tolist())
    raw, n_iter, status, n_fev, last_diff, prev_diff = _loop.run(
        code, capsules, n, d, d+1, 10, blocks, groups, max_iter,
        sw_sum, tol, 1e-4, 1e-12, owners, center_data,
    )
    if status != 1:
        raise RuntimeError(f'native loop failed to converge: status={status}, iterations={n_iter}')
    theta = mx.array(struct.unpack(f'{d+1}f', raw), mx.float32)
    w, b = theta[:d], theta[d]
    z = centered @ w + b
    sign = 1 - 2 * y
    signed = sign * z
    residual = sign * mx.sigmoid(signed) * sw
    loss = mx.logaddexp(mx.zeros_like(signed), signed)
    objective = mx.sum(sw * loss) / denom + 0.5 * l2 * mx.sum(w*w)
    bias_grad = mx.sum(residual) / denom
    grad = (residual @ centered) / denom + l2*w + center*bias_grad
    gradmax = mx.maximum(mx.max(mx.abs(grad)), mx.abs(bias_grad))
    mx.eval(objective, gradmax)
    obj, norm = float(objective), float(gradmax)
    progress = (abs(last_diff) + abs(prev_diff))*0.5 if n_iter >= 2 else abs(last_diff)
    if not math.isfinite(obj) or not math.isfinite(norm) or norm > tol or (d >= 2048 and progress > tol * abs(obj)):
        raise RuntimeError(f'direct certification failed: gradient={norm} progress={progress}')
    return DeviceResult(w, center, b, n_iter, obj, norm, progress)
