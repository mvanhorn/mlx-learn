"""Execute the experimental fit with NumPy and sklearn imports forbidden."""
import builtins
import importlib.util
import sys
from pathlib import Path

original_import = builtins.__import__
def guarded_import(name, *args, **kwargs):
    if name == 'numpy' or name.startswith('numpy.') or name == 'sklearn' or name.startswith('sklearn.'):
        raise AssertionError(f'forbidden import: {name}')
    return original_import(name, *args, **kwargs)
builtins.__import__ = guarded_import

import mlx.core as mx
spec = importlib.util.spec_from_file_location('gpu_prototype', Path(__file__).with_name('prototype.py'))
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
with mx.stream(mx.gpu):
    mx.random.seed(41)
    X = mx.random.normal((2_048, 512))
    y = (X[:, 0] > 0).astype(mx.float32)
    mx.eval(X, y)
    result = module.fit_binary(X, y)
    mx.eval(result.coefficients, result.center, result.centered_intercept)
    print('NumPy-free fit returned', result.n_iter, 'iterations; grad max', result.gradient_max_abs)
assert 'numpy' not in sys.modules and 'sklearn' not in sys.modules
