"""Exploratory resident-device fit comparison; scoring is external and uses NumPy.

The prototype fit accepts and returns MLX arrays and calls no NumPy APIs.
Input generation, external quality checks, sklearn, and benchmark bookkeeping
use NumPy. Device uploads are timed separately and excluded from fit times.
"""
from __future__ import annotations
import importlib.util, json, gc, math, statistics, sys, time, warnings
from pathlib import Path
from types import SimpleNamespace
import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SkLR
from sklearn.exceptions import ConvergenceWarning
from threadpoolctl import threadpool_limits

root=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(root))
from benchmarks.logistic_gpu import Case, make_data, quality
from mlxlearn._common.config import tuning_context
from mlxlearn.linear_model import LogisticRegression

spec=importlib.util.spec_from_file_location('gpu_prototype',Path(__file__).with_name('prototype.py'))
proto=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=proto
spec.loader.exec_module(proto)


def synchronize():
    mx.synchronize()


def run_one(variant, X, y, weight, dX, dy, dw):
    synchronize()
    start=time.perf_counter()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        if variant=='gpu_device':
            model=proto.fit_binary(dX,dy,sample_weight=dw)
        elif variant=='native_library':
            with tuning_context(force_backend='mlx'):
                model=LogisticRegression(C=1.,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weight)
        else:
            model=SkLR(C=1.,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weight)
        synchronize()
    elapsed=time.perf_counter()-start
    return model, elapsed, [f'{x.category.__name__}: {x.message}' for x in caught]


def as_host_model(model):
    w=np.asarray(model.coefficients,dtype=np.float64)
    center=np.asarray(model.center,dtype=np.float64)
    b=float(model.centered_intercept)-float(w @ center)
    # Provide prediction semantics of centered-coordinate result; this avoids
    # float32 intercept restoration for heavily shifted inputs.
    return SimpleNamespace(coef_=w.reshape(1,-1),intercept_=np.array([b]),classes_=np.array([0, 1]))


def main():
    cases=[Case('wide_1024',20000,1024),Case('wide_weighted',20000,1024,weighted=True),Case('wide_4096',20000,4096),Case('shifted_1024',20000,1024),Case('ill_conditioned_1024',20000,1024,ill_conditioned=True)]
    payload={'warning':'Exploratory only. Device prototype is not an sklearn estimator, lacks full-precision original-input certification and native fallback, and uses small host round-trips. Input upload excluded from fit times and measured separately. Reference fits use host input. External quality and benchmark use NumPy.', 'seed':41,'repeats':12,'warmups':3,'cases':[]}
    variants=('gpu_device','native_library','sklearn')
    with threadpool_limits(limits=1):
      for case in cases:
        X,y,sw=make_data(case,41,dtype='float32')
        if case.name.startswith('shifted'): X += np.float32(1000)
        synchronize();t=time.perf_counter();dX=mx.array(X);dy=mx.array(y);dw=None if sw is None else mx.array(sw.astype(np.float32));mx.eval(dX,dy,dw) if dw is not None else mx.eval(dX,dy);synchronize();upload=time.perf_counter()-t
        samples={v:[] for v in variants};models={}; failures=[];iterations={v:[] for v in variants}; warns={v:[] for v in variants}
        for rep in range(15):
          order=variants[rep%3:]+variants[:rep%3]
          if rep%2:order=order[::-1]
          for v in order:
            try:
              gc.collect(); model,t,ws=run_one(v,X,y,sw,dX,dy,dw)
              if rep>=3:
                samples[v].append(t);models[v]=model
                iterations[v].append(model.n_iter if v=='gpu_device' else model.n_iter_.tolist())
                warns[v].extend(ws)
            except Exception as exc:
              failures.append({'variant':v,'rep':rep,'error':repr(exc)})
        scores={}
        if 'sklearn' in models:
          ref=models['sklearn']
          for v in ('gpu_device','native_library'):
            if v in models:
              model=as_host_model(models[v]) if v=='gpu_device' else models[v]
              # quality needs predict; its score is constructed externally on
              # original input, preserving float64 restored intercept.
              model.predict=lambda data, m=model: ((np.asarray(data) @ m.coef_[0] + m.intercept_[0]) >= 0).astype(np.int32)
              scores[v]=quality(model,ref,X,y,sw)
        row={'case':case.name,'shape':[case.n_samples,case.n_features],'upload_seconds':upload,'timings_ms':{v:{'median':statistics.median(s)*1000,'samples':[x*1000 for x in s]} for v,s in samples.items() if s},'iterations':iterations,'warnings':warns,'failures':failures,'quality_last_fit':scores}
        payload['cases'].append(row)
        print(case.name,{v:round(z['median'],3) for v,z in row['timings_ms'].items()},'failure_count',len(failures), flush=True)
        Path('bench/gpu_no_numpy/results.json').write_text(json.dumps(payload,indent=2)+'\n')
    return int(any(row['failures'] for row in payload['cases']))
if __name__=='__main__': raise SystemExit(main())
