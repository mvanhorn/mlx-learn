"""Compare 1x and two-step averaged objective-progress heuristics with unchanged gtol.

The averaged variant modifies only the on-demand Metal shader string via a private extension proxy; no project source is changed. Slot 10 carries the averaged progress to both native host and direct verification.
Independent scoring runs only after all timed fits in each case. Short balanced
samples are diagnostic, not a substitute for release benchmarking.
"""
from __future__ import annotations

import gc
import hashlib
import itertools
import json
import time
import warnings
from pathlib import Path

import mlx.core as mx
import numpy as np
from scipy.special import expit
from sklearn.linear_model import LogisticRegression as SkLogisticRegression
from threadpoolctl import threadpool_limits

from benchmarks.logistic_gpu import Case, make_data
from benchmarks.logistic_wide import observed_implementation
from mlxlearn import config_context
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import logistic, native_command, native_logistic
from mlxlearn.linear_model import LogisticRegression
from mlxlearn.linear_model import _logistic as estimator

original_extension=native_command._metal_loop
if original_extension is None:
    raise RuntimeError('native extension is unavailable')

class Progress2:
    def run(self, source, *args):
        # Slot 4 is unused after direction finishes: preserve the last raw
        # accepted delta there. Slot 10 holds the averaged delta, so the
        # unchanged native host shortcut and direct verifier see the same rule.
        changes = {
            'stats[4]=maxgrad;stats[5]=active?slope:0.0f': 'stats[4]=meta[4];stats[5]=active?slope:0.0f',
            'i==8?alpha:(i==9?stats[9]+(stats[1]==0?CAND:0):(i==10?(accepted?accepted_diff:stats[10])': 'i==4?(accepted?accepted_diff:stats[4]):(i==8?alpha:(i==9?stats[9]+(stats[1]==0?CAND:0):(i==10?(accepted?(stats[0]==0?abs(accepted_diff):0.5f*(abs(accepted_diff)+abs(stats[4]))):stats[10])',
            'stats[11]+accepted_diff:stats[i])))));': 'stats[11]+accepted_diff:stats[i]))))));',
        }
        for old,new in changes.items():
            if source.count(old)!=1: raise RuntimeError('unexpected source fragment: '+old)
            source=source.replace(old,new)
        return original_extension.run(source,*args)


def fit(mode,X,y,weight,C):
    native_command._metal_loop = Progress2() if mode=='progress2' else original_extension
    cls=SkLogisticRegression if mode=='sklearn' else LogisticRegression
    settings=config_context(device='auto')
    tuning=tuning_context(force_backend='' if mode=='sklearn' else 'mlx')
    try:
        with settings,tuning,observed_implementation(estimator,logistic,native_logistic) as observed,warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            mx.synchronize();gc_enabled=gc.isenabled();gc.disable()
            try:
                start=time.perf_counter();model=cls(C=C,tol=1e-4,max_iter=200,fit_intercept=True).fit(X,y,sample_weight=weight);mx.synchronize();elapsed=time.perf_counter()-start
            finally:
                if gc_enabled:gc.enable()
        return elapsed,model,{'backend':getattr(model,'_execution_backend_','sklearn'),'n_iter':model.n_iter_.tolist(),'warnings':[{'category':x.category.__name__,'message':str(x.message)} for x in caught],**observed}
    finally:
        native_command._metal_loop=original_extension


def independent(model,data,y,weight,C):
    w=np.asarray(model.coef_[0],dtype=np.float64);b=float(model.intercept_[0]);raw=data@w+b
    residual=expit(raw)-y
    denom=float(len(y) if weight is None else weight.sum(dtype=np.float64))
    loss=np.logaddexp(0.,(1-2*y)*raw)
    if weight is not None:residual*=weight;loss*=weight
    grad=residual@data/denom+w/(C*denom);gb=float(residual.sum()/denom)
    return {'objective_float64':float(loss.sum(dtype=np.float64)/denom+np.dot(w,w)/(2*C*denom)),
            'gradient_max_abs_float64':max(float(np.abs(grad).max()),abs(gb)),
            'predictions':raw>=0}


def run():
    paths=[Path('src/mlxlearn/_solvers')/x for x in ('native_logistic.py','native_command.py','_metal_loop.mm','logistic.py','fused_lbfgs.py')]+[Path(original_extension.__file__),Path(__file__)]
    hashes={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    cases=[('seed41',20000,4096,41,1.0,False,False),('seed83',20000,4096,83,1.0,False,False),('seed2027',20000,4096,2027,1.0,False,False),('weighted41',20000,4096,41,1.0,True,False),('weighted83',20000,4096,83,1.0,True,False),('weighted_C01',20000,4096,83,0.1,True,False),('weighted_C10',20000,4096,83,10.0,True,False),('regularized01',20000,4096,41,0.1,False,False),('regularized10',20000,4096,41,10.0,False,False),('ill_conditioned',6000,2048,41,1.0,False,True)]
    modes=('progress1','progress2','sklearn');orders=list(itertools.permutations(modes));out={'method':{'repeats':len(orders),'warmups':1,'orders':'all permutations once','public_gtol':1e-4,'max_iter':200,'note':'Proxy replaces slot 10 with average of absolute last two accepted deltas; slot 4 stores previous raw delta, so GPU, native host and direct verifier all check the same unchanged 1x threshold. First step uses its own absolute delta. Diagnostic only.'},'hashes':hashes,'cases':[]}
    path=Path('bench/objective_accuracy_sweep/progress-average-results.json')
    with threadpool_limits(limits=1):
      for name,n,d,seed,C,weighted,ill in cases:
        case=Case(name,n,d,weighted=weighted,ill_conditioned=ill);X,y,sw=make_data(case,seed,dtype='float32')
        for mode in modes:fit(mode,X,y,sw,C)
        samples={x:[] for x in modes};models={x:[] for x in modes};details={x:[] for x in modes}
        for order in orders:
          for mode in order:
            elapsed,model,info=fit(mode,X,y,sw,C);samples[mode].append(elapsed);models[mode].append(model);details[mode].append(info)
        X64=np.asarray(X,dtype=np.float64);scores={}
        reference=independent(models['sklearn'][-1],X64,y,sw,C)
        for mode in modes:
          scores[mode]=[]
          for model in models[mode]:
            q=independent(model,X64,y,sw,C);pred=q.pop('predictions');q['objective_relative_gap_to_sklearn']=(q['objective_float64']-reference['objective_float64'])/abs(reference['objective_float64']);q['prediction_agreement_sklearn']=float(np.mean(pred==reference['predictions']));scores[mode].append(q)
        row={'name':name,'n':n,'d':d,'seed':seed,'C':C,'weighted':weighted,'ill_conditioned':ill,'orders':orders,'samples_s':samples,'fits':details,'quality_each_fit':scores,'median_ms':{m:1000*float(np.median(samples[m])) for m in modes},'paired_wins_progress2_vs_1':sum(b<a for a,b in zip(samples['progress1'],samples['progress2']))}
        out['cases'].append(row);path.write_text(json.dumps(out,indent=2)+'\n')
        print(name,row['median_ms'],'iterations',{m:[i['n_iter'] for i in details[m]] for m in modes},'gaps',{m:[round(q['objective_relative_gap_to_sklearn'],8) for q in scores[m]] for m in ('progress1','progress2')},'warnings',{m:sum(bool(i['warnings']) for i in details[m]) for m in modes},flush=True)
    out['source_integrity']={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest()==hashes[str(p.resolve())] for p in paths};path.write_text(json.dumps(out,indent=2)+'\n')

if __name__=='__main__':run()
