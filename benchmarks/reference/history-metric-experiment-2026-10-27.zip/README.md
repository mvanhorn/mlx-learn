# Exploratory scalar-metric L-BFGS history sizes

The production native command-loop wrapper currently selects history size 10.
This standalone process dynamically copies the wrapper's source and changes only
its route gate to allow 10, 20, or 32; no production source or extension is
edited. Metal kernels compile separately for each size. The full estimator is
run with the production scalar trace metric, and all fit times include the same
preparation and original-precision direct certification.

Reproduce from the repository root with `PYTHONPATH=. python3
bench/history_metric/experiment.py`. The 10, 20 and 32 variants use three
warmups then eight balanced/interleaved fresh fits. Stock sklearn is included
with one CPU thread. Each timed fit has a separate float64 objective and
original-coordinate maximum-gradient audit, warning record, native loop route,
and elapsed time. The rank-deficient cases contain exact powers-of-two
correlations, use C=1e6, and record a null-space coefficient diagnostic.
All source files, the native binary and experiment script are hashed before and
after the run. This is a short exploratory panel rather than a universal
performance or accuracy guarantee. Preserve the cases in which gradient
convergence passes but objective or accuracy relative to the scalar baseline
does not.

Observed warm median milliseconds in this run:

| Case | History 10 | History 20 | History 32 | sklearn |
|---|---:|---:|---:|---:|
| Correlated ill-conditioned, seed 41 | 71.71 | 38.08 | 127.67 | 57.88 |
| Weighted correlated, seed 83 | 28.31 | 36.27 | 56.91 | 190.59 |
| Exact rank-deficient, seed 41 | 9.26 | 11.15 | 13.97 | 14.44 |
| Exact rank-deficient, seed 83 | 9.51 | 11.21 | 15.04 | 14.60 |
| 20k × 4096, seed 41 | 42.97 | 63.61 | 80.02 | 64.34 |

In the ill-conditioned seed-41 row, 10 and 20 history gave relative objective
gaps of -0.001821 and +0.000000155 versus sklearn, respectively: the faster
history 20 solution is approximately 0.00182 relative worse than history 10.
The weighted correlated row has a pre-existing relative objective gap of
approximately +0.00290 versus sklearn across all three native histories despite
independent max gradients below 1e-4. sklearn's independent max gradient is
7.61e-5 with no warning. Exact rank-deficient outputs retain zero measured
null-space residual in both seeds. Every sampled native fit completed its native
command loop; no sampled fit or sklearn reference emitted a warning. The
before/after source-and-binary integrity comparison passed.
