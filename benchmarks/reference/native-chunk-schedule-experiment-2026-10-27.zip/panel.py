"""Profile native command chunk scheduling: exploratory same-process experiment.

No library file is edited. Extension variants report native wall/GPU times,
command count and encoded steps. Float64 scores are outside timed regions.
"""
from __future__ import annotations
import gc,hashlib,importlib.util,json,statistics,time,warnings
from pathlib import Path
import mlx.core as mx
import numpy as np
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import Case,dataset,independent_score
from benchmarks.logistic_wide import package_source_paths
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression

base=Path(__file__).resolve().parent
names=('baseline','chunk8','chunk16','chunk8_early','chunk16_early')
modules={}
for name in names:
 p=base/name/'_metal_loop.so';spec=importlib.util.spec_from_file_location('_metal_loop',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);modules[name]=module
orig_module,orig_source=native_command._metal_loop,native_command._source
EVENTS=[]

class Proxy:
 def __init__(self,name):self.name=name;self.__file__=modules[name].__file__
 def run(self,*args):
  r=modules[self.name].run(*args)
  if len(r)!=10:raise ValueError(f'bad instrumented loop result {len(r)}')
  EVENTS.append({'n_iter':int(r[1]),'status':int(r[2]),'gpu_ms':float(r[6])*1000,'native_wall_ms':float(r[7])*1000,'command_buffers':int(r[8]),'encoded_steps':int(r[9])})
  return r[:6]
proxies={k:Proxy(k) for k in names}

def early_source(*args):
 s=orig_source(*args);i=s.index('kernel void speculative_kernel(');p=s.index('{',i)
 s=s[:p+1]+'\nif(stats[1]!=0)return;\n'+s[p+1:]
 old='residual[i]=sw[i]>0?sw[i]*sign*sigmoid_stable(sign*z):0.0f;'
 new='residual[i]=status==0 && sw[i]>0?sw[i]*sign*sigmoid_stable(sign*z):0.0f;'
 if s.count(old)!=1:raise RuntimeError('accept source mismatch')
 return s.replace(old,new)

def fit(X,y,weights,case,variant):
 EVENTS.clear()
 if variant!='sklearn':
  native_command._metal_loop=proxies[variant]
  native_command._source=early_source if variant.endswith('_early') else orig_source
 with warnings.catch_warnings(record=True) as caught:
  warnings.simplefilter('always');mx.synchronize();enabled=gc.isenabled();gc.disable()
  try:
   t=time.perf_counter()
   if variant=='sklearn':m=SK(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weights)
   else:
    with tuning_context(force_backend='mlx'):m=LogisticRegression(C=case.C,tol=1e-4,max_iter=200).fit(X,y,sample_weight=weights)
   mx.synchronize();elapsed=(time.perf_counter()-t)*1000
  finally:
   if enabled:gc.enable()
 return m,elapsed,{'n_iter':m.n_iter_.tolist(),'native_events':EVENTS.copy(),'warnings':[{'category':w.category.__name__,'message':str(w.message)} for w in caught]}

cases=[Case('weighted_ill_seed83',20000,1024,seed=83,weighted=True,ill_conditioned=True),
       Case('weighted_ill_seed41',20000,1024,seed=41,weighted=True,ill_conditioned=True),
       Case('weighted_ill_seed2027',20000,1024,seed=2027,weighted=True,ill_conditioned=True),
       Case('normal_1024',20000,1024,seed=41),
       Case('weighted_normal_1024',20000,1024,seed=41,weighted=True),
       Case('rank_deficient_1024',20000,1024,seed=41,rank_deficient=True,C=1e6),
       Case('wide_4096',20000,4096,seed=41)]

def main():
 paths=package_source_paths()+[Path(orig_module.__file__).resolve(),Path(__file__).resolve(),base/'build.py']+[base/(n+'.mm') for n in names]+[base/n/'_metal_loop.so' for n in names]
 hashes=lambda:{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
 before=hashes();variants=names+('sklearn',)
 output={'method':'instrumented extension; interleaved complete fits, 3 warmup, 8 repeats, single-thread sklearn; all measured fits independently scored; CPU wall/GPU command timings per fit','source_integrity_before':before,'cases':[]}
 try:
  with threadpool_limits(limits=1):
   for case in cases:
    X,y,weights,ratio=dataset(case);samples={v:[] for v in variants};models={v:[] for v in variants};details={v:[] for v in variants}
    for rep in range(11):
     order=variants[rep%len(variants):]+variants[:rep%len(variants)]
     if rep%2:order=order[::-1]
     for v in order:
      model,elapsed,detail=fit(X,y,weights,case,v)
      if rep>=3:samples[v].append(elapsed);models[v].append(model);details[v].append(detail)
    ref,pr=independent_score(models['sklearn'][-1],X,y,weights,case.C,ratio)
    scores={v:[independent_score(m,X,y,weights,case.C,ratio,(ref['objective_float64'],pr))[0] for m in group] for v,group in models.items()}
    ref_obj=scores['baseline'][-1]['objective_float64'];failures=[]
    for v in names:
     for i,(sc,de) in enumerate(zip(scores[v],details[v])):
      if de['warnings'] or sc['gradient_max_abs_float64']>1e-4:failures.append([v,i,'warning_or_gradient'])
      if (sc['objective_float64']-ref_obj)/abs(ref_obj)>1e-5:failures.append([v,i,'objective_vs_baseline'])
      if case.rank_deficient and sc['nullspace_coefficient_relative']>1e-3:failures.append([v,i,'nullspace'])
      if not de['native_events'] or any(e['status']!=1 for e in de['native_events']):failures.append([v,i,'route_or_native_status'])
    medians={v:statistics.median(s) for v,s in samples.items()}
    diagnostics={}
    for v in names:
     events=[x['native_events'][0] for x in details[v] if x['native_events']]
     if events: diagnostics[v]={key:statistics.median(e[key] for e in events) for key in ('gpu_ms','native_wall_ms','command_buffers','encoded_steps','n_iter')}
    row={'case':case.name,'seed':case.seed,'C':case.C,'median_ms':medians,'samples_ms':samples,'fit_details':details,'quality_each_fit':scores,'diagnostics':diagnostics,'failures':failures}
    output['cases'].append(row)
    print(case.name,{v:round(t,3) for v,t in medians.items()},'diag',diagnostics,'fails',failures[:2],flush=True)
    (base/'results.json').write_text(json.dumps(output,indent=2)+'\n')
 finally:
  native_command._metal_loop=orig_module;native_command._source=orig_source
 output['source_integrity_after']=hashes();output['source_integrity_passed']=output['source_integrity_before']==output['source_integrity_after']
 (base/'results.json').write_text(json.dumps(output,indent=2)+'\n')
if __name__=='__main__':main()
