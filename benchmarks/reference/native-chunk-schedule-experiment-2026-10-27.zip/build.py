"""Build instrumented scratch native loops without changing library files."""
from pathlib import Path
import subprocess,sysconfig
root=Path(__file__).resolve().parents[2]; base=Path(__file__).resolve().parent
original=(root/'src/mlxlearn/_solvers/_metal_loop.mm').read_text()
chunk='int chunk=std::min(n_iter==0 ? 8 : n_iter==8 ? 1 : 4,max_iter-n_iter);'
assert original.count(chunk)==1
old='PyObject* result=Py_BuildValue("Niiidd",bytes,n_iter,status,n_fev,double(final_meta[10]),double(final_meta[4]));'
assert original.count(old)==1
for name,expression in [('baseline','n_iter==0 ? 8 : n_iter==8 ? 1 : 4'),('chunk8','8'),('chunk16','16'),('chunk8_early','8'),('chunk16_early','16'),('adaptive8','n_iter==0 ? 8 : n_iter==8 ? 1 : n_iter<32 ? 4 : 8'),('adaptive16','n_iter==0 ? 8 : n_iter==8 ? 1 : n_iter<32 ? 4 : 16'),('adaptive16_early','n_iter==0 ? 8 : n_iter==8 ? 1 : n_iter<32 ? 4 : 16')]:
 s=original.replace('#include <algorithm>','#include <algorithm>\n#include <chrono>')
 s=s.replace('MLXLearnRetainTestBufferV3','MLXLearnRetainTestBufferSchedule'+name)
 s=s.replace(chunk,'int chunk=std::min('+expression+',max_iter-n_iter);')
 s=s.replace('        int cur=0,n_iter=0,status=0,n_fev=0;','''        auto timer_start=std::chrono::steady_clock::now();
        double accumulated_gpu=0; int command_count=0,encoded_steps=0;
        int cur=0,n_iter=0,status=0,n_fev=0;''')
 s=s.replace('            for(int k=0;k<chunk;++k) {','            encoded_steps+=chunk;\n            for(int k=0;k<chunk;++k) {')
 target='''            set_pending(registry,owners.work,nil);pending=nil;
            float* h=static_cast<float*>(meta[cur].contents());'''
 replacement='''            accumulated_gpu += std::max(0.0,cb.GPUEndTime-cb.GPUStartTime); ++command_count;
            set_pending(registry,owners.work,nil);pending=nil;
            float* h=static_cast<float*>(meta[cur].contents());'''
 assert s.count(target)==1;s=s.replace(target,replacement)
 new='''double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-timer_start).count();
        PyObject* result=Py_BuildValue("Niiiddddi i",bytes,n_iter,status,n_fev,double(final_meta[10]),double(final_meta[4]),accumulated_gpu,elapsed,command_count,encoded_steps);'''
 # Spaces are ignored by Py_BuildValue format, but use a compact checked format.
 new=new.replace('Niiiddddi i','Niiiddddii')
 assert s.count(old)==1;s=s.replace(old,new)
 source=base/(name+'.mm');binary=base/(name+'/_metal_loop.so');binary.parent.mkdir(exist_ok=True)
 source.write_text(s)
 args=['clang++','-O3','-shared','-fobjc-arc','-std=c++17','-undefined','dynamic_lookup','-framework','Foundation','-framework','Metal',f'-I{sysconfig.get_path("include")}',str(source),'-o',str(binary)]
 subprocess.run(args,check=True)
