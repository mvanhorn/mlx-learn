import os,signal,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
with (root/'panel.log').open('w') as log:
 p=subprocess.Popen([sys.executable,str(root/'panel.py')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try: status=p.wait(timeout=75)
 except subprocess.TimeoutExpired:
  os.killpg(p.pid,signal.SIGKILL);p.wait();status='timeout-killed-process-group'
print('status',status,flush=True)
