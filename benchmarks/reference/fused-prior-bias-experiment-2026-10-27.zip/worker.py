"""Persistent isolated solver for interleaved timing."""
import gc,json,sys,time,warnings
from pathlib import Path
base=Path(__file__).resolve().parent;variant,mode,seed=sys.argv[1],sys.argv[2],int(sys.argv[3]);sys.path.insert(0,str(base/variant))
import mlx.core as mx
import numpy as np
from threadpoolctl import threadpool_limits
from mlxlearn._common.config import tuning_context
from mlxlearn.linear_model import LogisticRegression
from mlxlearn._solvers import native_command
rng=np.random.default_rng(seed);n,d=20000,1024
X=rng.standard_normal((n,d),dtype=np.float32);y=(X[:,0]+rng.normal(scale=.5,size=n)>0).astype(np.int32)
if mode in ('imbalance','shifted'):y=(X[:,0]>np.quantile(X[:,0],.9)).astype(np.int32)
elif mode=='rare':y=(X[:,0]>np.quantile(X[:,0],.98)).astype(np.int32)
if mode=='ill':
 X[:,512:]=X[:,:512]+np.float32(.01)*X[:,512:];X*=np.logspace(-1,1,1024,dtype=np.float32)
if mode=='shifted':X+=np.float32(1000)
w=rng.uniform(.25,3.,n);seen=[];real=native_command._metal_loop
class Probe:
 def run(self,*args):
  result=real.run(*args);seen.append({'n_iter':result[1],'status':result[2],'bias':args[19] if len(args)>=21 else 0.,'init_loss':args[20] if len(args)>=21 else float(np.log(2.))});return result
native_command._metal_loop=Probe()
print('READY',flush=True)
with threadpool_limits(limits=1):
 for command in sys.stdin:
  if command.strip()=='stop':break
  try:
   seen.clear()
   with warnings.catch_warnings(record=True) as caught,tuning_context(force_backend='mlx'):
    warnings.simplefilter('always');mx.synchronize();enabled=gc.isenabled();gc.disable()
    try:
     t=time.perf_counter();m=LogisticRegression(C=1.0,tol=1e-4,max_iter=200).fit(X,y,sample_weight=w);mx.synchronize();elapsed=(time.perf_counter()-t)*1000
    finally:
     if enabled:gc.enable()
   out={'ms':elapsed,'coef':m.coef_.ravel().tolist(),'intercept':m.intercept_.tolist(),'n_iter':m.n_iter_.tolist(),'warnings':[{'category':z.category.__name__,'message':str(z.message)} for z in caught],'native':seen.copy(),'backend':m._execution_backend_}
   print(json.dumps(out),flush=True)
  except Exception as e:
   print(json.dumps({'error':repr(e)}),flush=True)
