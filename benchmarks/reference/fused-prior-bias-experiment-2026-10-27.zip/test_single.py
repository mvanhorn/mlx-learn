"""One hard-timeout fused-prior probe, independent package process."""
import faulthandler,sys,time,warnings
from pathlib import Path
faulthandler.dump_traceback_later(8,repeat=False)
base=Path(__file__).resolve().parent
variant=sys.argv[1];mode=sys.argv[2] if len(sys.argv)>2 else 'imbalance';n=int(sys.argv[3]) if len(sys.argv)>3 else 8192;d=512
sys.path.insert(0,str(base/variant))
import mlx.core as mx
import numpy as np
from scipy.special import expit
from mlxlearn._common.config import tuning_context
from mlxlearn._solvers import native_command
from mlxlearn.linear_model import LogisticRegression
rng=np.random.default_rng(41);X=rng.standard_normal((n,d),dtype=np.float32)
y=(X[:,0]>np.quantile(X[:,0],.9)).astype(np.int32)
w=rng.uniform(.25,3.,n)
if mode=='ones':w=np.ones(n)
elif mode=='balanced':y=(X[:,0]>np.quantile(X[:,0],.5)).astype(np.int32)
elif mode=='shifted':X+=np.float32(1000)
elif mode=='extreme':y=(X[:,0]>np.quantile(X[:,0],.999)).astype(np.int32)
elif mode=='zero_budget':pass
seen=[]
real=native_command._metal_loop
class Probe:
 def run(self,*args):
  result=real.run(*args)
  seen.append({'n_iter':result[1],'status':result[2], 'bias':args[19] if len(args)>=21 else 0., 'initial_objective':args[20] if len(args)>=21 else float(np.log(2.))})
  return result
native_command._metal_loop=Probe()
print('fit start',variant,mode,flush=True)
with warnings.catch_warnings(record=True) as caught, tuning_context(force_backend='mlx'):
 warnings.simplefilter('always'); t=time.perf_counter()
 model=LogisticRegression(C=1.0,tol=1e-4,max_iter=0 if mode=='zero_budget' else 200).fit(X,y,sample_weight=w);mx.synchronize();elapsed=1000*(time.perf_counter()-t)
print('fit finished',model.n_iter_.tolist(),'ms',elapsed,'warnings',[str(w.message) for w in caught],'native',seen,flush=True)
coef=model.coef_[0];raw=X.astype(np.float64)@coef+model.intercept_[0];denom=w.sum()
loss=np.sum(w*(np.logaddexp(0,raw)-y*raw))/denom+coef@coef/(2*denom)
grad=(X.astype(np.float64).T@(w*(expit(raw)-y))+coef)/denom
print('loss',loss,'grad max',float(np.max(np.abs(grad))), 'intercept',model.intercept_[0],flush=True)
faulthandler.cancel_dump_traceback_later()
