from pathlib import Path
import shutil,zipfile,subprocess,sysconfig
root=Path(__file__).resolve().parent; top=root.parents[1]
for label in ('baseline','candidate'):
 dst=root/label
 if dst.exists():shutil.rmtree(dst)
 dst.mkdir()
 with zipfile.ZipFile(top/'benchmarks/reference/wide-repair-start-sources-2026-10-27.zip') as z:
  for name in z.namelist():
   if name.startswith(('src/mlxlearn/','src/mlxlearn_device/')):
    p=dst/name.removeprefix('src/');p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
 shutil.copy2(top/'bench/wide-repair-start/_metal_loop.abi3.so',dst/'mlxlearn/_solvers/_metal_loop.abi3.so')
def edit(path,old,new):
 s=path.read_text();n=s.count(old)
 if n!=1:raise RuntimeError((str(path),n,old[:70]))
 path.write_text(s.replace(old,new))
dst=root/'candidate/mlxlearn';p=dst/'_kernels/logistic_input.py'
source = p.read_text()
start = source.index('_center_initial = mx.fast.metal_kernel(')
end = source.index('\n\n@mx.compile', start)
initial_kernel = source[start:end]
prior_kernel = initial_kernel.replace('_center_initial = ', '_center_initial_prior = ', 1).replace('mlxlearn_logistic_center_initial', 'mlxlearn_logistic_center_initial_prior', 1)
prior_kernel = prior_kernel.replace('input_names=["X", "center", "y", "sw"],', 'input_names=["X", "center", "y", "sw", "prior_prob"],')
prior_kernel = prior_kernel.replace('float grad=0,diag=0;', 'float grad=0,diag=0;float prob=prior_prob[0], curvature=prob*(1.0f-prob);')
prior_kernel = prior_kernel.replace('grad+=x*(.5f-y[row])*weight;diag+=.25f*x*x*weight;', 'grad+=x*(prob-y[row])*weight;diag+=curvature*x*x*weight;')
p.write_text(source[:end] + "\n\n" + prior_kernel + source[end:])
edit(p,'def prepare_centered(X, y=None, sw=None):','def prepare_centered(X, y=None, sw=None, *, prior_probability=0.5):')
edit(p,'''    owned, parts = _center_initial(
        inputs=[X, center, y, sw],
''','''    kernel = _center_initial if prior_probability == 0.5 else _center_initial_prior
    inputs = [X, center, y, sw]
    if prior_probability != 0.5:
        inputs.append(mx.array([prior_probability], dtype=mx.float32))
    owned, parts = kernel(
        inputs=inputs,
''')
p=dst/'linear_model/_logistic.py'
edit(p,'native=_use_native_solver(config, targets, X_checked.shape[1]),','native=_use_native_solver(config, targets, X_checked.shape[1]),\n                            allow_prior=(config.max_iter > 0 and config.sketch_size == 0),')
edit(p,'def _prepare_centered_logistic_input(X, y, weights, *, native):','def _prepare_centered_logistic_input(X, y, weights, *, native, allow_prior=False):')
old='''        owned, center, finite, parts = prepare_centered(borrowed, labels, sample_weights)
        try:
            mx.eval(owned, center, finite, parts)
            yield owned, center, bool(finite), parts
'''
new='''        prior_bias, prior_objective, prior_probability = 0.0, math.log(2.0), 0.5
        if native and allow_prior and weights is not None and len(y) >= 8192:
            represented = np.asarray(weights, dtype=np.float32)
            if not np.all(represented == 1):
                total_repr = float(np.sum(represented, dtype=np.float64))
                total_original = float(np.sum(weights, dtype=np.float64))
                positive = float(np.sum(represented * y, dtype=np.float64)) / total_repr
                if 1e-5 < positive < 1.0 - 1e-5 and (positive < 0.2 or positive > 0.8):
                    prior_bias = float(np.float32(math.log(positive / (1.0 - positive))))
                    prior_probability = float(np.float32(1.0 / (1.0 + math.exp(-prior_bias))))
                    prior_objective = total_repr / total_original * (
                        positive * math.log1p(math.exp(-prior_bias))
                        + (1.0 - positive) * math.log1p(math.exp(prior_bias)))
        owned, center, finite, parts = prepare_centered(
            borrowed, labels, sample_weights, prior_probability=prior_probability)
        try:
            mx.eval(owned, center, finite, parts)
            passed_parts = (parts, prior_bias, prior_objective) if prior_bias else parts
            yield owned, center, bool(finite), passed_parts
'''
edit(p,old,new)
p=dst/'_solvers/logistic.py'
needle='''    center = None
    if y_host.shape != (n_samples,):
'''
edit(p,needle,'''    prior_bias, prior_objective = 0.0, math.log(2.0)
    if isinstance(initial_parts, tuple):
        initial_parts, prior_bias, prior_objective = initial_parts
    center = None
    if y_host.shape != (n_samples,):
''')
edit(p,'''            if initial_history is not None:
                native_options["initial_history"] = initial_history
''','''            if initial_history is not None:
                native_options["initial_history"] = initial_history
            if prior_bias:
                native_options["prior_bias"] = prior_bias
                native_options["prior_objective"] = prior_objective
''')
p=dst/'_solvers/native_logistic.py'
edit(p,'    use_native_loop: bool = True,\n) -> LBFGSState:', '    use_native_loop: bool = True,\n    prior_bias: float = 0.0,\n    prior_objective: float = math.log(2.0),\n) -> LBFGSState:')
needle='''    # Native command submission requires prepared, privately owned inputs.
'''
edit(p,needle,'''    if prior_bias:
        w = mx.concatenate([mx.zeros(d, dtype=X.dtype), mx.array([prior_bias], dtype=X.dtype)])

    # Native command submission requires prepared, privately owned inputs.
''')
edit(p,'''        if initial_history is not None:
            native_kwargs["initial_history"] = initial_history
''','''        if initial_history is not None:
            native_kwargs["initial_history"] = initial_history
        if prior_bias:
            native_kwargs["prior_bias"] = prior_bias
            native_kwargs["prior_objective"] = prior_objective
''')
edit(p,'''        meta = mx.concatenate([mx.zeros(11, dtype=X.dtype), mx.array([math.log(2)], dtype=X.dtype)])
        raw = mx.zeros(n, dtype=X.dtype)
''','''        meta = mx.concatenate([mx.zeros(11, dtype=X.dtype), mx.array([prior_objective], dtype=X.dtype)])
        raw = mx.full(n, prior_bias, dtype=X.dtype)
''')
p=dst/'_solvers/native_command.py'
edit(p,'''    convergence_center=None, initial_history=None, return_attempt=False,
''','''    convergence_center=None, initial_history=None, return_attempt=False,
    prior_bias=0.0, prior_objective=math.log(2.0),
''')
edit(p,'''        arguments += (seed_capsules, seed_count, None, 1)
''','''        arguments += (seed_capsules, seed_count, None, 1, prior_bias, prior_objective)
''')
p=dst/'_solvers/_metal_loop.mm'
p.write_text(p.read_text().replace('MLXLearnRetainTestBufferV5','MLXLearnRetainTestBufferPriorFused'))
edit(p,'int seed_count=0, weighted=0;','int seed_count=0, weighted=0; double prior_bias=0, prior_objective=std::log(2.0);')
edit(p,'"sOiiiiiiiddddOy#|OiOi"','"sOiiiiiiiddddOy#|OiOidd"')
edit(p,'&seed_capsules,&seed_count,&device_buffers,&weighted))','&seed_capsules,&seed_count,&device_buffers,&weighted,&prior_bias,&prior_objective))')
edit(p,'static_cast<float*>(meta[0].contents())[11]=std::log(2.0f);','''static_cast<float*>(meta[0].contents())[11]=float(prior_objective);
        if(prior_bias!=0.0) {
          for(int a=0;a<2;++a){
            static_cast<float*>(w[a].contents())[d]=float(prior_bias);
            std::fill_n(static_cast<float*>(raw[a].contents()),n,float(prior_bias));
          }
        }''')
out=dst/'_solvers/_metal_loop.abi3.so';cmd=['clang++','-O3','-shared','-fobjc-arc','-std=c++17','-undefined','dynamic_lookup','-framework','Foundation','-framework','Metal',f'-I{sysconfig.get_path("include")}',str(p),'-o',str(out)]
subprocess.run(cmd,check=True);print('prepared',out)
