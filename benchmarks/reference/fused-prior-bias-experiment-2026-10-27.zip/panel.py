"""Interleaved full-fit comparison, independent float64 scoring."""
import hashlib,json,math,statistics,subprocess,sys,warnings
from pathlib import Path
from types import SimpleNamespace
base=Path(__file__).resolve().parent;sys.path.insert(0,str(base.parents[1]))
import numpy as np
from sklearn.linear_model import LogisticRegression as SK
from threadpoolctl import threadpool_limits
from benchmarks.hessian_logistic import independent_score
from benchmarks.sketch_weighted import tight_reference_usable
cases=[('imbalance',41),('imbalance',83),('imbalance',2027),('rare',2027),('ordinary',41),('shifted',41),('ill',83)]
def hashes():
 files=[base/'prepare.py',base/'worker.py',base/'panel.py']+[q for v in ('baseline','candidate') for q in (base/v).rglob('*') if q.is_file() and '__pycache__' not in q.parts]
 return {str(q):hashlib.sha256(q.read_bytes()).hexdigest() for q in files}
def data(mode,seed):
 rng=np.random.default_rng(seed);n,d=20000,1024
 X=rng.standard_normal((n,d),dtype=np.float32);y=(X[:,0]+rng.normal(scale=.5,size=n)>0).astype(np.int32)
 if mode in ('imbalance','shifted'):y=(X[:,0]>np.quantile(X[:,0],.9)).astype(np.int32)
 elif mode=='rare':y=(X[:,0]>np.quantile(X[:,0],.98)).astype(np.int32)
 if mode=='ill':X[:,512:]=X[:,:512]+np.float32(.01)*X[:,512:];X*=np.logspace(-1,1,1024,dtype=np.float32)
 if mode=='shifted':X+=np.float32(1000)
 return X,y,rng.uniform(.25,3.,n)
def main():
 out={'source_before':hashes(),'method':'interleaved complete fits from two persistent independent processes; two warmups five timings; source verified; tight centered float64 reference','cases':[]}
 with threadpool_limits(limits=1):
  for mode,seed in cases:
   workers={};logs=[]
   try:
    for name in ('baseline','candidate'):
     log=(base/f'{mode}-{seed}-{name}-stderr.log').open('w');logs.append(log)
     workers[name]=subprocess.Popen([sys.executable,str(base/'worker.py'),name,mode,str(seed)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=log,text=True,bufsize=1)
    for name,proc in workers.items():
     if proc.stdout.readline().strip()!='READY':raise RuntimeError(f'{name} failed startup')
    samples={x:[] for x in workers}
    for rep in range(7):
     order=('baseline','candidate') if rep%2==0 else ('candidate','baseline')
     for name in order:
      p=workers[name];p.stdin.write('fit\n');p.stdin.flush();line=p.stdout.readline()
      if not line:raise RuntimeError(f'{name} process exited {p.poll()}')
      obj=json.loads(line)
      if 'error' in obj:raise RuntimeError(f'{name} {obj}')
      if rep>=2:samples[name].append(obj)
   finally:
    for p in workers.values():
     if p.poll() is None:
      p.stdin.write('stop\n');p.stdin.flush()
      try:p.wait(timeout=2)
      except subprocess.TimeoutExpired:p.kill();p.wait()
    for log in logs:log.close()
   X,y,w=data(mode,seed);center=X.mean(axis=0,dtype=np.float64);centered=X.astype(np.float64)-center
   with warnings.catch_warnings(record=True) as rw:
    warnings.simplefilter('always');ref=SK(C=1,tol=1e-10,max_iter=3000).fit(centered,y,sample_weight=w)
   rm=SimpleNamespace(coef_=ref.coef_,intercept_=ref.intercept_-ref.coef_@center);ref_score,ref_pred=independent_score(rm,X,y,w,1,None)
   refwarn=[{'category':x.category.__name__,'message':str(x.message)} for x in rw];refvalid=tight_reference_usable(ref_score,refwarn,1e-4);del centered
   for items in samples.values():
    for item in items:
     m=SimpleNamespace(coef_=np.array(item.pop('coef')).reshape(1,-1),intercept_=np.array(item.pop('intercept')))
     item['score']=independent_score(m,X,y,w,1,None,(ref_score['objective_float64'],ref_pred))[0]
   failures=[]
   if not refvalid:failures.append({'reference_invalid':ref_score,'warnings':refwarn})
   for i,(c,b) in enumerate(zip(samples['candidate'],samples['baseline'])):
    sc=c['score'];sb=b['score'];gap=(sc['objective_float64']-sb['objective_float64'])/abs(sb['objective_float64'])
    if gap>1e-5 or (refvalid and sc['objective_relative_gap_to_sklearn']>1e-5) or sc['gradient_max_abs_float64']>1e-4 or c['warnings'] or c['backend']!='mlx' or not c['native']:
     failures.append({'fit':i,'previous_gap':gap,'quality':sc,'warnings':c['warnings'],'native':c['native']})
   row={'case':mode,'seed':seed,'median_ms':{v:statistics.median(s['ms'] for s in items) for v,items in samples.items()},'samples':samples,'reference':ref_score,'reference_valid':refvalid,'failures':failures}
   out['cases'].append(row);print(mode,seed,row['median_ms'],'iters',samples['baseline'][0]['n_iter'],samples['candidate'][0]['n_iter'],'init',samples['candidate'][0]['native'],'failures',failures[:1],flush=True)
   (base/'panel-results.json').write_text(json.dumps(out,indent=2)+'\n')
 out['source_after']=hashes();out['source_integrity_pass']=out['source_before']==out['source_after'];(base/'panel-results.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':main()
