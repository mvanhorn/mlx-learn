"""Hard timeout guard for separate frozen and fused-prior processes."""
import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path(__file__).resolve().parent
results=[]
for variant in ('baseline','candidate'):
 for mode in ('imbalance','ones','zero_budget'):
  path=root/(variant+'-'+mode+'.log')
  with path.open('w') as log:
   t=time.perf_counter()
   try:
    cp=subprocess.run([sys.executable,str(root/'test_single.py'),variant,mode],stdout=log,stderr=subprocess.STDOUT,timeout=15,check=False)
    status=cp.returncode
   except subprocess.TimeoutExpired:status='timeout-killed'
  elapsed=time.perf_counter()-t;results.append({'variant':variant,'mode':mode,'status':status,'seconds':elapsed,'log':path.read_text()})
  print(variant,mode,status,round(elapsed,3),flush=True)
  if status=='timeout-killed':break
files=[root/'prepare.py',root/'test_single.py',root/'run_repro.py']+[p for v in ('baseline','candidate') for p in (root/v).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
(root/'repro-results.json').write_text(json.dumps({'results':results,'files':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},'timeout_seconds':15},indent=2)+'\n')
