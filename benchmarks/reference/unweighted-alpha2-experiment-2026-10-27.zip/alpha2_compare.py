"""Measure alpha=2 on the first step with unchanged 8-candidate Armijo search.

Only the first iteration starts at alpha=2, then subsequent iterations start at 1. The existing eight-candidate search and full continuation fallback remain unchanged. This is diagnostic, not production; every sample and ordering is retained.
"""
import argparse
import hashlib
import itertools
import importlib.util
import json
import statistics
from pathlib import Path
from types import SimpleNamespace

import numpy as np
from threadpoolctl import threadpool_limits

from benchmarks.logistic_gpu import Case, make_data, quality
from benchmarks.logistic_wide import fit_once, frozen_reference
from mlxlearn._solvers import native_command


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--repeats',type=int,default=24)
    p.add_argument('--warmup',type=int,default=3)
    p.add_argument('--dtype',choices=('float32','float64','both'),default='float32')
    p.add_argument('--output',type=Path,default=Path('bench/unweighted_opt/alpha2-results.json'))
    p.add_argument('--case',action='append',default=[])
    args=p.parse_args()
    variants=('previous_native','current','alpha2','sklearn')
    orders=list(itertools.permutations(variants))
    assert args.repeats%len(orders)==0
    original_extension=native_command._metal_loop
    alpha_path=Path('bench/unweighted_opt/alpha2/_metal_loop.abi3.so').resolve()
    spec=importlib.util.spec_from_file_location('_alpha2._metal_loop',alpha_path)
    alpha_extension=importlib.util.module_from_spec(spec); spec.loader.exec_module(alpha_extension)
    result={'method':{'variants':variants,'permutations':len(orders),'repeats':args.repeats,
                      'warmups':args.warmup,'policy':'alpha 2 on first iteration, alpha 1 thereafter; unchanged batched Armijo and continuation',
                      'score':'independent float64 scoring after all fits in each case'},
            'harness_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'alpha_source_sha256':hashlib.sha256(alpha_path.with_name('_metal_loop.mm').read_bytes()).hexdigest(),
            'alpha_binary_sha256':hashlib.sha256(alpha_path.read_bytes()).hexdigest(),'cases':[]}
    cases=(Case('20k1024',20000,1024), Case('60k1024',60000,1024),
           Case('weighted20k1024',20000,1024,weighted=True),Case('20k4096_default',20000,4096),Case('20k4096_strict',20000,4096),
           Case('ill_conditioned12k1024',12000,1024,ill_conditioned=True))
    if args.case:
        assert not set(args.case)-{case.name for case in cases}
        cases=tuple(case for case in cases if case.name in args.case)
    archive=Path('benchmarks/reference/certified-start-2026-10-27.zip')
    binary=Path('bench/certified-start/_metal_loop.abi3.so')
    with frozen_reference(archive=archive,extension=binary) as reference,threadpool_limits(limits=1):
      for dtype in (('float32','float64') if args.dtype=='both' else (args.dtype,)):
       for case in cases:
        X,y,weights=make_data(case,41,dtype=dtype);tol=1e-5 if case.name.endswith('_strict') else 1e-4
        rec={'name':case.name,'shape':[case.n_samples,case.n_features],
             'dtype':dtype,'tol':tol,'weighted':case.weighted,
             'order':[],'fits':{k:[] for k in variants},'samples':{k:[] for k in variants}}
        models={k:[] for k in variants}
        def fit(variant):
            calls=[]
            def run(*a):
                v=alpha_extension.run(*a);calls.append({'status':v[2],'accepted_steps':v[1],'n_fev':v[3]});return v
            if variant=='alpha2':
                native_command._metal_loop=SimpleNamespace(run=run)
            try:
                mapped='optimized_gpu' if variant in ('alpha2','current') else variant
                elapsed,model,meta=fit_once(mapped,X,y,weights,reference=reference,max_iter=200,tol=tol)
            finally:
                native_command._metal_loop=original_extension
            return elapsed,model,{**meta,'alpha2_device_calls':calls}
        for _ in range(args.warmup):
            for v in variants:fit(v)
        for i in range(args.repeats):
            order=orders[i%len(orders)];rec['order'].append(order)
            for v in order:
                t,m,meta=fit(v);rec['samples'][v].append(t);rec['fits'][v].append(meta);models[v].append(m)
        X64=X.astype(np.float64,copy=False);sk=models['sklearn'][-1]
        rec['quality']={k:[quality(m,sk,X64,y,weights) for m in ms] for k,ms in models.items() if k!='sklearn'}
        rec['median_ms']={k:statistics.median(v)*1000 for k,v in rec['samples'].items()}
        rec['mean_ms']={k:statistics.mean(v)*1000 for k,v in rec['samples'].items()}
        rec['paired_wins_alpha2_vs_current']=sum(a<b for a,b in zip(rec['samples']['alpha2'],rec['samples']['current']))
        print(dtype,case.name,rec['median_ms'],'paired_wins',rec['paired_wins_alpha2_vs_current'],
              'routes', {r['implementation'] for r in rec['fits']['alpha2']},flush=True)
        result['cases'].append(rec);args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(result,indent=2)+'\n')

if __name__=='__main__':main()
